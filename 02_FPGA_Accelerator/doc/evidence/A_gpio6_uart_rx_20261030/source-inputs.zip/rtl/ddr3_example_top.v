//***************************************************************/
//
// Moudel Name    : ddr3_example_top.v
// Version        : 1.1
// Date Created   : 2023-02-23 10:37:59
// Last Modified  : 2023-02-24 15:27:41
// Abstract       : ---
//
//***************************************************************/
//Modification History
//1.initial
//***************************************************************/
`include "ddr3_controller/ddr3_parameter.vh"

`define Efinity_Debug
`timescale 1ps/1ps
// `define SOFT_JTAG

module ddr3_example_top #
(
parameter                       RANK_RATIO         = 1,       // # of unique CS outputs per rank
parameter                       CK_RATIO           = `CK_RATIO, 
parameter                       ASYN_AXI_CLK       = `ASYN_AXI_CLK, 
parameter                       RANKS              = `RANKS,
parameter                       CK_WIDTH           = `CK_WIDTH,       // # of CK/CK# outputs to memory   
parameter                       CKE_WIDTH          = `CKE_WIDTH,       // # of cke outputs
parameter                       CS_WIDTH           = `CS_WIDTH,       // # of unique CS outputs
parameter                       BANK_WIDTH         = `BANK_WIDTH,       // # of bank bits
parameter                       ROW_WIDTH          = `ROW_WIDTH,       // DRAM address bus width
parameter                       COL_WIDTH          = `COL_WIDTH,      // column address width
parameter                       DM_WIDTH           = `DM_WIDTH,       // # of DM (data mask)
parameter                       DQS_WIDTH          = `DQS_WIDTH,       // # of DQS (strobe)
parameter                       DQ_WIDTH           = `DQ_WIDTH,      // # of DQ (data)
parameter                       ODT_WIDTH          = `ODT_WIDTH,
parameter                       DQ_CNT_WIDTH       = `DQ_CNT_WIDTH,       // = ceil(log2(DQ_WIDTH))
parameter                       DQS_CNT_WIDTH      = `DQS_CNT_WIDTH,       // = ceil(log2(DQS_WIDTH))  
parameter                       DRAM_WIDTH         = `DRAM_WIDTH,       // # of DQ per DQS   
parameter                       DATA_WIDTH         = `DATA_WIDTH,
parameter                       ADDR_WIDTH         = `ADDR_WIDTH,    
parameter                       AXI_ID_WIDTH       = `AXI_ID_WIDTH,
parameter                       AXI_ADDR_WIDTH     = `AXI_ADDR_WIDTH,
parameter                       AXI_DATA_WIDTH     = `AXI_DATA_WIDTH
)
(

   // Clock and reset ports
   input                              axi_clk,      
   input                              core_clk,     // CORE CLK @ 100MHz
   input                              sdram_clk,    // SDRAM CK @ 400MHz
   input                              rx_cal_clk,   // SDRAM CK @ 400MHz
   input                              tx_cal_clk,   // SDRAM CK @ 400MHz
   input                              tx_cal_clk_90edge,   // SDRAM CK @ 400MHz
   input                              pll_locked,
   input                              user_pll_locked,
  //  input                              peripheralClk,
   //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
   output  wire                       system_uart_0_io_txd,
output  wire                       buzzer,                // Stage7 A-3: GPIOL_04 (QSE J7 pin37, 3.3V)
   input                              system_uart_0_io_rxd,   
   input  [3:0]                       soc_gpio_IN,
   output [3:0]                       soc_gpio_OUT,
   output [3:0]                       soc_gpio_OE,
   input  [7:0]                       plat_gpio_IN,       // Stage7 A-3b: PS2 pad + MPU6050 I2C
   output [7:0]                       plat_gpio_OUT,
   output [7:0]                       plat_gpio_OE,
    // debug core ports
`ifdef  Efinity_Debug  //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& 
`ifdef SOFT_JTAG
  input                               io_jtag_tms,
  input                               io_jtag_tdi,
  output  wire                        io_jtag_tdo,
  input                               io_jtag_tck,
`else
  input                               jtag_inst1_CAPTURE ,
  input                               jtag_inst1_DRCK    ,
  input                               jtag_inst1_RESET   ,
  input                               jtag_inst1_RUNTEST ,
  input                               jtag_inst1_SEL     ,
  input                               jtag_inst1_SHIFT   ,
  input                               jtag_inst1_TCK     ,
  input                               jtag_inst1_TDI     ,
  input                               jtag_inst1_TMS     ,
  input                               jtag_inst1_UPDATE  ,
  output                              jtag_inst1_TDO     ,
`endif 

`endif  //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
   // PLL status flags  
   output [2:0]                       pll_shift,  
   output [4:0]                       pll_shift_sel,
   output                             pll_shift_ena,  
   // memory interface ports
   output                             ddr_ck_hi,
   output                             ddr_ck_lo,
   output                             ddr_reset_n,
   output [CKE_WIDTH-1:0]             ddr_cke,     
   output [ROW_WIDTH-1:0]             ddr_addr,
   output [BANK_WIDTH-1:0]            ddr_ba,
   output                             ddr_cas_n,

   output [CS_WIDTH*RANK_RATIO-1:0]   ddr_cs_n,
   output                             ddr_ras_n,
   output                             ddr_we_n,
   
   input  [DQS_WIDTH-1:0]             ddr_dqs_in_hi,
   input  [DQS_WIDTH-1:0]             ddr_dqs_in_lo,
   input  [DQ_WIDTH-1:0]              ddr_dq_in_hi,
   input  [DQ_WIDTH-1:0]              ddr_dq_in_lo,
   
   output [DQS_WIDTH-1:0]             ddr_dqs_oe,
   output [DQS_WIDTH-1:0]             ddr_dqs_oe_n,
   output [DQ_WIDTH-1:0]              ddr_dq_oe,  
   output [DQS_WIDTH-1:0]             ddr_dqs_out_hi,
   output [DQS_WIDTH-1:0]             ddr_dqs_out_lo,
   output [DQ_WIDTH-1:0]              ddr_dq_out_hi,
   output [DQ_WIDTH-1:0]              ddr_dq_out_lo,
   output [DM_WIDTH-1:0]              ddr_dm_hi,
   output [DM_WIDTH-1:0]              ddr_dm_lo,
   output [ODT_WIDTH-1:0]             ddr_odt,

   input                              system_spi_0_io_data_0_IN,
   input                              system_spi_0_io_data_1_IN,
   output                             system_spi_0_io_ss,
   output                             system_spi_0_io_sclk_write,
   output                             system_spi_0_io_data_0_OUT,
   output                             system_spi_0_io_data_0_OE,
   output                             system_spi_0_io_data_1_OUT,
   output                             system_spi_0_io_data_1_OE,

   //====================================================================
   // 关卡3 M1: HDMI TX 接口
   //   PLL (pll_hdmi) 与 4 组 LVDS TX 硬核由 Interface Designer 从
   //   ddr_demo_ti60.peri.xml 生成，按名字与下面的端口对接：
   //     pll_hdmi 输出 -> hdmi_tx_locked / hdmi_tx_slow_clk (74.375MHz 像素时钟)
   //     LVDS 硬核      -> tmds_*_o / *_TX_OE / *_TX_RST
   //====================================================================
   input                              hdmi_tx_locked,
   input                              hdmi_tx_slow_clk,
   output [9:0]                       tmds_data0_o,
   output [9:0]                       tmds_data1_o,
   output [9:0]                       tmds_data2_o,
   output [9:0]                       tmds_clk_o,
   output                             tmds_data0_TX_OE,
   output                             tmds_data1_TX_OE,
   output                             tmds_data2_TX_OE,
   output                             tmds_clk_TX_OE,
   output                             tmds_data0_TX_RST,
   output                             tmds_data1_TX_RST,
   output                             tmds_data2_TX_RST,
   output                             tmds_clk_TX_RST

   );


      
//Parameter Define
parameter FREQ = 200;			// default is 100 MHz.  Redefine as needed.
`ifndef SIM
    localparam CNT_INIT = 1.5*FREQ*1000;
`else
    localparam CNT_INIT = 10;
`endif    
  localparam   AIW               = AXI_ID_WIDTH      ;
  localparam   ADW               = AXI_DATA_WIDTH    ;
  localparam   ABN               = AXI_DATA_WIDTH/8   ;
  /////////////////////////////////////////////////////////
  // Wire declarations
  reg  [19:0]                       cnt;    
  wire                              clk;
  wire                              rst;
  wire                              mmcm_locked;
  reg                               aresetn;
  wire                              app_sr_active;
  wire                              app_ref_ack;
  wire                              app_zq_ack;

  wire                              cal_done;

  // Slave Interface Write Address Ports
  wire [AXI_ID_WIDTH-1:0]           s_axi_awid;
  wire [AXI_ADDR_WIDTH-1:0]         s_axi_awaddr;
  wire [7:0]                        s_axi_awlen;
  wire [2:0]                        s_axi_awsize;
  wire [1:0]                        s_axi_awburst;
  wire [0:0]                        s_axi_awlock;
  wire [3:0]                        s_axi_awcache;
  wire [2:0]                        s_axi_awprot;
  wire                              s_axi_awvalid;
  wire                              s_axi_awready;
   // Slave Interface Write Data Ports
  wire [AXI_DATA_WIDTH-1:0]         s_axi_wdata;
  wire [(AXI_DATA_WIDTH/8)-1:0]     s_axi_wstrb;
  wire                              s_axi_wlast;
  wire                              s_axi_wvalid;
  wire                              s_axi_wready;
   // Slave Interface Write Response Ports
  wire                              s_axi_bready;
  wire [AXI_ID_WIDTH-1:0]           s_axi_bid;
  wire [1:0]                        s_axi_bresp;
  wire                              s_axi_bvalid;
   // Slave Interface Read Address Ports
  wire [AXI_ID_WIDTH-1:0]           s_axi_arid;
  wire [AXI_ADDR_WIDTH-1:0]         s_axi_araddr;
  wire [7:0]                        s_axi_arlen;
  wire [2:0]                        s_axi_arsize;
  wire [1:0]                        s_axi_arburst;
  wire [0:0]                        s_axi_arlock;
  wire [3:0]                        s_axi_arcache;
  wire [2:0]                        s_axi_arprot;
  wire                              s_axi_arvalid;
  wire                              s_axi_arready;
   // Slave Interface Read Data Ports
  wire                              s_axi_rready;
  wire [AXI_ID_WIDTH-1:0]           s_axi_rid;
  wire [AXI_DATA_WIDTH-1:0]         s_axi_rdata;
  wire [1:0]                        s_axi_rresp;
  wire                              s_axi_rlast;
  wire                              s_axi_rvalid;


//***************************************************************************
  wire [2:0]                        vio_pll_shift;  
  wire [4:0]                        vio_pll_shift_sel;
  wire                              vio_pll_shift_ena; 
  wire                              pos_pll_shift_ena; 
  wire [2:0]                        phy_pll_shift;  
  wire [4:0]                        phy_pll_shift_sel;
  wire                              phy_pll_shift_ena; 
  wire                              ddr_reset; 
  wire                              sys_rst;
  wire  [2:0]                       phy_wr_pll_shift;
  wire                              idelay_ld       ;
  wire                              mpr_rdlvl_dly   ;
  wire  [7:0]                       wrlvl_dq_check  ;
  wire  [7:0]                       rd_level_dqs_check;  
  wire  [2:0]                       rdlvl_shift;  
  wire  [2:0]                       wrlvl_shift;  
  wire  [15:0]                      debug_fifo;  
  wire  [15:0]                      overflow_fifo;  
  wire  [6:0]                       init_cur_state;  
  wire  [35:0]                      ddr_debug_port;  
  wire                              app_rdy;  
  wire                              user_clk;  
  wire                              ddr_rstn;

//---- Stage 7 A-3: buzzer pin (GPIOL_04, QSE J7 pin 37, 3.3V) ----------------
//     Until B delivers pwm_tone.v this pin emits a ~1 Hz square wave: audible
//     on an active buzzer module AND easy to locate with a multimeter on the
//     QSE-to-header sub-card (J28), which is how we verify the pin mapping.
reg [26:0] buz_cnt;
reg        buzzer_r;

always @(posedge user_clk or negedge sys_rst) begin
    if (!sys_rst) begin
        buz_cnt  <= 27'd0;
        buzzer_r <= 1'b0;
    end else if (buz_cnt == 27'd49_999_999) begin   // 100 MHz / 50M = 1 Hz
        buz_cnt  <= 27'd0;
        buzzer_r <= ~buzzer_r;
    end else begin
        buz_cnt  <= buz_cnt + 27'd1;
    end
end

assign buzzer = buzzer_r;  
  wire                                phy_rddata_valid;
  wire [2*CK_RATIO*DQ_WIDTH-1:0]      phy_rd_data;
  wire [2*CK_RATIO*DATA_WIDTH-1:0]    app_rd_data_to_axi; 
  wire                                app_rd_data_end;
  wire                                app_rd_data_valid;
  wire [2*CK_RATIO*DQ_WIDTH-1:0]      rd_data;          
  wire                                rd_data_en;            
  wire                                rd_data_end;
  wire [15:0]                         apb_paddr;
  wire [0:0]                          apb_psel;
  wire                                apb_penable;
  wire                                apb_pready;
  wire                                apb_pwrite;
  wire [31:0]                         apb_pwdata;
  wire [31:0]                         apb_prdata;
  wire                                apb_pslverror;
  wire                                sig;
  // ---- GPU accelerator AXI4 write master (32-bit) -> SoC io_ddrMasters_0 ----
  wire [31:0]                         gpu_axi_awaddr;
  wire [7:0]                          gpu_axi_awlen;
  wire [2:0]                          gpu_axi_awsize;
  wire [1:0]                          gpu_axi_awburst;
  wire                                gpu_axi_awvalid;
  wire                                gpu_axi_awready;
  wire [127:0]                         gpu_axi_wdata;
  wire [15:0]                          gpu_axi_wstrb;
  wire                                gpu_axi_wlast;
  wire                                gpu_axi_wvalid;
  wire                                gpu_axi_wready;
  wire [1:0]                          gpu_axi_bresp;
  wire                                gpu_axi_bvalid;
  wire                                gpu_axi_bready;
  // DEBUG PROBE: AXI handshake progress, readable by software via GPIO input
  //   (read 0xF8015000 + 0x00)   bit3 = live bvalid, bits[2:0] = sticky:
  //     bit0 = AW handshake done, bit1 = W handshake done, bit2 = B response done
  reg  [2:0]                          dbg_sticky;
  always @(posedge user_clk or negedge sys_rst) begin
      if (!sys_rst)
          dbg_sticky <= 3'b000;
      else
          dbg_sticky <= dbg_sticky | {(gpu_axi_awvalid & gpu_axi_awready),
                                      (gpu_axi_wvalid  & gpu_axi_wready),
                                      (gpu_axi_bvalid  & gpu_axi_bready)};
  end
  wire [3:0]                          dbg_gpio_in = {gpu_axi_bvalid, dbg_sticky};

  //==========================================================================
  // SoC DDR AXI master side (Axi_Mux slave port 0)
  //==========================================================================
  wire [7:0]   soc_axi_awid;    wire [31:0]  soc_axi_awaddr;  wire [7:0]  soc_axi_awlen;
  wire [2:0]   soc_axi_awsize;  wire [1:0]   soc_axi_awburst; wire        soc_axi_awlock;
  wire         soc_axi_awvalid; wire         soc_axi_awready;
  wire [127:0] soc_axi_wdata;   wire [15:0]  soc_axi_wstrb;   wire        soc_axi_wlast;
  wire         soc_axi_wvalid;  wire         soc_axi_wready;
  wire [7:0]   soc_axi_bid;     wire [1:0]   soc_axi_bresp;   wire        soc_axi_bvalid;
  wire         soc_axi_bready;
  wire [7:0]   soc_axi_arid;    wire [31:0]  soc_axi_araddr;  wire [7:0]  soc_axi_arlen;
  wire [2:0]   soc_axi_arsize;  wire [1:0]   soc_axi_arburst; wire        soc_axi_arlock;
  wire         soc_axi_arvalid; wire         soc_axi_arready;
  wire [7:0]   soc_axi_rid;     wire [127:0] soc_axi_rdata;   wire [1:0]  soc_axi_rresp;
  wire         soc_axi_rlast;   wire         soc_axi_rvalid;  wire        soc_axi_rready;

  //---- 关卡3 M2: 显示取数主机（gpu_axi_reader）接 Axi_Mux S1 读通道 ----
  wire [7:0]   disp_arid;   wire [31:0] disp_araddr; wire [7:0] disp_arlen;
  wire [2:0]   disp_arsize; wire [1:0]  disp_arburst; wire [1:0] disp_arlock;
  wire         disp_arvalid; wire        disp_arready;
  wire [7:0]   disp_rid;    wire [127:0] disp_rdata;  wire [1:0] disp_rresp;
  wire         disp_rlast;  wire         disp_rvalid; wire       disp_rready;

  //---- 关卡4: GPU 读通道（gpu_copy，来自 apb3_top）----------------------
  wire [7:0]   gpu_rd_arid;   wire [31:0] gpu_rd_araddr; wire [7:0] gpu_rd_arlen;
  wire [2:0]   gpu_rd_arsize; wire [1:0]  gpu_rd_arburst; wire [1:0] gpu_rd_arlock;
  wire         gpu_rd_arvalid; wire        gpu_rd_arready;
  wire [7:0]   gpu_rd_rid;    wire [127:0] gpu_rd_rdata;  wire [1:0] gpu_rd_rresp;
  wire         gpu_rd_rlast;  wire         gpu_rd_rvalid; wire       gpu_rd_rready;

  //---- 读通道仲裁器从侧（接 Axi_Mux S1 读通道）--------------------------
  wire [7:0]   arb_arid;   wire [31:0] arb_araddr; wire [7:0] arb_arlen;
  wire [2:0]   arb_arsize; wire [1:0]  arb_arburst; wire [1:0] arb_arlock;
  wire         arb_arvalid; wire        arb_arready;
  wire [7:0]   arb_rid;    wire [127:0] arb_rdata;  wire [1:0] arb_rresp;
  wire         arb_rlast;  wire         arb_rvalid; wire       arb_rready;

  // mux master side (to the DDR3 controller AXI slave port)
  wire [7:0]   mux_awid;   wire [31:0] mux_awaddr; wire [7:0] mux_awlen; wire [2:0] mux_awsize;
  wire [1:0]   mux_awburst; wire [1:0] mux_awlock; wire mux_awvalid;     wire       mux_awready;
  wire [7:0]   mux_wid;    wire [127:0] mux_wdata; wire       mux_wlast; wire [15:0] mux_wstrb;
  wire         mux_wvalid; wire         mux_wready;
  wire [7:0]   mux_bid;    wire [1:0]  mux_bresp;  wire       mux_bvalid; wire       mux_bready;
  wire [7:0]   mux_arid;   wire [31:0] mux_araddr; wire [7:0] mux_arlen; wire [2:0] mux_arsize;
  wire [1:0]   mux_arburst; wire [1:0] mux_arlock; wire mux_arvalid;     wire       mux_arready;
  wire [7:0]   mux_rid;    wire [127:0] mux_rdata; wire [1:0] mux_rresp; wire       mux_rlast;
  wire         mux_rvalid; wire        mux_rready;

  assign s_axi_awid    = mux_awid[AXI_ID_WIDTH-1:0];
  assign s_axi_awaddr  = mux_awaddr[AXI_ADDR_WIDTH-1:0];
  assign s_axi_awlen   = mux_awlen;
  assign s_axi_awsize  = mux_awsize;
  assign s_axi_awburst = mux_awburst;
  assign s_axi_awlock  = mux_awlock[0];
  assign s_axi_awvalid = mux_awvalid;
  assign mux_awready   = s_axi_awready;
  assign s_axi_wdata   = mux_wdata;
  assign s_axi_wstrb   = mux_wstrb;
  assign s_axi_wlast   = mux_wlast;
  assign s_axi_wvalid  = mux_wvalid;
  assign mux_wready    = s_axi_wready;
  assign mux_bid       = {4'h0, s_axi_bid};
  assign mux_bresp     = s_axi_bresp;
  assign mux_bvalid    = s_axi_bvalid;
  assign s_axi_bready  = mux_bready;
  assign s_axi_arid    = mux_arid[AXI_ID_WIDTH-1:0];
  assign s_axi_araddr  = mux_araddr[AXI_ADDR_WIDTH-1:0];
  assign s_axi_arlen   = mux_arlen;
  assign s_axi_arsize  = mux_arsize;
  assign s_axi_arburst = mux_arburst;
  assign s_axi_arlock  = mux_arlock[0];
  assign s_axi_arvalid = mux_arvalid;
  assign mux_arready   = s_axi_arready;
  assign mux_rid       = {4'h0, s_axi_rid};
  assign mux_rdata     = s_axi_rdata;
  assign mux_rresp     = s_axi_rresp;
  assign mux_rlast     = s_axi_rlast;
  assign mux_rvalid    = s_axi_rvalid;
  assign s_axi_rready  = mux_rready;
  assign s_axi_awcache = 4'h0;
  assign s_axi_awprot  = 3'h0;
  assign s_axi_arcache = 4'h0;
  assign s_axi_arprot  = 3'h0;

  //--------------------------------------------------------------------------
  // AXI 2-to-1 mux : S0 = SoC DDR master,  S1 = GPU accelerator (128-bit data)
  //   arbitration : 0 = shared / round robin ,  1 = S0 highest priority
  //--------------------------------------------------------------------------
  wire [31:0] bullet_outer_debug;
  wire [11:0] disp_fifo_wlevel,disp_fifo_rlevel;
  wire [511:0] bullet_bus_debug;
  wire [2:0] display_qos;wire [95:0] debug_write_admission;
Axi_Mux u_axi_mux (
 .I_DISPLAY_QOS(display_qos),.O_DBG_ADMISSION(debug_write_admission),
      .O_DBG_BUS(bullet_bus_debug),.O_DBG_R_STATE(bullet_outer_debug),
      .Sys_Clk            (user_clk                           ),
      .Sys_Rst_N          (sys_rst                           ),
      .O_M_AW_ID          (mux_awid                          ),
      .O_M_AW_ADDR        (mux_awaddr                        ),
      .O_M_AW_LEN         (mux_awlen                         ),
      .O_M_AW_SIZE        (mux_awsize                        ),
      .O_M_AW_BURST       (mux_awburst                       ),
      .O_M_AW_LOCK        (mux_awlock                        ),
      .O_M_AW_VALID       (mux_awvalid                       ),
      .I_M_AW_READY       (mux_awready                       ),
      .O_M_W_ID           (mux_wid                           ),
      .O_M_W_DATA         (mux_wdata                         ),
      .O_M_W_LAST         (mux_wlast                         ),
      .O_M_W_STRB         (mux_wstrb                         ),
      .O_M_W_VALID        (mux_wvalid                        ),
      .I_M_W_READY        (mux_wready                        ),
      .I_M_B_ID           (mux_bid                           ),
      .I_M_B_VALID        (mux_bvalid                        ),
      .O_M_B_READY        (mux_bready                        ),
      .O_M_AR_ID          (mux_arid                          ),
      .O_M_AR_ADDR        (mux_araddr                        ),
      .O_M_AR_LEN         (mux_arlen                         ),
      .O_M_AR_SIZE        (mux_arsize                        ),
      .O_M_AR_BURST       (mux_arburst                       ),
      .O_M_AR_LOCK        (mux_arlock                        ),
      .O_M_AR_VALID       (mux_arvalid                       ),
      .I_M_AR_READY       (mux_arready                       ),
      .I_M_R_ID           (mux_rid                           ),
      .I_M_R_DATA         (mux_rdata                         ),
      .I_M_R_LAST         (mux_rlast                         ),
      .I_M_R_RESP         (mux_rresp                         ),
      .I_M_R_VALID        (mux_rvalid                        ),
      .O_M_R_READY        (mux_rready                        ),
      // ---- slave 0 : SoC DDR AXI master (128-bit, 8-bit ID) --------------
      .I_S0_AW_ID         (soc_axi_awid                      ),
      .I_S0_AW_ADDR       (soc_axi_awaddr                    ),
      .I_S0_AW_LEN        (soc_axi_awlen                     ),
      .I_S0_AW_SIZE       (soc_axi_awsize                    ),
      .I_S0_AW_BURST      (soc_axi_awburst                   ),
      .I_S0_AW_LOCK       ({1'b0, soc_axi_awlock}            ),
      .I_S0_AW_VALID      (soc_axi_awvalid                   ),
      .O_S0_AW_READY      (soc_axi_awready                   ),
      .I_S0_W_ID          (8'h00                             ),
      .I_S0_W_DATA        (soc_axi_wdata                     ),
      .I_S0_W_LAST        (soc_axi_wlast                     ),
      .I_S0_W_STRB        (soc_axi_wstrb                     ),
      .I_S0_W_VALID       (soc_axi_wvalid                    ),
      .O_S0_W_READY       (soc_axi_wready                    ),
      .O_S0_B_ID          (soc_axi_bid                       ),
      .O_S0_B_VALID       (soc_axi_bvalid                    ),
      .I_S0_B_READY       (soc_axi_bready                    ),
      .I_S0_AR_ID         (soc_axi_arid                      ),
      .I_S0_AR_ADDR       (soc_axi_araddr                    ),
      .I_S0_AR_LEN        (soc_axi_arlen                     ),
      .I_S0_AR_SIZE       (soc_axi_arsize                    ),
      .I_S0_AR_BURST      (soc_axi_arburst                   ),
      .I_S0_AR_LOCK       ({1'b0, soc_axi_arlock}            ),
      .I_S0_AR_VALID      (soc_axi_arvalid                   ),
      .O_S0_AR_READY      (soc_axi_arready                   ),
      .O_S0_R_ID          (soc_axi_rid                       ),
      .O_S0_R_DATA        (soc_axi_rdata                     ),
      .O_S0_R_LAST        (soc_axi_rlast                     ),
      .O_S0_R_RESP        (soc_axi_rresp                     ),
      .O_S0_R_VALID       (soc_axi_rvalid                    ),
      .I_S0_R_READY       (soc_axi_rready                    ),
      // ---- slave 1 : GPU accelerator (write only, 128-bit) ---------------
      .I_S1_AW_ID         (8'h00                             ),
      .I_S1_AW_ADDR       (gpu_axi_awaddr                    ),
      .I_S1_AW_LEN        (gpu_axi_awlen                     ),
      .I_S1_AW_SIZE       (gpu_axi_awsize                    ),
      .I_S1_AW_BURST      (gpu_axi_awburst                   ),
      .I_S1_AW_LOCK       (2'b00                             ),
      .I_S1_AW_VALID      (gpu_axi_awvalid                   ),
      .O_S1_AW_READY      (gpu_axi_awready                   ),
      .I_S1_W_ID          (8'h00                             ),
      .I_S1_W_DATA        (gpu_axi_wdata                     ),
      .I_S1_W_LAST        (gpu_axi_wlast                     ),
      .I_S1_W_STRB        (gpu_axi_wstrb                     ),
      .I_S1_W_VALID       (gpu_axi_wvalid                    ),
      .O_S1_W_READY       (gpu_axi_wready                    ),
      .O_S1_B_ID          (                                  ),
      .O_S1_B_VALID       (gpu_axi_bvalid                    ),
      .I_S1_B_READY       (gpu_axi_bready                    ),
      //---- S1 读通道：关卡3 显示取数 + 关卡4 Copy 经 axir_arb2 仲裁 ------
      .I_S1_AR_ID         (arb_arid                        ),
      .I_S1_AR_ADDR       (arb_araddr                      ),
      .I_S1_AR_LEN        (arb_arlen                       ),
      .I_S1_AR_SIZE       (arb_arsize                      ),
      .I_S1_AR_BURST      (arb_arburst                     ),
      .I_S1_AR_LOCK       (arb_arlock                      ),
      .I_S1_AR_VALID      (arb_arvalid                     ),
      .O_S1_AR_READY      (arb_arready                     ),
      .O_S1_R_ID          (arb_rid                         ),
      .O_S1_R_DATA        (arb_rdata                       ),
      .O_S1_R_LAST        (arb_rlast                       ),
      .O_S1_R_RESP        (arb_rresp                       ),
      .O_S1_R_VALID       (arb_rvalid                      ),
      .I_S1_R_READY       (arb_rready                      ),
      .Cfg_Arb_Type       (1'b0                              ),
      .Cfg_Cnl_Mask       (2'b11                             ),
      .O_AW_Cnl_Num       (                                  ),
      .O_W_Cnl_Num        (                                  ),
      .O_B_Cnl_Num        (                                  ),
      .O_AR_Cnl_Num       (                                  ),
      .O_R_Cnl_Num        (                                  )
  );
  
// Start of User Design top instance
//***************************************************************************
// The User design is instantiated below. The memory interface ports are
// connected to the top-level and the application interface ports are
// connected to the traffic generator module. This provides a reference
// for connecting the memory controller to system.
//***************************************************************************
always @(posedge user_clk or negedge sys_rst) begin
	if (!sys_rst)
		cnt <= 0;
    else if (cnt != CNT_INIT) 
        cnt <= cnt + 20'd1;
	else 
        cnt <= cnt;
end
assign ddr_rstn = (cnt == CNT_INIT);


generate
if (ASYN_AXI_CLK) begin
assign user_clk = axi_clk;

end else begin
assign user_clk = core_clk;
end
endgenerate
//***************************************************************************
// The traffic generation module instantiated below drives traffic (patterns)
// on the application interface of the memory controller
//***************************************************************************
//***************************************************************************

assign sys_rst       = pll_locked & user_pll_locked;

//***************************************************************************
ddr3_top                 u_ddr3_top
      (
      
    .axi_clk                (user_clk             ),
    .core_clk               (core_clk            ),
    .sdram_clk              (sdram_clk           ),  
    .rx_cal_clk             (rx_cal_clk          ),
    .tx_cal_clk             (tx_cal_clk          ),
    .tx_cal_clk_90edge      (tx_cal_clk_90edge   ),
    .rstn                   (ddr_rstn            ),      
    .pll_shift              (pll_shift           ),
    .pll_shift_sel          (pll_shift_sel       ),
    .pll_shift_ena          (pll_shift_ena       ), 
///////////////DDR BUS
    .ddr_ck_hi              (ddr_ck_hi           ),
    .ddr_ck_lo              (ddr_ck_lo           ),
    .ddr_cke                (ddr_cke             ),    
    .ddr_reset_n            (ddr_reset_n         ),
    .ddr_cs_n               (ddr_cs_n            ),
    .ddr_ras_n              (ddr_ras_n           ),
    .ddr_cas_n              (ddr_cas_n           ),
    .ddr_we_n               (ddr_we_n            ),     
    .ddr_addr               (ddr_addr            ),
    .ddr_ba                 (ddr_ba              ),

    .ddr_dqs_oe             (ddr_dqs_oe          ),
    .ddr_dqs_oe_n           (ddr_dqs_oe_n        ),
    .ddr_dq_oe              (ddr_dq_oe           ),
    .ddr_dqs_in_hi          (ddr_dqs_in_hi       ),
    .ddr_dqs_in_lo          (ddr_dqs_in_lo       ),
    .ddr_dq_in_hi           (ddr_dq_in_hi        ),
    .ddr_dq_in_lo           (ddr_dq_in_lo        ),

    .ddr_dqs_out_hi         (ddr_dqs_out_hi      ),
    .ddr_dqs_out_lo         (ddr_dqs_out_lo      ),
    .ddr_dq_out_hi          (ddr_dq_out_hi       ),
    .ddr_dq_out_lo          (ddr_dq_out_lo       ),
    
    .ddr_dm_hi              (ddr_dm_hi           ),
    .ddr_dm_lo              (ddr_dm_lo           ),
    .ddr_odt                (ddr_odt             ),

// Application interface ports
       .app_sr_req                     (1'b0),
       .app_ref_req                    (1'b0),
       .app_zq_req                     (1'b0),
       .app_sr_active                  (app_sr_active),
       .app_ref_ack                    (app_ref_ack),
       .app_zq_ack                     (app_zq_ack),

// Slave Interface Write Address Ports
       .s_axi_awid                     (s_axi_awid        ),
       .s_axi_awaddr                   (s_axi_awaddr      ),
       .s_axi_awlen                    (s_axi_awlen       ),
       .s_axi_awsize                   (s_axi_awsize      ),
       .s_axi_awburst                  (s_axi_awburst     ),
       .s_axi_awlock                   (s_axi_awlock      ),
       .s_axi_awcache                  (s_axi_awcache     ),
       .s_axi_awprot                   (s_axi_awprot      ),
       .s_axi_awqos                    (4'h0              ),
       .s_axi_awvalid                  (s_axi_awvalid     ),
       .s_axi_awready                  (s_axi_awready     ),
// Slave Interface Write Data Ports
       .s_axi_wdata                    (s_axi_wdata       ),
       .s_axi_wstrb                    (s_axi_wstrb       ),
       .s_axi_wlast                    (s_axi_wlast       ),
       .s_axi_wvalid                   (s_axi_wvalid      ),
       .s_axi_wready                   (s_axi_wready      ),
// Slave Interface Write Response Ports
       .s_axi_bid                      (s_axi_bid         ),
       .s_axi_bresp                    (s_axi_bresp       ),
       .s_axi_bvalid                   (s_axi_bvalid      ),
       .s_axi_bready                   (s_axi_bready      ),
// Slave Interface Read Address Ports
       .s_axi_arid                     (s_axi_arid        ),
       .s_axi_araddr                   (s_axi_araddr      ),
       .s_axi_arlen                    (s_axi_arlen       ),
       .s_axi_arsize                   (s_axi_arsize      ),
       .s_axi_arburst                  (s_axi_arburst     ),
       .s_axi_arlock                   (s_axi_arlock      ),
       .s_axi_arcache                  (s_axi_arcache     ),
       .s_axi_arprot                   (s_axi_arprot      ),
       .s_axi_arqos                    (4'h0              ),
       .s_axi_arvalid                  (s_axi_arvalid     ),
       .s_axi_arready                  (s_axi_arready     ),
// Slave Interface Read Data Ports
       .s_axi_rid                      (s_axi_rid         ),
       .s_axi_rdata                    (s_axi_rdata       ),
       .s_axi_rresp                    (s_axi_rresp       ),
       .s_axi_rlast                    (s_axi_rlast       ),
       .s_axi_rvalid                   (s_axi_rvalid      ),
       .s_axi_rready                   (s_axi_rready      ),
//DEBUG       
       .wrlvl_dq_check                 (wrlvl_dq_check    ) ,
       .rd_level_dqs_check             (rd_level_dqs_check) ,
       .rdlvl_shift                    (rdlvl_shift) ,
       .wrlvl_shift                    (wrlvl_shift) ,
       .init_cur_state                 (init_cur_state    ) ,
       .idelay_ld                      (idelay_ld         ) ,
       .mpr_rdlvl_dly                  (mpr_rdlvl_dly     ) ,
       .ddr_debug_port                 (ddr_debug_port    ) ,
       .cal_done                       (cal_done          ) 
       );
// End of User Design top instance

//***************************************************************************


//***************************************************************************
soc u_sapphire_soc(
    .io_asyncReset                      (!pll_locked                        ),
    .io_systemClk                       (user_clk                           ),

    //UART 0
    .system_uart_0_io_txd               (system_uart_0_io_txd               ),
    .system_uart_0_io_rxd               (system_uart_0_io_rxd               ),
    .io_memoryClk                       (user_clk                           ),
    .io_memoryReset                     (                                   ),
    .io_systemReset                     (                                   ),
    //External Memory AXI4 Interface
    .io_ddrA_aw_payload_prot            (                                  ),//(                                  ),
    .io_ddrA_aw_payload_qos             (                                  ),//(                                  ),
    .io_ddrA_aw_payload_cache           (                                  ),//(                                  ),
    .io_ddrA_aw_payload_lock            (soc_axi_awlock                     ),//(m1_axi_awlock                     ),
    .io_ddrA_aw_payload_burst           (soc_axi_awburst                    ),//(m1_axi_awburst                    ),
    .io_ddrA_aw_payload_size            (soc_axi_awsize                     ),//(m1_axi_awsize                     ),
    .io_ddrA_aw_payload_len             (soc_axi_awlen                      ),//(m1_axi_awlen                      ),
    .io_ddrA_aw_payload_region          (                                 ),//(                                  ),
    .io_ddrA_aw_payload_id              (soc_axi_awid                       ),//(m1_axi_awid                       ),
    .io_ddrA_aw_payload_addr            (soc_axi_awaddr                     ),//(m1_axi_awaddr                     ),
    .io_ddrA_aw_ready                   (soc_axi_awready                    ),//(m1_axi_awready                    ),
    .io_ddrA_aw_valid                   (soc_axi_awvalid                    ),//(m1_axi_awvalid                    ),
    .io_ddrA_w_payload_last             (soc_axi_wlast                      ),//(m1_axi_wlast                      ),
    .io_ddrA_w_ready                    (soc_axi_wready                     ),//(m1_axi_wready                     ),
    .io_ddrA_w_valid                    (soc_axi_wvalid                     ),  //(m1_axi_wvalid                     ),    
    .io_ddrA_w_payload_strb             (soc_axi_wstrb                      ),//(m1_axi_wstrb                      ),
    .io_ddrA_w_payload_data             (soc_axi_wdata                      ),//(m1_axi_wdata                      ),
    .io_ddrA_b_payload_resp             (                                 ),//(                                  ),
    .io_ddrA_b_payload_id               (soc_axi_bid                        ),//(m1_axi_bid                        ),
    .io_ddrA_b_ready                    (soc_axi_bready                     ),//(m1_axi_bready                     ),
    .io_ddrA_b_valid                    (soc_axi_bvalid                     ),//(m1_axi_bvalid                     ),
    .io_ddrA_ar_payload_prot            (                                 ),//(                                  ),
    .io_ddrA_ar_payload_qos             (                                 ),//(                                  ),
    .io_ddrA_ar_payload_cache           (                                 ),//(                                  ),
    .io_ddrA_ar_payload_region          (                                 ),//(                                  ),
    .io_ddrA_ar_payload_lock            (soc_axi_arlock                     ),//(m1_axi_arlock                     ),
    .io_ddrA_ar_payload_burst           (soc_axi_arburst                    ),//(m1_axi_arburst                    ),
    .io_ddrA_ar_payload_size            (soc_axi_arsize                     ),//(m1_axi_arsize                     ),
    .io_ddrA_ar_payload_len             (soc_axi_arlen                      ),//(m1_axi_arlen                      ),
    .io_ddrA_ar_payload_id              (soc_axi_arid                       ),//(m1_axi_arid                       ),
    .io_ddrA_ar_payload_addr            (soc_axi_araddr                     ),//(m1_axi_araddr                     ),
    .io_ddrA_ar_ready                   (soc_axi_arready                    ),//(m1_axi_arready                    ),
    .io_ddrA_ar_valid                   (soc_axi_arvalid                    ),//(m1_axi_arvalid                    ),
    .io_ddrA_r_payload_last             (soc_axi_rlast                      ),//(m1_axi_rlast                      ),
    .io_ddrA_r_payload_resp             (soc_axi_rresp                      ),//(m1_axi_rresp                      ),
    .io_ddrA_r_payload_id               (soc_axi_rid                        ),//(m1_axi_rid                        ),
    .io_ddrA_r_payload_data             (soc_axi_rdata                      ),//(m1_axi_rdata                      ),
    .io_ddrA_r_ready                    (soc_axi_rready                     ),//(m1_axi_rready                     ),
    .io_ddrA_r_valid                    (soc_axi_rvalid                     ),//(m1_axi_rvalid                     ),
     //SPI 0
    .system_spi_0_io_sclk_write         (system_spi_0_io_sclk_write         ),
    .system_spi_0_io_data_0_writeEnable (system_spi_0_io_data_0_OE ),
    .system_spi_0_io_data_0_read        (system_spi_0_io_data_0_IN        ),
    .system_spi_0_io_data_0_write       (system_spi_0_io_data_0_OUT       ),
    .system_spi_0_io_data_1_writeEnable (system_spi_0_io_data_1_OE ),
    .system_spi_0_io_data_1_read        (system_spi_0_io_data_1_IN        ),
    .system_spi_0_io_data_1_write       (system_spi_0_io_data_1_OUT       ),
    .system_spi_0_io_data_2_writeEnable (                                   ),
    .system_spi_0_io_data_2_read        (                                   ),
    .system_spi_0_io_data_2_write       (                                   ),
    .system_spi_0_io_data_3_writeEnable (                                   ),
    .system_spi_0_io_data_3_read        (                                   ),
    .system_spi_0_io_data_3_write       (                                   ),
    .system_spi_0_io_ss                 (system_spi_0_io_ss                 ),
    //APB 0
    .io_apbSlave_0_PADDR                (apb_paddr                          ),
    .io_apbSlave_0_PSEL                 (apb_psel                           ),
    .io_apbSlave_0_PENABLE              (apb_penable                        ),
    .io_apbSlave_0_PREADY               (apb_pready                         ),
    .io_apbSlave_0_PWRITE               (apb_pwrite                         ),
    .io_apbSlave_0_PWDATA               (apb_pwdata                         ),
    .io_apbSlave_0_PRDATA               (apb_prdata                         ),
    .io_apbSlave_0_PSLVERROR            (apb_pslverror                      ),

    .system_gpio_0_io_write             ( soc_gpio_OUT                      ),//,
    .system_gpio_0_io_read              ( {soc_gpio_IN[3:2], dbg_gpio_in[1:0]} ),// Stage7: bits[3:2]=KEY2/KEY1, bits[1:0]=debug probe
    .system_gpio_0_io_writeEnable       ( soc_gpio_OE                       ),//, 


    //Hard Jtag Tap
    .jtagCtrl_tck                       (jtag_inst1_TCK                     ),
    .jtagCtrl_tdi                       (jtag_inst1_TDI                     ),
    .jtagCtrl_tdo                       (jtag_inst1_TDO                     ),
    .jtagCtrl_enable                    (jtag_inst1_SEL                     ),
    .jtagCtrl_capture                   (jtag_inst1_CAPTURE                 ),
    .jtagCtrl_shift                     (jtag_inst1_SHIFT                   ),
    .jtagCtrl_update                    (jtag_inst1_UPDATE                  ),
    .jtagCtrl_reset                     (jtag_inst1_RESET                   ),

    //---- External AXI master port 0 : NOT USED ----------------------------
    //  This SoC port accepted AW/W but never returned a response and wedged the
    //  whole DDR path (the CPU runs code from DDR and froze). The GPU now writes
    //  through Axi_Mux slave port 1, directly on the DDR3 controller port.
    .io_ddrMasters_0_clk                (user_clk                           ),
    .io_ddrMasters_0_reset              (                                   ),
    .io_ddrMasters_0_aw_valid           (1'b0                               ),
    .io_ddrMasters_0_aw_ready           (                                   ),
    .io_ddrMasters_0_aw_payload_addr    (32'h0                              ),
    .io_ddrMasters_0_aw_payload_id      (4'h0                               ),
    .io_ddrMasters_0_aw_payload_region  (4'h0                               ),
    .io_ddrMasters_0_aw_payload_len     (8'h0                               ),
    .io_ddrMasters_0_aw_payload_size    (3'h0                               ),
    .io_ddrMasters_0_aw_payload_burst   (2'h0                               ),
    .io_ddrMasters_0_aw_payload_lock    (1'b0                               ),
    .io_ddrMasters_0_aw_payload_cache   (4'h0                               ),
    .io_ddrMasters_0_aw_payload_qos     (4'h0                               ),
    .io_ddrMasters_0_aw_payload_prot    (3'h0                               ),
    .io_ddrMasters_0_w_valid            (1'b0                               ),
    .io_ddrMasters_0_w_ready            (                                   ),
    .io_ddrMasters_0_w_payload_data     (32'h0                              ),
    .io_ddrMasters_0_w_payload_strb     (4'h0                               ),
    .io_ddrMasters_0_w_payload_last     (1'b0                               ),
    .io_ddrMasters_0_b_valid            (                                   ),
    .io_ddrMasters_0_b_ready            (1'b0                               ),
    .io_ddrMasters_0_b_payload_id       (                                   ),
    .io_ddrMasters_0_b_payload_resp     (                                   ),
    .io_ddrMasters_0_ar_valid           (1'b0                               ),
    .io_ddrMasters_0_ar_ready           (                                   ),
    .io_ddrMasters_0_ar_payload_addr    (32'h0                              ),
    .io_ddrMasters_0_ar_payload_id      (4'h0                               ),
    .io_ddrMasters_0_ar_payload_region  (4'h0                               ),
    .io_ddrMasters_0_ar_payload_len     (8'h0                               ),
    .io_ddrMasters_0_ar_payload_size    (3'h0                               ),
    .io_ddrMasters_0_ar_payload_burst   (2'h0                               ),
    .io_ddrMasters_0_ar_payload_lock    (1'b0                               ),
    .io_ddrMasters_0_ar_payload_cache   (4'h0                               ),
    .io_ddrMasters_0_ar_payload_qos     (4'h0                               ),
    .io_ddrMasters_0_ar_payload_prot    (3'h0                               ),
    .io_ddrMasters_0_r_valid            (                                   ),
    .io_ddrMasters_0_r_ready            (1'b1                               ),
    .io_ddrMasters_0_r_payload_data     (                                   ),
    .io_ddrMasters_0_r_payload_id       (                                   ),
    .io_ddrMasters_0_r_payload_resp     (                                   ),
    .io_ddrMasters_0_r_payload_last     (                                   )

);


// ---- Stage 7: observation-only output of px_serial (display debug page) ----
//      Purely a routed-out copy of px_serial's internal `have` flag.  It is
//      consumed ONLY by apb3_top's display debug block; no display logic reads
//      it, so the pixel path is unchanged.  Declared HERE, before both the
//      apb3_top instance (which observes it) and the u_px_serial instance
//      (which drives it), so there is no forward reference.
wire        px_have;
wire [15:0] ddr_pix565;
wire [15:0] display_pix565;
wire display_have,bullet_mode_active;
wire legacy_apb_psel,legacy_apb_pready,legacy_apb_pslverr;
wire [31:0] legacy_apb_prdata;

wire line_req_reader;
wire [31:0] line_addr_reader;
wire display_queue_overflow;
wire line_req_ax;   // declare EARLY: implicit use + later init made Efinity tie it to 0 (VDB-1002)
// ---- rtl7: runtime line-phase relock wiring ---------------------------------
//      dbg_relock_en is the ONLY functional signal this delivery adds: it runs
//      from apb3_top (DBG_CTRL bit2, 0 after reset) into px_serial.relock_en.
//      px_relock_tgl / px_relock_busy come back out of px_serial purely as
//      observation (did the relock fire / is a catch-up still running).
//      ALL THREE are declared HERE, before apb3_top (which drives one and
//      observes two) and before u_px_serial (which does the opposite), so no
//      identifier is ever used before its declaration -- the rtl6 black screen.
wire        dbg_relock_en;
wire        px_relock_tgl;
wire        px_relock_busy;
apb3_top u_apb3_top(
    .clk                                (user_clk                           ),
    .reset                              (!ddr_rstn                          ),
    .apb_paddr                          (apb_paddr                          ),
    .apb_psel                           (legacy_apb_psel                           ),
    .apb_penable                        (apb_penable                        ),
    .apb_pready                         (legacy_apb_pready                         ),
    .apb_pwrite                         (apb_pwrite                         ),
    .apb_pwdata                         (apb_pwdata                         ),
    .apb_prdata                         (legacy_apb_prdata                         ),
    .apb_pslverror                      (legacy_apb_pslverr                      ),
    .sig                                (sig                                ),

    //---- 关卡6: 双缓冲换帧握手 -------------------------------------------
    //     display_fb_sel_active 已经在顶层同步进 user_clk 域（见下面的 2 级同步）
    .display_fb_sel_req                 (gpu_fb_sel_req                     ),
    .display_fb_sel_active              (gpu_fb_sel_active                  ),

    //---- 鍏冲崱7 A-3b: 骞冲彴 GPIO锛圥S2 鎵嬫焺 + MPU6050 杞欢 bit-bang锛?-------
    .plat_gpio_IN                       (plat_gpio_IN                      ),
    .plat_gpio_OUT                      (plat_gpio_OUT                     ),
    .plat_gpio_OE                       (plat_gpio_OE                      ),

    //---- Stage 7: A-side display debug page 0x50..0x7F (PURE OBSERVATION) ----
    //     These are the ONLY connections this delivery adds to the top level,
    //     and every one of them is an INPUT to apb3_top: display_dbg watches
    //     the display path and drives nothing.
    //     `have` comes from the new OBSERVATION-ONLY output port of px_serial
    //     (u_px_serial.have -> wire px_have); connecting it here is the
    //     root-cause fix for the 5cf4726 saturation bug, where that line was
    //     deleted and the counter input was left floating so that
    //     `de && !have` degenerated into "count every active pixel"
    //     (1280/line, ~37 k per 500 us probe, 0xFFFF within milliseconds).
    //     `v_vs` is the startup-snapshot time base: display_dbg latches its
    //     boot snapshot at the 2nd vs rising edge (end of the first 2 frames).
    //     NOTHING ELSE in this file differs from 48c0a72: the hdmi_sync /
    //     px_serial / DC_FIFO resets, the reader line_req and the frame-swap
    //     path are byte-identical to the working baseline (the previous
    //     delivery's pre-warm FSM and its reset/line_req gating are GONE).
    .dispdbg_pclk                       (hdmi_tx_slow_clk                  ),
    .dispdbg_pclk_reset_n               (hdmi_rst_n                        ),
    .dispdbg_pclk_vcnt                  (v_vcnt                            ),
    .dispdbg_pclk_de                    (v_de                              ),
    .dispdbg_pclk_have                  (display_have                           ),
    .dispdbg_pclk_vs                    (v_vs                              ),
    .dispdbg_reader_arvalid             (disp_arvalid                      ),
    .dispdbg_reader_arready             (disp_arready                      ),
    .dispdbg_reader_rvalid              (disp_rvalid                       ),
    .dispdbg_reader_rready              (disp_rready                       ),
    .dispdbg_reader_busy                (disp_busy                         ),
    .dispdbg_reader_error               (disp_error | display_queue_overflow),
    .dispdbg_reader_line_req            (line_req_reader                   ),
    .dispdbg_reader_line_done           (disp_line_done                    ),
    .dispdbg_pclk_relock_tgl            (px_relock_tgl                    ),
    .dispdbg_pclk_relock_busy           (px_relock_busy                   ),
    .dispdbg_relock_en                  (dbg_relock_en                    ),

    //---- AXI4 write master (128-bit) -> Axi_Mux slave port 1 ----------------
    //     (the SoC's io_ddrMasters_0 port is NOT used: it never returned a B
    //      response and blocked the DDR path, see A_FPGA_build_guide.md)
    .m_axi_awaddr                       (gpu_axi_awaddr                     ),
    .m_axi_awlen                        (gpu_axi_awlen                      ),
    .m_axi_awsize                       (gpu_axi_awsize                     ),
    .m_axi_awburst                      (gpu_axi_awburst                    ),
    .m_axi_awvalid                      (gpu_axi_awvalid                    ),
    .m_axi_awready                      (gpu_axi_awready                    ),
    .m_axi_wdata                        (gpu_axi_wdata                      ),
    .m_axi_wstrb                        (gpu_axi_wstrb                      ),
    .m_axi_wlast                        (gpu_axi_wlast                      ),
    .m_axi_wvalid                       (gpu_axi_wvalid                     ),
    .m_axi_wready                       (gpu_axi_wready                     ),
    .m_axi_bresp                        (gpu_axi_bresp                      ),
    .m_axi_bvalid                       (gpu_axi_bvalid                     ),
    .m_axi_bready                       (gpu_axi_bready                     ),
    
    //---- 关卡4: GPU 的 AXI 读通道（gpu_copy 读源块）----------------------
    //     经 axir_arb2 与显示 reader 仲裁后接 Axi_Mux S1 读通道
    .m_axi_arid                         (gpu_rd_arid                        ),
    .m_axi_araddr                       (gpu_rd_araddr                      ),
    .m_axi_arlen                        (gpu_rd_arlen                       ),
    .m_axi_arsize                       (gpu_rd_arsize                      ),
    .m_axi_arburst                      (gpu_rd_arburst                     ),
    .m_axi_arlock                       (gpu_rd_arlock                      ),
    .m_axi_arvalid                      (gpu_rd_arvalid                     ),
    .m_axi_arready                      (gpu_rd_arready                     ),
    .m_axi_rid                          (gpu_rd_rid                         ),
    .m_axi_rdata                        (gpu_rd_rdata                       ),
    .m_axi_rlast                        (gpu_rd_rlast                       ),
    .m_axi_rresp                        (gpu_rd_rresp                       ),
    .m_axi_rvalid                       (gpu_rd_rvalid                      ),
    .m_axi_rready                       (gpu_rd_rready                      )
    
);    

//***************************************************************************


//***************************************************************************
// 关卡3 M1: HDMI 显示链路（彩条上屏）
//   color_bar_rgb (720p60 时序 + 彩条图样)
//        -> dvi_encoder (TMDS 8b/10b)
//        -> 4 组 LVDS TX 硬核 (Interface Designer 生成) -> HDMI 插座
//
//   M2 阶段把 TEST_MODE 改成 2'd3，用 i_cfg_vid 接 DDR3 取数(FIFO)；
//   M1 阶段保持 2'd2（内部彩条），先验证 PLL/LVDS/引脚这条硬件通路。
//   ⚠️ color_bar_rgb 的 de/hs/vs 比 h_cnt 慢 1 拍，M2 取数要用 de 门控。
//***************************************************************************

wire        hdmi_rst_n;
wire        video_hs;
wire        video_vs;
wire        video_de;
wire [7:0]  video_r;
wire [7:0]  video_g;
wire [7:0]  video_b;
wire [9:0]  hdmi_tmds_data0;
wire [9:0]  hdmi_tmds_data1;
wire [9:0]  hdmi_tmds_data2;
wire [9:0]  hdmi_tmds_clk;

// 像素域复位：由 PLL locked 同步出来（与 demo 同做法）
reset #(
    .IN_RST_ACTIVE  ("LOW"),
    .OUT_RST_ACTIVE ("LOW"),
    .CYCLE          (3)
) u_hdmi_rst (
    .i_arst (hdmi_tx_locked && ddr_rstn && cal_done),
    .i_clk  (hdmi_tx_slow_clk),
    .o_srst (hdmi_rst_n)
);

// 720p60 时序：H 1280+110+40+220=1650 / V 720+5+5+20=750 @74.375MHz
//====================================================================
// 关卡3 M2: DDR3 framebuffer -> HDMI
//   hdmi_sync(720p 时序 + 行请求) --toggle--> gpu_axi_reader(AXI 读)
//        -> DC_FIFO(异步) -> px_serial(128b->RGB565) -> RGB888
//        -> dvi_encoder(TMDS) -> LVDS 硬核
//
//   HDMI_SRC_DDR = 1 : 显示 DDR3 framebuffer 0x00200000（M2/M3 正式通路）
//   HDMI_SRC_DDR = 0 : 显示 color_bar_rgb 内部彩条（硬件排查用，改后重建）
//====================================================================
localparam HDMI_SRC_DDR = 1'b1;
localparam [31:0] FB_BASE   = 32'h0020_0000;   // FB0：C 的测试图/GPU 填色写这里
localparam [31:0] FB1_BASE  = 32'h0040_0000;   // FB1：关卡6 双缓冲的第二块
localparam [31:0] FB_STRIDE = 32'd2560;        // 720p RGB565：1280 * 2 字节
localparam [31:0] FB_BYTES  = 32'd2560;        // 每行字节数（必须是 16 的倍数）

// ---- 像素域：视频时序 + 行取数请求 ---------------------------------
wire        line_req_tgl;
wire [31:0] line_addr_p;
wire        v_hs, v_vs, v_de;
wire [15:0] v_hcnt, v_vcnt;
wire        v_line_start;

hdmi_sync #(
    .PREFETCH_LINES (8),
    .FB_BASE   (FB_BASE   ),
    .FB1_BASE  (FB1_BASE  ),
    .FB_STRIDE (FB_STRIDE ),
    .HACT (16'd1280), .HFP (16'd110), .HST (16'd40), .HBP (16'd220),
    .VACT (16'd720 ), .VFP (16'd5  ), .VST (16'd5 ), .VBP (16'd20 )
) u_hdmi_sync (
    .pclk         (hdmi_tx_slow_clk),
    .prst_n       (hdmi_rst_n),
    .fb_sel_req   (gpu_fb_sel_req  ),
    .fb_sel_active(fb_sel_active_p ),
    .line_req_tgl (line_req_tgl),
    .line_addr    (line_addr_p),
    .hs           (v_hs),
    .vs           (v_vs),
    .de           (v_de),
    .h_cnt        (v_hcnt),
    .v_cnt        (v_vcnt),
    .line_start   (v_line_start)
);

// ---- 跨时钟域：toggle 同步到 AXI 域 + 边沿检测 ----------------------
// ---- Stage 6: double-buffer swap handshake (clock domain crossing) -----
// dir 1: FB_CTRL[0] (user_clk) -> pixel domain, 2-FF sync inside hdmi_sync
// dir 2: fb_sel_active (pixel domain) -> user_clk, 2 FF here. Needed because
//        gpu_apb_regs compares them combinationally:
//        swap_pending = fb_sel_req ^ display_fb_sel_active, so both operands
//        must live in the same clock domain.
wire gpu_fb_sel_req;        // from apb3_top (user_clk domain)
wire fb_sel_active_p;       // from hdmi_sync (pixel clock domain)
wire gpu_fb_sel_active;     // synchronised back to user_clk, to apb3_top
reg  fb_act_s1, fb_act_s2;

always @(posedge user_clk or negedge ddr_rstn) begin
    if (!ddr_rstn) begin
        fb_act_s1 <= 1'b0;
        fb_act_s2 <= 1'b0;
    end else begin
        fb_act_s1 <= fb_sel_active_p;
        fb_act_s2 <= fb_act_s1;
    end
end
assign gpu_fb_sel_active = fb_act_s2;

reg rq_s1, rq_s2, rq_s3;
always @(posedge user_clk or negedge ddr_rstn) begin
    if(!ddr_rstn) begin rq_s1<=0;rq_s2<=0;rq_s3<=0;end
    else begin rq_s1<=line_req_tgl;rq_s2<=rq_s1;rq_s3<=rq_s2;end
end
assign line_req_ax = rq_s2 ^ rq_s3;      // 每检测到一次翻转 -> 1 拍脉冲

// ---- AXI 域：读主机 + 异步 FIFO -------------------------------------
wire         disp_fifo_full;
wire [127:0] disp_fifo_wdata;
wire         disp_fifo_wen;
wire         disp_fifo_empty;
wire [127:0] disp_fifo_rdata;
wire         disp_fifo_dataval;
wire         disp_fifo_ren;
wire         disp_busy, disp_line_done, disp_error;

// ---- 关卡4: 读通道仲裁（显示 reader 优先，copy 其次）-----------------
//   两个 reader 各自一次性只挂一个突发并在 RLAST 收尾，所以按突发切换
//   所有者不会让 R 响应错配（见 axir_arb2.v 头部说明）。
  bullet_display_subsystem u_bullet_display (
 .display_qos(display_qos),.debug_write_admission(debug_write_admission),
      .debug_legacy_pixel({14'd0,px_have,disp_fifo_empty,4'd0,disp_fifo_rlevel}),
      .debug_legacy_core({13'd0,display_queue_overflow,disp_error,disp_busy,disp_fifo_full,3'd0,disp_fifo_wlevel}),
      .debug_bus(bullet_bus_debug),.debug_outer(bullet_outer_debug),
    .clk       (user_clk      ),
    .rstn      (ddr_rstn      ),
    .pclk(hdmi_tx_slow_clk),.prstn(hdmi_rst_n),
    .paddr(apb_paddr),.psel(apb_psel[0]),.penable(apb_penable),.pwrite(apb_pwrite),
    .pwdata(apb_pwdata),.prdata(apb_prdata),.pready(apb_pready),.pslverr(apb_pslverror),
    .legacy_psel(legacy_apb_psel),.legacy_prdata(legacy_apb_prdata),
    .legacy_pready(legacy_apb_pready),.legacy_pslverr(legacy_apb_pslverr),
    .h_cnt(v_hcnt),.v_cnt(v_vcnt),.de(v_de),
    .legacy_pix(ddr_pix565),.legacy_have(px_have),
    .pix(display_pix565),.have(display_have),.mode_active(bullet_mode_active),
    // m0: 显示取数（优先）
    .m0_arid   (disp_arid     ), .m0_araddr  (disp_araddr  ), .m0_arlen   (disp_arlen  ),
    .m0_arsize (disp_arsize   ), .m0_arburst (disp_arburst ), .m0_arlock  (disp_arlock ),
    .m0_arvalid(disp_arvalid  ), .m0_arready (disp_arready ),
    .m0_rid    (disp_rid      ), .m0_rdata   (disp_rdata   ), .m0_rlast   (disp_rlast  ),
    .m0_rresp  (disp_rresp    ), .m0_rvalid  (disp_rvalid  ), .m0_rready  (disp_rready ),
    // m1: Copy 引擎（gpu_copy）
    .m2_arid   (gpu_rd_arid   ), .m2_araddr  (gpu_rd_araddr), .m2_arlen   (gpu_rd_arlen),
    .m2_arsize (gpu_rd_arsize ), .m2_arburst (gpu_rd_arburst), .m2_arlock (gpu_rd_arlock),
    .m2_arvalid(gpu_rd_arvalid), .m2_arready (gpu_rd_arready),
    .m2_rid    (gpu_rd_rid    ), .m2_rdata   (gpu_rd_rdata ), .m2_rlast   (gpu_rd_rlast),
    .m2_rresp  (gpu_rd_rresp  ), .m2_rvalid  (gpu_rd_rvalid), .m2_rready  (gpu_rd_rready),
    // 从侧 -> Axi_Mux S1 读通道
    .s_arid    (arb_arid      ), .s_araddr   (arb_araddr   ), .s_arlen    (arb_arlen   ),
    .s_arsize  (arb_arsize    ), .s_arburst  (arb_arburst  ), .s_arlock   (arb_arlock  ),
    .s_arvalid (arb_arvalid   ), .s_arready  (arb_arready  ),
    .s_rid     (arb_rid       ), .s_rdata    (arb_rdata    ), .s_rlast    (arb_rlast   ),
    .s_rresp   (arb_rresp     ), .s_rvalid   (arb_rvalid   ), .s_rready   (arb_rready  )
);

display_req_queue u_display_req_queue (
    .clk(user_clk), .rstn(ddr_rstn),
    .line_req(line_req_ax), .line_addr(line_addr_p),
    .reader_busy(disp_busy), .reader_req(line_req_reader),
    .reader_addr(line_addr_reader), .overflow(display_queue_overflow)
);

gpu_axi_reader u_disp_reader (
    .aclk         (user_clk        ),
    .aresetn      (ddr_rstn        ),
    .line_req     (line_req_reader ),
    .line_base    (line_addr_reader),
    .line_bytes   (FB_BYTES        ),
    .busy         (disp_busy       ),
    .line_done    (disp_line_done  ),
    .error        (disp_error      ),
    .fifo_full    (disp_fifo_full  ),
    .fifo_wdata   (disp_fifo_wdata ),
    .fifo_wen     (disp_fifo_wen   ),
    .m_axi_arid   (disp_arid       ),
    .m_axi_araddr (disp_araddr     ),
    .m_axi_arlen  (disp_arlen      ),
    .m_axi_arsize (disp_arsize     ),
    .m_axi_arburst(disp_arburst    ),
    .m_axi_arlock (disp_arlock     ),
    .m_axi_arvalid(disp_arvalid    ),
    .m_axi_arready(disp_arready    ),
    .m_axi_rid    (disp_rid        ),
    .m_axi_rdata  (disp_rdata      ),
    .m_axi_rlast  (disp_rlast      ),
    .m_axi_rresp  (disp_rresp      ),
    .m_axi_rvalid (disp_rvalid     ),
    .m_axi_rready (disp_rready     )
);

DC_FIFO #(
    .FIFO_MODE  ("Normal"),
    .DATA_WIDTH (128),
    .FIFO_DEPTH (2048)
) u_disp_fifo (
    .Reset   (~ddr_rstn      ),
    .WrClk   (user_clk       ),
    .WrEn    (disp_fifo_wen  ),
    .WrDNum  (disp_fifo_wlevel),
    .WrFull  (disp_fifo_full ),
    .WrData  (disp_fifo_wdata),
    .RdClk   (hdmi_tx_slow_clk),
    .RdEn    (disp_fifo_ren  ),
    .RdData  (disp_fifo_rdata),
    .RdDNum  (disp_fifo_rlevel),
    .RdEmpty (disp_fifo_empty),
    .DataVal (disp_fifo_dataval)
);

// ---- 像素域：128bit -> RGB565 ----------------------------------------

wire        ddr_underrun;

px_serial u_px_serial (
    .pclk         (hdmi_tx_slow_clk),
    .prst_n       (hdmi_rst_n),
    .de           (v_de),
    .line_start   (v_line_start),
    .fifo_dout    (disp_fifo_rdata),
    .fifo_empty   (disp_fifo_empty),
    .fifo_dataval (disp_fifo_dataval),
    .fifo_ren     (disp_fifo_ren),
    .pix          (ddr_pix565),
    .underrun     (ddr_underrun),
    .have         (px_have),         // OBSERVATION ONLY - new port, no logic
    // rtl7: DEFAULT-OFF runtime line-phase relock.  With relock_en = 0 this
    //      instance is bit-identical to the rtl6 revision (see px_serial.v).
    .relock_en    (dbg_relock_en),
    .relock_tgl   (px_relock_tgl),
    .relock_busy  (px_relock_busy)
);

// RGB565 -> RGB888（低位补高位）
wire [7:0] ddr_r8 = {display_pix565[15:11], display_pix565[15:13]};
wire [7:0] ddr_g8 = {display_pix565[10:5],  display_pix565[10:9]};
wire [7:0] ddr_b8 = {display_pix565[4:0],   display_pix565[4:2]};

// ---- 备用数据源：内部彩条（HDMI_SRC_DDR=0 时用）---------------------
wire [7:0] bar_r, bar_g, bar_b;
wire       bar_hs, bar_vs, bar_de;

color_bar_rgb #(
    .HS_POLORY      (1'b1       ),
    .VS_POLORY      (1'b1       ),
    .SYMBOL_WIDTH   (8          ),
    .SYMBOL_NUM     (3          ),
    .PAR_PIXEL_NUM  (1          ),
    .HFP            (13'd110    ),
    .HST            (13'd40     ),
    .HACT           (13'd1280   ),
    .HBP            (13'd220    ),
    .VFP            (13'd5      ),
    .VST            (13'd5      ),
    .VACT           (13'd720    ),
    .VBP            (13'd20     ),
    .TEST_MODE      (2'd2       )
) u_color_bar_rgb (
    .clk        (hdmi_tx_slow_clk),
    .rst_n      (hdmi_rst_n),
    .hs         (bar_hs),
    .vs         (bar_vs),
    .de         (bar_de),
    .o_vid_data ({bar_r, bar_g, bar_b})
);

// ---- 数据源选择 -> TMDS ---------------------------------------------
assign video_hs = HDMI_SRC_DDR ? v_hs   : bar_hs;
assign video_vs = HDMI_SRC_DDR ? v_vs   : bar_vs;
assign video_de = HDMI_SRC_DDR ? v_de   : bar_de;
assign video_r  = HDMI_SRC_DDR ? ddr_r8 : bar_r;
assign video_g  = HDMI_SRC_DDR ? ddr_g8 : bar_g;
assign video_b  = HDMI_SRC_DDR ? ddr_b8 : bar_b;

dvi_encoder u_dvi_encoder (
    .pixelclk   (hdmi_tx_slow_clk),
    .rstin      (~hdmi_rst_n),
    .blue_din   (video_b),
    .green_din  (video_g),
    .red_din    (video_r),
    .hsync      (video_hs),
    .vsync      (video_vs),
    .de         (video_de),
    .tmds_data0 (hdmi_tmds_data0),
    .tmds_data1 (hdmi_tmds_data1),
    .tmds_data2 (hdmi_tmds_data2),
    .tmds_clk   (hdmi_tmds_clk)
);

assign tmds_data0_TX_OE  = 1'b1;
assign tmds_data1_TX_OE  = 1'b1;
assign tmds_data2_TX_OE  = 1'b1;
assign tmds_clk_TX_OE    = 1'b1;
assign tmds_data0_TX_RST = 1'b0;
assign tmds_data1_TX_RST = 1'b0;
assign tmds_data2_TX_RST = 1'b0;
assign tmds_clk_TX_RST   = 1'b0;

// 输出取反：Efinity LVDS 串行器的极性约定（demo 同款做法，别去掉）
assign tmds_clk_o   = ~hdmi_tmds_clk;
assign tmds_data0_o = ~hdmi_tmds_data0;
assign tmds_data1_o = ~hdmi_tmds_data1;
assign tmds_data2_o = ~hdmi_tmds_data2;

//***************************************************************************

endmodule
