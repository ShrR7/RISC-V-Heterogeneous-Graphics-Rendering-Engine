#!/usr/bin/env bash
set -euo pipefail
repo_root=$(cd "$(dirname "$0")/../.." && pwd)
project="$repo_root/Ti60F225_DemoBoard_v4/08_ti60f225_soc_demo/09_Ti60F225_hardjtag_demo/par/ddr_demo_ti60"
build_dir=$(mktemp -d)
trap 'rm -rf "$build_dir"' EXIT
iverilog -g2012 -Wall -s tb_platform_uart_rx -I "$project/src" -o "$build_dir/test.vvp" \
    "$repo_root/gpu_accelerator/sim/tb_platform_uart_rx.v" \
    "$project/src/Interrupt.v" "$project/src/platform_gpio.v" \
    "$project/src/platform_uart_rx.v" "$project/src/display_dbg.v" \
    "$project/src/gpu_apb_regs.v" "$project/src/gpu_top.v" \
    "$project/src/gpu_fill.v" "$project/src/gpu_copy.v" "$project/src/gpu_bitblt.v" \
    "$project/src/gpu_axi_master.v" "$project/src/gpu_axi_reader.v"
vvp "$build_dir/test.vvp"
