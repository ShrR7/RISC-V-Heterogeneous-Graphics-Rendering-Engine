`timescale 1ns/1ps

module tb_platform_uart_rx;
    reg clk = 0;
    always #5 clk = ~clk;
    reg reset = 1;
    reg [15:0] paddr = 0;
    reg psel = 0, penable = 0, pwrite = 0;
    reg [31:0] pwdata = 0;
    wire [31:0] prdata;
    wire pready, pslverr;
    reg [7:0] pins = 8'hFF;
    wire [7:0] pin_oe;
    integer checks = 0;
    integer byte_index;
    reg [31:0] value;

    apb3_top dut (
        .clk(clk), .reset(reset), .apb_paddr(paddr), .apb_psel(psel),
        .apb_penable(penable), .apb_pwrite(pwrite), .apb_pwdata(pwdata),
        .apb_prdata(prdata), .apb_pready(pready), .apb_pslverror(pslverr),
        .plat_gpio_IN(pins), .plat_gpio_OE(pin_oe),
        .display_fb_sel_active(1'b0), .dispdbg_pclk(clk),
        .dispdbg_pclk_reset_n(~reset), .dispdbg_pclk_vcnt(16'd0),
        .dispdbg_pclk_de(1'b0), .dispdbg_pclk_have(1'b0),
        .dispdbg_pclk_vs(1'b0), .dispdbg_pclk_relock_tgl(1'b0),
        .dispdbg_pclk_relock_busy(1'b0), .dispdbg_reader_arvalid(1'b0),
        .dispdbg_reader_arready(1'b0), .dispdbg_reader_rvalid(1'b0),
        .dispdbg_reader_rready(1'b0), .dispdbg_reader_busy(1'b0),
        .dispdbg_reader_error(1'b0), .dispdbg_reader_line_req(1'b0),
        .dispdbg_reader_line_done(1'b0), .m_axi_awready(1'b0),
        .m_axi_wready(1'b0), .m_axi_bresp(2'd0), .m_axi_bvalid(1'b0),
        .m_axi_arready(1'b0), .m_axi_rid(8'd0), .m_axi_rdata(128'd0),
        .m_axi_rlast(1'b0), .m_axi_rresp(2'd0), .m_axi_rvalid(1'b0)
    );
    defparam dut.u_platform_uart_rx.CLOCK_HZ = 1843200;

    reg real_rx = 1;
    reg real_sel = 0, real_enable = 0;
    reg [15:0] real_addr = 16'h0904;
    wire [31:0] real_data;
    platform_uart_rx real_baud (
        .clk(clk), .reset(reset), .rx(real_rx), .paddr(real_addr),
        .psel(real_sel), .penable(real_enable), .pwrite(1'b0),
        .pwdata(32'd0), .prdata(real_data), .sel(), .pready(), .pslverr()
    );

    task check;
        input condition;
        input [511:0] label;
        begin
            checks = checks + 1;
            if (condition !== 1'b1) $fatal(1, "%0s at %0t", label, $time);
        end
    endtask

    task apb_read;
        input [15:0] address;
        output [31:0] data;
        begin
            @(negedge clk);
            paddr = address; psel = 1; penable = 0; pwrite = 0;
            @(negedge clk);
            penable = 1;
            #1;
            data = prdata;
            check(pready && !pslverr, "APB zero wait");
            if (address >= 16'h0900 && address <= 16'h091F)
                check(dut.uart_sel && !dut.gpu_sel && !dut.plat_sel && !dut.dispdbg_sel,
                      "UART exclusive decode");
            @(negedge clk);
            psel = 0; penable = 0;
        end
    endtask

    task apb_write;
        input [15:0] address;
        input [31:0] data;
        begin
            @(negedge clk);
            paddr = address; pwdata = data; psel = 1; penable = 0; pwrite = 1;
            @(negedge clk);
            penable = 1;
            @(negedge clk);
            psel = 0; penable = 0; pwrite = 0;
        end
    endtask

    task send_byte;
        input [7:0] data;
        input integer bit_ns;
        input good_stop;
        integer bit_index;
        begin
            pins[6] = 0;
            #(bit_ns);
            for (bit_index = 0; bit_index < 8; bit_index = bit_index + 1) begin
                pins[6] = data[bit_index];
                #(bit_ns);
            end
            pins[6] = good_stop;
            #(bit_ns);
        end
    endtask

    task expect_byte;
        input [7:0] data;
        begin
            apb_read(16'h0904, value);
            check(value == (32'h80000000 | data), "FIFO ordered byte/VALID");
        end
    endtask

    task send_real_byte;
        input [7:0] data;
        input integer bit_ns;
        integer bit_index;
        begin
            #3;
            real_rx = 0;
            #(bit_ns);
            for (bit_index = 0; bit_index < 8; bit_index = bit_index + 1) begin
                real_rx = data[bit_index];
                #(bit_ns);
            end
            real_rx = 1;
            #(bit_ns);
        end
    endtask

    initial begin
        #10000000;
        $fatal(1, "timeout");
    end

    initial begin
        repeat (5) @(negedge clk);
        reset = 0;
        apb_read(16'h0900, value); check(value == 32'h55365258, "UART ID");
        apb_read(16'h0918, value); check(value == 115200, "baud register");
        apb_read(16'h0908, value); check(value == 0, "empty at reset");
        apb_read(16'h0904, value); check(value == 0, "empty read no pop");
        apb_read(16'h091C, value); check(value == 32'h00010009, "revision/status idle");
        apb_read(16'h004C, value); check(value == 32'h504C4154, "GPIO ID unchanged");
        apb_read(16'h0024, value); check(value == 32'h47505531, "GPU ID unchanged");
        apb_write(16'h0048, 255);
        apb_read(16'h0048, value); check(value == 191 && pin_oe == 191, "GPIO6 input only");
        apb_write(16'h0048, 0);

        #3;
        pins[6] = 0; #30; pins[6] = 1; #1800;
        apb_read(16'h0908, value); check(value == 0, "false start rejected");
        apb_read(16'h0910, value); check(value == 0, "false start no frame error");

        #7;
        for (byte_index = 0; byte_index < 256; byte_index = byte_index + 1)
            send_byte(byte_index, 160, 1);
        apb_read(16'h0908, value); check(value == 256, "all 256 slots usable");
        apb_read(16'h091C, value); check(value[1:0] == 2, "full status");
        send_byte(8'h55, 160, 1);
        send_byte(8'hAA, 160, 1);
        apb_read(16'h090C, value); check(value == 2, "drop newest overflow count");
        apb_read(16'h0908, value); check(value == 256, "overflow preserves FIFO");

        fork
            send_byte(8'hA6, 160, 1);
            begin
                wait (dut.u_platform_uart_rx.rx_valid);
                paddr = 16'h0904; psel = 1; penable = 0; pwrite = 0;
                @(negedge clk);
                penable = 1;
                #1;
                check(prdata == 32'h80000000, "full simultaneous pop old head");
                @(negedge clk);
                psel = 0; penable = 0;
            end
        join
        apb_read(16'h0908, value); check(value == 256, "full push/pop conserves count");
        apb_read(16'h090C, value); check(value == 2, "full push/pop no overflow");
        for (byte_index = 1; byte_index < 256; byte_index = byte_index + 1)
            expect_byte(byte_index);
        expect_byte(8'hA6);
        apb_read(16'h0904, value); check(value == 0, "FIFO drained");

        fork
            send_byte(8'hD2, 160, 1);
            begin
                wait (dut.u_platform_uart_rx.rx_valid);
                paddr = 16'h0904; psel = 1; penable = 0; pwrite = 0;
                @(negedge clk);
                penable = 1;
                #1; check(prdata == 0, "empty read concurrent with first push");
                @(negedge clk);
                psel = 0; penable = 0;
            end
        join
        @(negedge clk);
        paddr = 16'h0904; psel = 1; penable = 0;
        repeat (5) @(negedge clk);
        check(dut.u_platform_uart_rx.fifo_count == 1, "setup phase does not pop");
        psel = 0; penable = 1;
        repeat (3) @(negedge clk);
        check(dut.u_platform_uart_rx.fifo_count == 1, "unselected access does not pop");
        penable = 0;
        expect_byte(8'hD2);
        send_byte(8'h4B, 160, 1);
        apb_write(16'h0904, 32'h12345678);
        apb_read(16'h0908, value); check(value == 1, "DATA writes do not pop");
        apb_read(16'h0905, value); check(value == 0, "unaligned read returns zero");
        apb_read(16'h0908, value); check(value == 1, "unaligned read does not pop");
        expect_byte(8'h4B);

        send_byte(8'h81, 156, 1); expect_byte(8'h81);
        send_byte(8'h7E, 164, 1); expect_byte(8'h7E);
        send_byte(8'hA5, 160, 0);
        #8000;
        apb_read(16'h0910, value); check(value == 1, "bad stop/break counted once");
        apb_read(16'h0908, value); check(value == 0, "bad frame discarded");
        pins[6] = 1; #500;
        send_byte(8'h3C, 160, 1); expect_byte(8'h3C);
        send_byte(8'h00, 160, 1);
        apb_write(16'h0914, 1);
        apb_read(16'h0908, value); check(value == 0, "flush FIFO");
        apb_read(16'h0910, value); check(value == 1, "flush preserves stats");
        apb_write(16'h0914, 2);
        apb_read(16'h0910, value); check(value == 0, "clear frame errors");
        apb_read(16'h090C, value); check(value == 0, "clear overflow errors");

        @(negedge clk);
        dut.u_platform_uart_rx.frame_error_count = 32'hFFFFFFFE;
        send_byte(8'h80, 160, 0);
        pins[6] = 1; #500;
        send_byte(8'h00, 160, 0);
        pins[6] = 1; #500;
        apb_read(16'h0910, value); check(value == 32'hFFFFFFFF, "frame counter saturates");
        apb_write(16'h0914, 3);

        for (byte_index = 0; byte_index < 256; byte_index = byte_index + 1)
            send_byte(byte_index ^ 8'hA5, 160, 1);
        @(negedge clk);
        dut.u_platform_uart_rx.overflow_count = 32'hFFFFFFFE;
        send_byte(8'h20, 160, 1);
        send_byte(8'h30, 160, 1);
        apb_read(16'h090C, value); check(value == 32'hFFFFFFFF, "overflow counter saturates");
        apb_write(16'h0914, 3);

        fork
            begin
                send_real_byte(8'h00, 8681);
                send_real_byte(8'hFF, 8507);
                send_real_byte(8'hA5, 8855);
            end
            begin
                send_byte(8'h55, 160, 1); expect_byte(8'h55);
                send_byte(8'hFE, 160, 1); expect_byte(8'hFE);
            end
        join
        repeat (4) @(negedge clk);
        check(real_baud.fifo_count == 3 && real_baud.frame_error_count == 0,
              "100MHz/115200 independent RX with +/-2 percent sender");
        real_sel = 1;
        @(negedge clk); real_enable = 1;
        #1; check(real_data == 32'h80000000, "real baud first byte");
        @(negedge clk); real_enable = 0;
        @(negedge clk); real_enable = 1;
        #1; check(real_data == 32'h800000FF, "real baud second byte");
        @(negedge clk); real_enable = 0;
        @(negedge clk); real_enable = 1;
        #1; check(real_data == 32'h800000A5, "real baud third byte");
        @(negedge clk); real_enable = 0; real_sel = 0;

        fork
            send_byte(8'h42, 160, 1);
            begin
                #600;
                reset = 1;
                repeat (4) @(negedge clk);
                pins[6] = 1;
                repeat (4) @(negedge clk);
                reset = 0;
            end
        join
        pins[6] = 1;
        repeat (200) @(negedge clk);
        apb_write(16'h0914, 3);
        send_byte(8'hC3, 160, 1); expect_byte(8'hC3);
        check(real_baud.fifo_count == 0, "reset clears independent FIFO");
        $display("PASS platform UART RX: %0d checks, 256-byte FIFO, real APB/GPU/GPIO wrapper", checks);
        $finish;
    end
endmodule
