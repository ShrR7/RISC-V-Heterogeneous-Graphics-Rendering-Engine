# ============================================================================
#  build_flow.ps1 : full Efinity build flow for ddr_demo_ti60
#    synthesis(elab) -> debug-core merge -> Interface Designer -> P&R -> bitstream
#
#  Usage:  Set-ExecutionPolicy -Scope Process Bypass -Force
#          & '<this file>'
#  The script locates the project from its own folder, so it works in any copy
#  of the project tree.
# ============================================================================
$ErrorActionPreference = 'Continue'
$proj = $PSScriptRoot
Set-Location $proj

$env:EFINITY_HOME = 'C:/Efinity'
$env:EFXPT_HOME   = 'C:/Efinity/pt'
$env:EFXPGM_HOME  = 'C:/Efinity/pgm'
$env:EFXDBG_HOME  = 'C:/Efinity/debugger'
$env:PYTHONHOME   = 'C:/Efinity/python311'
$env:PATH         = 'C:\Efinity\bin;' + $env:PATH

$map = 'C:\Efinity\bin\efx_map.exe'
$pnr = 'C:\Efinity\bin\efx_pnr.exe'
$pgm = 'C:\Efinity\bin\efx_pgm.exe'
$py  = 'C:\Efinity\python311\bin\python.exe'

$syn = @(
 '--allow-const-ram-index','0','--blackbox-error','1','--blast_const_operand_adders','1',
 '--bram_output_regs_packing','1','--create-onehot-fsms','0','--fanout-limit','0',
 '--hdl-compile-unit','1','--infer-clk-enable','3','--infer-sync-set-reset','1',
 '--max_ram','-1','--max_mult','-1','--min-sr-fanout','0','--min-ce-fanout','0',
 '--mult-decomp-retime','0','--mode','speed','--operator-sharing','0','--optimize-adder-tree','0',
 '--optimize-zero-init-rom','1','--retiming','1','--seq_opt','1','--seq-opt-sync-only','0',
 '--dsp-input-regs-packing','1','--dsp-output-regs-packing','1','--dsp-mac-packing','1',
 '--insert-carry-skip','0','--pack-luts-to-comb4','0','--mult-auto-pipeline','0',
 '--use-logic-for-small-mem','64','--use-logic-for-small-rom','64','--bram-push-tco-outreg','0',
 '--hdl-loop-limit','20000','--enable-mark-debug','1','--max-bit-blast-mem-size','10240',
 '--peri-syn-instantiation','0','--peri-syn-inference','0','--ram-decomp-mode','0','--max_threads','-1',
 '--I',$proj,'--I',"$proj\ip\soc",'--I',"$proj\src",'--I',"$proj\src\hdmi",'--family','Titanium','--device','Ti60F225'
)

# A stale bitstream must never survive a failed build: delete the previous
# outputs first, so "no .bit file" unambiguously means "this build did not
# finish". (Learned the hard way: a step can fail while an old bitstream from a
# previous stage is still sitting in outflow/ and looks brand new to everyone
# who only checks the file's presence.)
Remove-Item "$proj\outflow\ddr_demo_ti60.bit", "$proj\outflow\ddr_demo_ti60.hex" -Force -ErrorAction SilentlyContinue

Write-Output '===== [1/5] synthesis (elaborated vdb) ====='
& $map @syn '--root','ddr3_example_top','--vdb',"$proj\outflow\ddr_demo_ti60.elab.vdb", `
  '--write-efx-verilog',"$proj\outflow\ddr_demo_ti60.map.v", `
  '--write-premap-module',"$proj\outflow\ddr_demo_ti60.elab.vdb", `
  '--gen-mark-debug-json','0','--work-dir',"$proj\work_syn",'--output-dir',"$proj\outflow", `
  '--project-xml',"$proj\ddr_demo_ti60.xml", '--binary-db',"$proj\outflow\ddr_demo_ti60.vdb"
if ($LASTEXITCODE -ne 0) { Write-Output '*** STEP 1 FAILED ***'; exit 1 }

Write-Output '===== [2/5] debug_top map ====='
& $map @syn '--keep-gclk-in-module','1','--root','edb_top','--v',"$proj\work_dbg\debug_top.v", `
 '--write-postmap-module',"$proj\work_dbg\debug_top.post.vdb",'--gen-mark-debug-json','0', `
 '--work-dir',"$proj\work_dbg",'--output-dir',"$proj\outflow"
if ($LASTEXITCODE -ne 0) { Write-Output '*** STEP 2 FAILED ***'; exit 1 }

Write-Output '===== [3/5] merge user design + debugger cores ====='
& $map @syn '--gen-mark-debug-json','0','--root','ddr3_example_top', `
 '--vdb',"$proj\outflow\ddr_demo_ti60.elab.vdb",'--vdb',"$proj\work_dbg\debug_top.post.vdb", `
 '--write-efx-verilog',"$proj\work_dbg\ddr_demo_ti60.dbg.map.v", `
 '--binary-db',"$proj\work_dbg\ddr_demo_ti60.dbg.vdb", `
 '--merge_vdbs=1','--conn',"$proj\debug_profile.wizard.json", `
 '--work-dir',"$proj\work_dbg",'--output-dir',"$proj\outflow"
if ($LASTEXITCODE -ne 0) { Write-Output '*** STEP 3 FAILED ***'; exit 1 }
Copy-Item "$proj\work_dbg\ddr_demo_ti60.dbg.vdb" "$proj\outflow\ddr_demo_ti60.dbg.vdb" -Force

Write-Output '===== [4/5] interface designer (pins / lpf / interface.csv) ====='
& $py 'C:\Efinity\scripts\efx_pt_jtag_util.py' --device 'Ti60F225' --project 'ddr_demo_ti60' `
 --design_file "$proj\ddr_demo_ti60.peri.xml" --action 'add' --jtag_user 'JTAG_USER2' `
 --output "$proj\ddr_demo_ti60.dbg.peri.xml"
if ($LASTEXITCODE -ne 0) { Write-Output '*** STEP 4a FAILED ***'; exit 1 }
& $py 'C:\Efinity\scripts\efx_run_pt_unified.py' 'ddr_demo_ti60.dbg' 'Titanium' 'Ti60F225' --peri_file 'ddr_demo_ti60.dbg.peri.xml'
if ($LASTEXITCODE -ne 0) { Write-Output '*** STEP 4b FAILED ***'; exit 1 }
if (-not (Test-Path "$proj\outflow\ddr_demo_ti60.interface.csv")) { Write-Output '*** interface.csv missing ***'; exit 1 }
Remove-Item "$proj\ddr_demo_ti60.dbg.peri.xml" -Force -ErrorAction SilentlyContinue

Write-Output '===== [5/5] place and route + bitstream ====='
& $pnr --prj "$proj\ddr_demo_ti60.xml" --circuit 'ddr_demo_ti60' --family 'Titanium' --device 'Ti60F225' `
 --operating_conditions 'I3' --pack --place --route `
 --vdb_file "$proj\outflow\ddr_demo_ti60.dbg.vdb" --use_vdb_file 'on' `
 --place_file "$proj\outflow\ddr_demo_ti60.place" --route_file "$proj\outflow\ddr_demo_ti60.troutingtraces" `
 --sdc_file "$proj\sdc\ddr3.sdc" --sync_file "$proj\outflow\ddr_demo_ti60.interface.csv" `
 --seed '1' --placer_effort_level '2' --max_threads '-1' --beneficial_skew 'on' --print_critical_path '10' `
 --work_dir "$proj\work_pnr" --output_dir "$proj\outflow" --timing_analysis 'on'
if ($LASTEXITCODE -ne 0) { Write-Output '*** PNR FAILED ***'; exit 1 }

& $pgm --source "$proj\work_pnr\ddr_demo_ti60.lbf" --dest "$proj\outflow\ddr_demo_ti60.hex" `
 --device 'Ti60F225' --family 'Titanium' --periph "$proj\outflow\ddr_demo_ti60.lpf" `
 --interface_designer_settings "$proj\outflow\ddr_demo_ti60_or.ini" `
 --enable_external_master_clock 'off' --oscillator_clock_divider 'DIV8' --active_capture_clk_edge 'negedge' `
 --spi_low_power_mode 'on' --io_weak_pullup 'on' --enable_roms 'smart' --mode 'active' --width '1' `
 --release_tri_then_reset 'on' --bitstream_compression 'on' --jtag_usercode '0xFFFFFFFF'
if ($LASTEXITCODE -ne 0) { Write-Output '*** BITSTREAM FAILED ***'; exit 1 }

Write-Output '===== BUILD FLOW COMPLETE ====='
Write-Output "  bitstream : $proj\outflow\ddr_demo_ti60.bit"
Write-Output "  timing    : $proj\outflow\ddr_demo_ti60.timing.rpt  (check Setup/Hold all positive)"
