// Team A: preserve ordered line descriptors while the B reader is busy.
// The reader and GPU RTL are unchanged. No FIFO reset or line dropping is
// used for recovery. Overflow is sticky and exposed as display reader error.
module display_req_queue (
    input wire clk, input wire rstn,
    input wire line_req, input wire [31:0] line_addr,
    input wire reader_busy,
    output reg reader_req, output reg [31:0] reader_addr,
    output reg overflow
);
    reg [31:0] addresses [0:15];
    reg [3:0] head, tail;
    reg [4:0] count;
    wire take = count!=0 && !reader_busy && !reader_req;
    wire put = line_req && (count<16 || take);
    always @(posedge clk or negedge rstn) begin
        if(!rstn) begin
            head<=0;tail<=0;count<=0;reader_req<=0;reader_addr<=0;overflow<=0;
        end else begin
            reader_req<=0;
            if(line_req && !put) overflow<=1;
            if(put) begin addresses[tail]<=line_addr;tail<=tail+4'd1;end
            if(take) begin
                reader_addr<=addresses[head];reader_req<=1;
                head<=head+4'd1;
            end
            case({put,take})
                2'b10:count<=count+5'd1;
                2'b01:count<=count-5'd1;
                default:count<=count;
            endcase
        end
    end
endmodule
