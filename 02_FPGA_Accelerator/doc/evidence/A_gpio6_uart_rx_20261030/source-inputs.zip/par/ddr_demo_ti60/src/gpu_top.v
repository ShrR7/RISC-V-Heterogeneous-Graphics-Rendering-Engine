//============================================================================
// File        : gpu_top.v
// Description : GPU Accelerator top-level wrapper
//               (Stage 7: Fill + Copy + BitBlt/ColorKey + ALPHA-BLEND)
// Team        : Team B (RTL Accelerator)
//
// Stage 7 changes:
//   - CTRL bit[8] (alpha_en) + ALPHA(0x30, 0~32) routed to gpu_bitblt:
//     op=10 with bit[8]=1 blends every non-key pixel against the destination
//     line (RMW: the engine AXI-reads the dst line into a second buffer).
//     bit[8]=0 keeps the Stage 5 frozen color-key behaviour bit-identical.
// Stage 6 changes:
//   - New display swap handshake ports: display_fb_sel_req (out, from
//     FB_CTRL[0]) and display_fb_sel_active (in, from A's display path).
//     A latches the request at a safe frame boundary in hdmi_sync and drives
//     active back; software observes FB_STATUS(0x2C). If the display path is
//     not connected yet, A must tie display_fb_sel_active to 1'b0 (power-on
//     default: show FB0, no pending swap).
//
// Stage 5 changes:
//   - CTRL.op_type now dispatches: 00 -> gpu_fill, 01 -> gpu_copy,
//     10 -> gpu_bitblt. op 11 is a reserved no-op: no engine starts,
//     busy stays 0.
//   - gpu_bitblt (color-keyed sprite blit) shares BOTH channels: its pixel
//     stream joins the fill/copy mux into the shared gpu_axi_master, and its
//     AXI read bursts share the read channel with gpu_copy through a mux
//     keyed on the registered active op (copy and bitblt are mutually
//     exclusive, so a simple op-keyed mux is safe - no new external ports,
//     A's wiring and the axir_arb2 arbiter are untouched).
//   - COLOR(0x20) is routed to gpu_bitblt as color_key while op=10
//     (Stage 5 protocol amendment, see interface_spec.md).
//
// Stage 4 notes (unchanged behaviour):
//   - gpu_copy reads DDR3 through the AXI read channel exposed here; A
//     arbitrates it with the display gpu_axi_reader on Axi_Mux S1
//     (see port_description.md, axir_arb2.v).
//   - STATUS.error reflects the active read-engine's error flag
//     (fill has no error source).
//============================================================================

`include "gpu_pkg.vh"

module gpu_top (
    input  wire        pclk,
    input  wire        presetn,
    input  wire [31:0] paddr,
    input  wire        psel,
    input  wire        penable,
    input  wire        pwrite,
    input  wire [31:0] pwdata,
    output wire [31:0] prdata,
    output wire        pready,
    output wire        pslverr,

    // ---- AXI4 write channel (shared: gpu_fill / gpu_copy / gpu_bitblt) ----
    output wire [31:0]  m_axi_awaddr,
    output wire [7:0]   m_axi_awlen,
    output wire [2:0]   m_axi_awsize,
    output wire [1:0]   m_axi_awburst,
    output wire         m_axi_awvalid,
    input  wire         m_axi_awready,
    output wire [127:0] m_axi_wdata,
    output wire [15:0]  m_axi_wstrb,
    output wire         m_axi_wlast,
    output wire         m_axi_wvalid,
    input  wire         m_axi_wready,
    input  wire [1:0]   m_axi_bresp,
    input  wire         m_axi_bvalid,
    output wire         m_axi_bready,

    // ---- AXI4 read channel (gpu_copy / gpu_bitblt) ------------------------
    output wire [7:0]   m_axi_arid,
    output wire [31:0]  m_axi_araddr,
    output wire [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output wire [1:0]   m_axi_arlock,
    output wire         m_axi_arvalid,
    input  wire         m_axi_arready,
    input  wire [7:0]   m_axi_rid,
    input  wire [127:0] m_axi_rdata,
    input  wire         m_axi_rlast,
    input  wire [1:0]   m_axi_rresp,
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready,

    // ---- Stage 6: double-buffer display swap handshake (to A's display) --
    output wire         display_fb_sel_req,    // FB_CTRL[0]: 0=FB0, 1=FB1
    input  wire         display_fb_sel_active  // tie to 1'b0 if not connected
);

    wire        engine_start;
    wire [1:0]  engine_op;
    wire        engine_busy, engine_done, engine_error;
    wire [31:0] reg_dst_addr, reg_src_addr, reg_dst_stride, reg_src_stride;
    wire [15:0] reg_width, reg_height, reg_color;
    wire        engine_alpha;           // Stage 7: CTRL bit[8]
    wire [5:0]  reg_alpha;              // Stage 7: ALPHA(0x30)
    wire        engine_batch;           // Stage 8: CTRL bit[9]
    wire [31:0] reg_list_addr;          // Stage 8: LIST_ADDR(0x34)
    wire [31:0] reg_list_cnt;           // Stage 8: LIST_CNT(0x38), full u32

    // ---- op dispatch ------------------------------------------------------
    wire fill_start = engine_start && (engine_op == `OP_FILL);
    wire copy_start = engine_start && (engine_op == `OP_COPY);
    wire blt_start  = engine_start && (engine_op == `OP_BITBLT);

    // registered "which engine owns the shared resources" select
    reg [1:0] active_op;
    always @(posedge pclk or negedge presetn) begin
        if (!presetn)
            active_op <= `OP_FILL;
        else if (engine_start)
            active_op <= engine_op;
    end
    wire copy_active = (active_op == `OP_COPY);
    wire blt_active  = (active_op == `OP_BITBLT);

    // ---- shared write-channel observation (all engines' drain logic) -----
    wire wr_aw_hs = m_axi_awvalid && m_axi_awready;
    wire wr_b_hs  = m_axi_bvalid  && m_axi_bready;
    wire wr_idle  = !m_axi_awvalid && !m_axi_wvalid;

    // ---- fill engine ------------------------------------------------------
    wire        fill_busy, fill_done, fill_error;
    wire [31:0] fpix_addr;
    wire [15:0] fpix_data;
    wire        fpix_valid, fpix_ready, fill_flush;
    wire [31:0] f_araddr;               // Stage 8: batch list read channel
    wire [7:0]  f_arlen;
    wire        f_arvalid, f_rready;

    gpu_fill u_fill (
        .clk(pclk), .rstn(presetn), .start(fill_start),
        .busy(fill_busy), .done(fill_done), .error(fill_error),
        .dst_addr(reg_dst_addr), .width(reg_width), .height(reg_height),
        .dst_stride(reg_dst_stride), .color(reg_color),
        .batch(engine_batch), .list_addr(reg_list_addr),
        .list_cnt(reg_list_cnt),
        .pixel_addr(fpix_addr), .pixel_data(fpix_data),
        .pixel_valid(fpix_valid), .pixel_ready(fpix_ready),
        .flush(fill_flush),
        .wr_aw_hs(wr_aw_hs), .wr_b_hs(wr_b_hs), .wr_idle(wr_idle),
        .m_axi_araddr(f_araddr), .m_axi_arlen(f_arlen),
        .m_axi_arvalid(f_arvalid), .m_axi_arready(m_axi_arready),
        .m_axi_rdata(m_axi_rdata), .m_axi_rlast(m_axi_rlast),
        .m_axi_rresp(m_axi_rresp), .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(f_rready)
    );

    // ---- copy engine ------------------------------------------------------
    wire        copy_busy, copy_done, copy_error;
    wire [31:0] cpix_addr;
    wire [15:0] cpix_data;
    wire        cpix_valid, cpix_ready, copy_flush;
    wire [31:0] c_araddr;
    wire [7:0]  c_arlen;
    wire        c_arvalid, c_rready;

    gpu_copy u_copy (
        .clk(pclk), .rstn(presetn), .start(copy_start),
        .busy(copy_busy), .done(copy_done), .error(copy_error),
        .src_addr(reg_src_addr), .dst_addr(reg_dst_addr),
        .width(reg_width), .height(reg_height),
        .src_stride(reg_src_stride), .dst_stride(reg_dst_stride),
        .pixel_addr(cpix_addr), .pixel_data(cpix_data),
        .pixel_valid(cpix_valid), .pixel_ready(cpix_ready),
        .flush(copy_flush),
        .wr_aw_hs(wr_aw_hs), .wr_b_hs(wr_b_hs), .wr_idle(wr_idle),
        .m_axi_araddr(c_araddr), .m_axi_arlen(c_arlen),
        .m_axi_arsize(), .m_axi_arburst(),
        .m_axi_arvalid(c_arvalid), .m_axi_arready(m_axi_arready),
        .m_axi_rdata(m_axi_rdata), .m_axi_rlast(m_axi_rlast),
        .m_axi_rresp(m_axi_rresp), .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(c_rready)
    );

    // ---- bitblt engine ----------------------------------------------------
    wire        blt_busy, blt_done, blt_error;
    wire [31:0] bpix_addr;
    wire [15:0] bpix_data;
    wire        bpix_valid, bpix_hole, bpix_ready, blt_flush;
    wire [31:0] b_araddr;
    wire [7:0]  b_arlen;
    wire        b_arvalid, b_rready;

    gpu_bitblt u_bitblt (
        .clk(pclk), .rstn(presetn), .start(blt_start),
        .busy(blt_busy), .done(blt_done), .error(blt_error),
        .src_addr(reg_src_addr), .dst_addr(reg_dst_addr),
        .width(reg_width), .height(reg_height),
        .src_stride(reg_src_stride), .dst_stride(reg_dst_stride),
        .color_key(reg_color),
        .alpha_en(engine_alpha), .alpha_val(reg_alpha),
        .batch(engine_batch), .list_addr(reg_list_addr),
        .list_cnt(reg_list_cnt),
        .pixel_addr(bpix_addr), .pixel_data(bpix_data),
        .pixel_valid(bpix_valid), .pixel_hole(bpix_hole),
        .pixel_ready(bpix_ready),
        .flush(blt_flush),
        .wr_aw_hs(wr_aw_hs), .wr_b_hs(wr_b_hs), .wr_idle(wr_idle),
        .m_axi_araddr(b_araddr), .m_axi_arlen(b_arlen),
        .m_axi_arsize(), .m_axi_arburst(),
        .m_axi_arvalid(b_arvalid), .m_axi_arready(m_axi_arready),
        .m_axi_rdata(m_axi_rdata), .m_axi_rlast(m_axi_rlast),
        .m_axi_rresp(m_axi_rresp), .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(b_rready)
    );

    // ---- read-channel mux (fill-batch vs copy vs bitblt) -------------------
    // Mutually exclusive ops: AR is driven by the active engine; R is
    // broadcast to all three (each engine only accepts R while its own FSM
    // expects it; idle engines ignore it).  arsize/arburst are the same
    // constants from all engines (16B INCR).
    assign m_axi_araddr  = blt_active ? b_araddr  :
                           (copy_active ? c_araddr  : f_araddr);
    assign m_axi_arlen   = blt_active ? b_arlen   :
                           (copy_active ? c_arlen   : f_arlen);
    assign m_axi_arvalid = blt_active ? b_arvalid :
                           (copy_active ? c_arvalid : f_arvalid);
    assign m_axi_rready  = blt_active ? b_rready  :
                           (copy_active ? c_rready  : f_rready);
    assign m_axi_arsize  = 3'b100;              // 16 bytes (both engines)
    assign m_axi_arburst = 2'b01;               // INCR

    // AXI_Mux port carries id/lock: none used, tie like gpu_axi_reader
    assign m_axi_arid   = 8'h00;
    assign m_axi_arlock = 2'b00;
    // m_axi_rid intentionally unused (single outstanding burst)

    // ---- shared pixel stream mux (fill vs copy vs bitblt) -----------------
    wire [31:0] pix_addr  = blt_active ? bpix_addr  :
                            (copy_active ? cpix_addr  : fpix_addr);
    wire [15:0] pix_data  = blt_active ? bpix_data  :
                            (copy_active ? cpix_data  : fpix_data);
    wire        pix_valid = blt_active ? bpix_valid :
                            (copy_active ? cpix_valid : fpix_valid);
    // Stage 7 wr-opt: only BitBlt produces holes; fill/copy tie 0
    wire        pix_hole  = blt_active ? bpix_hole : 1'b0;
    wire        pix_ready;
    wire        pix_flush = blt_active ? blt_flush  :
                            (copy_active ? copy_flush :
                                           (fill_done | fill_flush));

    assign fpix_ready = (!copy_active && !blt_active) ? pix_ready : 1'b0;
    assign cpix_ready = copy_active ? pix_ready : 1'b0;
    assign bpix_ready = blt_active  ? pix_ready : 1'b0;

    gpu_axi_master u_axi (
        .aclk(pclk), .aresetn(presetn),
        .pixel_addr(pix_addr), .pixel_data(pix_data),
        .pixel_valid(pix_valid), .pixel_hole(pix_hole),
        .pixel_ready(pix_ready),
        .flush(pix_flush),
        .m_axi_awaddr(m_axi_awaddr), .m_axi_awlen(m_axi_awlen),
        .m_axi_awsize(m_axi_awsize), .m_axi_awburst(m_axi_awburst),
        .m_axi_awvalid(m_axi_awvalid), .m_axi_awready(m_axi_awready),
        .m_axi_wdata(m_axi_wdata), .m_axi_wstrb(m_axi_wstrb),
        .m_axi_wlast(m_axi_wlast), .m_axi_wvalid(m_axi_wvalid),
        .m_axi_wready(m_axi_wready), .m_axi_bresp(m_axi_bresp),
        .m_axi_bvalid(m_axi_bvalid), .m_axi_bready(m_axi_bready)
    );

    // ---- status mux back to the APB register block ------------------------
    assign engine_busy  = blt_active ? blt_busy  :
                          (copy_active ? copy_busy  : fill_busy);
    assign engine_done  = blt_active ? blt_done  :
                          (copy_active ? copy_done  : fill_done);
    assign engine_error = blt_active ? blt_error :
                          (copy_active ? copy_error : fill_error);

    gpu_apb_regs u_apb_regs (
        .pclk(pclk), .presetn(presetn), .paddr(paddr), .psel(psel),
        .penable(penable), .pwrite(pwrite), .pwdata(pwdata), .prdata(prdata),
        .pready(pready), .pslverr(pslverr),
        .engine_start(engine_start), .engine_op(engine_op),
        .engine_busy(engine_busy), .engine_done(engine_done),
        .engine_error(engine_error),
        .display_fb_sel_req(display_fb_sel_req),
        .display_fb_sel_active(display_fb_sel_active),
        .reg_dst_addr(reg_dst_addr), .reg_src_addr(reg_src_addr),
        .reg_width(reg_width), .reg_height(reg_height),
        .reg_dst_stride(reg_dst_stride), .reg_src_stride(reg_src_stride),
        .reg_color(reg_color),
        .engine_alpha(engine_alpha), .reg_alpha(reg_alpha),
        .engine_batch(engine_batch),
        .reg_list_addr(reg_list_addr), .reg_list_cnt(reg_list_cnt)
    );

endmodule
