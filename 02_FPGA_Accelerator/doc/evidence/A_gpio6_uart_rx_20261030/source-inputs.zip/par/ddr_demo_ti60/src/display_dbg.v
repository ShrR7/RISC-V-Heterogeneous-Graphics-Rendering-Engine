`timescale 1ns/1ps
//============================================================================
// display_dbg.v : A-side DISPLAY DEBUG page, APB3 zero-wait slave, 0x50..0x8F
// Team A (FPGA/SoC/display platform).
//---------------------------------------------------------------------------
// This block is OBSERVATION ONLY, with ONE deliberate exception:
//   `dbg_relock_en` is the single output that reaches the pixel path.  It is a
//   level that is 0 after every reset, so out of reset the display path is
//   untouched.  C turns it on at runtime from DBG_CTRL to A/B the fix on one
//   bitstream.  Every other output is APB read data.
//---------------------------------------------------------------------------
// rtl9: read-clear counters merge pending carry and current events.
// Read-edge events belong to the next segment; no change to the pixel path.
//---------------------------------------------------------------------------
// rtl7 CHANGES
//   A1. STALL is split and completed.  0x60 is now
//          [15:0]  STALL_AR : cycles with ARVALID & !ARREADY  (address handshake)
//          [31:16] STALL_R  : cycles with RREADY  & !RVALID   (WAITING FOR DDR)
//       The R term is the blind spot C found: the reader asserts RREADY only
//       in its read state with the FIFO not full (m_axi_rready = (state==ST_R)
//       && !fifo_full), so `RREADY & !RVALID` really does mean "a read is in
//       flight and the data has not come back" - it does NOT count idle time.
//       Both are RAW cycle counts (the old STALL_CNT was thresholded, which is
//       why a short-but-real wait could show as 0).
//   A2. RUNTIME PHASE OBSERVABILITY.  Two read-only "predicted phase error"
//       registers, defined exactly as C asked:
//           pred_phase = (starved pixels counted so far) mod 1280
//         0x80 PRED_PHASE_SEG  : segment version, READ-CLEAR
//         0x84 PRED_PHASE_BOOT : since reset, never cleared by APB
//       If pred_phase matches the horizontal offset actually seen on screen the
//       mechanism holds; if it does not, the mechanism is refuted.  (C already
//       refuted "offset == total starved pixels" using 0x78 - this register is
//       the tool that makes that comparison possible in the first place.)
//   B.  DBG_CTRL gains a DEFAULT-OFF, runtime line-phase relock switch for
//       px_serial (see px_serial.v).  DBG_CTRL keeps its "no footgun" shape:
//       the switch is SET by a write-1 pulse and CLEARED by another pulse, so
//       writing 0x5C=1 to clear counters can never silently disable it.
//---------------------------------------------------------------------------
// REGISTER MAP  (page 0x50..0x8F; all implemented offsets are 4-byte aligned)
//
//   0x50 DBG_STATUS       RO (clear_all)  [0] underrun_seen     sticky
//                                         [1] reader_stall_seen sticky
//                                         [2] full_line_seen    sticky
//                                         [3] phase_lost_seen   sticky / 0x54 sat
//                                         [4] line_starving_now live
//                                         [5] reader_busy       live
//                                         [6] reader_error      live
//                                         [7] disp_de           live (synced)
//                                         [31:8] 0
//   0x54 UNDERRUN_PX_CNT  RO r-c  [15:0] starved pixel cycles in this SEGMENT
//   0x58 UNDERRUN_LINE_CNT RO r-c [15:0] PARTIAL-starve lines in this SEGMENT
//   0x5C DBG_CTRL         RW      WRITE: [0] clear_all  (pulse)
//                                         [1] snap_rearm (pulse)
//                                         [2] relock_set (pulse) -> relock on
//                                         [3] relock_clr (pulse) -> relock off
//                                 READ : [2] = current relock state, all else 0
//   0x5E ---- DEPRECATED ----      reads 0x0000_0000.  NOT reused: it is a
//                                  2-byte offset and is NOT 4-byte aligned.
//   0x60 DBG_STALL_CNT    RO r-c  [15:0]  STALL_AR  ARVALID & !ARREADY cycles
//                                 [31:16] STALL_R   RREADY  & !RVALID  cycles
//   0x64 DBG_LAST_ROW     RO r-c  [15:0] v_cnt of the last PARTIAL-starve line
//   0x68 DBG_TIMESTAMP    RO r-c  [15:0] free-running user_clk counter (10 ns)
//   0x6C DBG_ID           RO      magic 0x4442_4731 = "DBG1"
//   0x70 DBG_FULLLINE_CNT RO r-c  [15:0] FULL-line (>=1280 px) starves, SEGMENT
//   0x74 DBG_STATUS2      RO      [0] reader_stall_now live
//                                 [1] px_have          live
//                                 [2] reader_busy      live
//                                 [3] reader_error     live
//                                 [4] reader_line_req  live
//                                 [5] snap_valid
//                                 [6] snap_clean
//                                 [7] snap_phase_ok
//                                 [8] vs_toggle        live (flips per vs rising edge)
//                                 [9] fetch_toggle     live (flips per line fetch)
//                                 [10] relock_en       live (mirror of DBG_CTRL[2])
//                                 [11] relock_seen     sticky: a relock fired
//                                 [12] relock_busy     live: catch-up running
//                                 [31:13] 0
//   0x78 DBG_BOOT_SNAP0   RO  (NOT clearable by any APB action)
//                                 [15:0]  BOOT_PX_CNT   startup starved pixel cycles
//                                 [31:16] BOOT_LINE_CNT startup PARTIAL-starve lines
//   0x7C DBG_BOOT_SNAP1   RO  (NOT clearable by any APB action)
//                                 [15:0]  BOOT_FULL_CNT startup FULL-line starves
//                                 [31:16] BOOT_LAST_ROW last startup PARTIAL starve
//   0x80 DBG_PRED_PHASE_SEG  RO r-c  [10:0] (segment starved px) mod 1280
//   0x84 DBG_PRED_PHASE_BOOT RO      [10:0] (starved px since reset) mod 1280
//                                    never cleared except by `reset`
//---------------------------------------------------------------------------
// "r-c" = read-clear.  It affects ONLY the APB-domain segment counters; there
// is no APB -> pixel path in this file, so it can not influence a line verdict
// and can not disturb the relock state.
//
// CLOCK DOMAINS: APB/reader = clk = user_clk (100 MHz); video = pclk
// (74.375 MHz).  pclk is slower than clk, so a single pclk-cycle pulse is
// always captured by the 2-FF synchroniser on the clk side.  Every register is
// written from exactly ONE always block (no VDB-1000/VDB-1001 multi-driver).
//============================================================================

module display_dbg #(
    parameter [31:0] DBG_MAGIC    = 32'h4442_4731,   // "DBG1"
    parameter [15:0] STALL_THRESH = 16'd32,
    parameter [15:0] HACT         = 16'd1280,
    parameter [1:0]  SNAP_VS      = 2'd1
) (
    input  wire        clk,
    input  wire        reset,

    // ---- APB3 -------------------------------------------------------------
    input  wire [7:0]  paddr,
    input  wire        psel,
    input  wire        penable,
    input  wire        pwrite,
    input  wire [31:0] pwdata,
    output reg  [31:0] prdata,
    output wire        pready,
    output wire        pslverr,
    output wire        sel,

    // ---- pixel clock domain (74.375 MHz) - OBSERVATION INPUTS ONLY --------
    input  wire        pclk,
    input  wire        prst_n,
    input  wire        disp_de,
    input  wire        disp_have,
    input  wire        disp_vs,
    input  wire [15:0] disp_vcnt,
    input  wire        disp_relock_tgl,     // rtl7: px_serial relock fired
    input  wire        disp_relock_busy,    // rtl7: px_serial catch-up running

    // ---- AXI (clk) domain reader observation ------------------------------
    input  wire        reader_arvalid,
    input  wire        reader_arready,
    input  wire        reader_rvalid,
    input  wire        reader_rready,
    input  wire        reader_busy,
    input  wire        reader_error,
    input  wire        reader_line_req,
    input  wire        reader_line_done,

    // ---- rtl7: THE ONE FUNCTIONAL OUTPUT (0 after reset) ------------------
    output wire        dbg_relock_en
);

    //========================================================== page decode ==
    // rtl7: the DISP page now spans 0x50..0x8F so that the new phase registers
    // can live at 4-byte aligned offsets.  apb3_top derives gpu_sel as
    // `~plat_sel & ~dispdbg_sel`, so extending this range automatically keeps
    // the GPU page out of it - no change is needed in the arbiter.
    assign sel     = psel & (paddr >= 8'h50) & (paddr <= 8'h8F);
    assign pready  = 1'b1;
    assign pslverr = 1'b0;

    localparam [7:0] R_STATUS   = 8'h50;
    localparam [7:0] R_PXCNT    = 8'h54;
    localparam [7:0] R_LINECNT  = 8'h58;
    localparam [7:0] R_CTRL     = 8'h5C;
    // 0x5E is deliberately NOT decoded (2-byte offset, not 4-byte aligned).
    localparam [7:0] R_STALLCNT = 8'h60;
    localparam [7:0] R_LASTROW  = 8'h64;
    localparam [7:0] R_STAMP    = 8'h68;
    localparam [7:0] R_ID       = 8'h6C;
    localparam [7:0] R_FULLCNT  = 8'h70;
    localparam [7:0] R_STATUS2  = 8'h74;
    localparam [7:0] R_BOOT0    = 8'h78;
    localparam [7:0] R_BOOT1    = 8'h7C;
    localparam [7:0] R_PPSEG    = 8'h80;
    localparam [7:0] R_PPBOOT   = 8'h84;

    wire wr = sel & penable &  pwrite;
    wire rd = sel & penable & ~pwrite;

    //====================================================== pixel domain =====
    reg [15:0] starve_line;
    reg        de_seen_p;
    reg        starving_now;
    reg        px_tgl;
    reg        ln_tgl;
    reg        fl_tgl;
    reg        lrv_tgl;
    reg [15:0] lrv_val;
    reg        vs_d;
    reg        vs_tgl;

    wire de_fall      = de_seen_p & ~disp_de;
    wire partial_line = (starve_line != 16'd0) && (starve_line < HACT);
    wire full_line    = (starve_line >= HACT);

    always @(posedge pclk or negedge prst_n) begin
        if (!prst_n) begin
            starve_line  <= 16'd0;
            de_seen_p    <= 1'b0;
            starving_now <= 1'b0;
            px_tgl       <= 1'b0;
            ln_tgl       <= 1'b0;
            fl_tgl       <= 1'b0;
            lrv_tgl      <= 1'b0;
            lrv_val      <= 16'd0;
            vs_d         <= 1'b0;
            vs_tgl       <= 1'b0;
        end else begin
            vs_d <= disp_vs;
            if (disp_vs & ~vs_d) vs_tgl <= ~vs_tgl;

            // per-starved-pixel accumulation: PIXEL DOMAIN ONLY.  No APB action
            // of any kind can reach this, so a mid-line read of 0x54 can never
            // truncate it and corrupt the line classification.
            if (disp_de & ~disp_have) begin
                px_tgl       <= ~px_tgl;
                starving_now <= 1'b1;
                if (starve_line != 16'hFFFF)
                    starve_line <= starve_line + 16'd1;
            end

            // line boundary: ONLY the de falling edge
            if (de_fall) begin
                de_seen_p <= 1'b0;
                if (partial_line) begin
                    ln_tgl  <= ~ln_tgl;
                    lrv_tgl <= ~lrv_tgl;
                    lrv_val <= disp_vcnt;
                end else if (full_line) begin
                    fl_tgl  <= ~fl_tgl;
                end
                starve_line  <= 16'd0;
                starving_now <= 1'b0;
            end else if (disp_de) begin
                de_seen_p <= 1'b1;
            end
        end
    end

    //=================================================== CDC into clk domain =
    reg px_s1, px_s2, ln_s1, ln_s2, fl_s1, fl_s2, lr_s1, lr_s2;
    reg vs_s1, vs_s2, pr_s1, pr_s2, de_s1, de_s2, hv_s1, hv_s2;
    reg rlt_s1, rlt_s2, rlb_s1, rlb_s2;
    reg [15:0] lrv_s1, lrv_s2;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            px_s1 <= 1'b0; px_s2 <= 1'b0;
            ln_s1 <= 1'b0; ln_s2 <= 1'b0;
            fl_s1 <= 1'b0; fl_s2 <= 1'b0;
            lr_s1 <= 1'b0; lr_s2 <= 1'b0;
            vs_s1 <= 1'b0; vs_s2 <= 1'b0;
            pr_s1 <= 1'b0; pr_s2 <= 1'b0;
            de_s1 <= 1'b0; de_s2 <= 1'b0;
            hv_s1 <= 1'b0; hv_s2 <= 1'b0;
            rlt_s1 <= 1'b0; rlt_s2 <= 1'b0;
            rlb_s1 <= 1'b0; rlb_s2 <= 1'b0;
            lrv_s1 <= 16'd0; lrv_s2 <= 16'd0;
        end else begin
            px_s1  <= px_tgl;       px_s2  <= px_s1;
            ln_s1  <= ln_tgl;       ln_s2  <= ln_s1;
            fl_s1  <= fl_tgl;       fl_s2  <= fl_s1;
            lr_s1  <= lrv_tgl;      lr_s2  <= lr_s1;
            vs_s1  <= vs_tgl;       vs_s2  <= vs_s1;
            pr_s1  <= reader_line_done; pr_s2 <= pr_s1;
            de_s1  <= disp_de;      de_s2  <= de_s1;
            hv_s1  <= disp_have;    hv_s2  <= hv_s1;
            rlt_s1 <= disp_relock_tgl;  rlt_s2 <= rlt_s1;
            rlb_s1 <= disp_relock_busy; rlb_s2 <= rlb_s1;
            lrv_s1 <= lrv_val;      lrv_s2 <= lrv_s1;
        end
    end

    reg px_s2_d, ln_s2_d, fl_s2_d, lr_s2_d, vs_s2_d, pr_s2_d, rlt_s2_d;
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            px_s2_d <= 1'b0; ln_s2_d <= 1'b0; fl_s2_d <= 1'b0;
            lr_s2_d <= 1'b0; vs_s2_d <= 1'b0; pr_s2_d <= 1'b0; rlt_s2_d <= 1'b0;
        end else begin
            px_s2_d <= px_s2;
            ln_s2_d <= ln_s2;
            fl_s2_d <= fl_s2;
            lr_s2_d <= lr_s2;
            vs_s2_d <= vs_s2;
            pr_s2_d <= pr_s2;
            rlt_s2_d <= rlt_s2;
        end
    end
    wire px_evt  = px_s2 ^ px_s2_d;
    wire ln_evt  = ln_s2 ^ ln_s2_d;
    wire fl_evt  = fl_s2 ^ fl_s2_d;
    wire vs_evt  = vs_s2 ^ vs_s2_d;
    wire pr_evt  = pr_s2 ^ pr_s2_d;
    wire rl_evt  = rlt_s2 ^ rlt_s2_d;
    wire lr_new  = lr_s2 ^ lr_s2_d;

    reg fetch_tgl;
    always @(posedge clk or posedge reset) begin
        if (reset)       fetch_tgl <= 1'b0;
        else if (pr_evt) fetch_tgl <= ~fetch_tgl;
    end

    //================================================ stall watch (A1) =======
    // Two RAW cycle counters plus the two thresholded level flags that drive
    // STATUS[1] and STATUS2[0].
    //   STALL_AR : ARVALID held against ARREADY low  -> address not accepted
    //   STALL_R  : RREADY  high against RVALID  low  -> DATA NOT RETURNED YET
    //              (m_axi_rready = (state==ST_R) && !fifo_full, so this cannot
    //               fire during idle blanking - it really is "waiting for DDR")
    reg [15:0] stall_ar_cnt, stall_r_cnt;
    reg [15:0] ar_hold, r_hold;
    reg        ar_stall, r_stall;

    wire ar_wait = reader_arvalid & ~reader_arready;
    wire r_wait  = reader_rready  & ~reader_rvalid;

    // (the raw cycle counters live in their own block further down: one writer
    //  per register, which is what keeps this file free of VDB-1000)
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            ar_hold <= 16'd0; r_hold <= 16'd0;
            ar_stall <= 1'b0; r_stall <= 1'b0;
        end else begin
            if (ar_wait) begin
                if (ar_hold != 16'hFFFF) ar_hold <= ar_hold + 16'd1;
                if (ar_hold >= STALL_THRESH) ar_stall <= 1'b1;
            end else begin
                ar_hold  <= 16'd0;
                ar_stall <= 1'b0;
            end

            if (r_wait) begin
                if (r_hold != 16'hFFFF) r_hold <= r_hold + 16'd1;
                if (r_hold >= STALL_THRESH) r_stall <= 1'b1;
            end else begin
                r_hold  <= 16'd0;
                r_stall <= 1'b0;
            end
        end
    end

    wire reader_stall_now = ar_stall | r_stall;

    //=================================================== counters / control ==
    reg [15:0] px_cnt, line_cnt, full_cnt, last_row, stamp;
    reg        px_carry, ln_carry, fl_carry;
    reg        und_seen, phase_lost, px_sat, full_seen, stall_seen;
    // A2: predicted phase error, 0..1279, wrapping (never saturating, so the
    // modulo stays exact however long the board runs)
    reg [10:0] pred_seg;
    reg [10:0] pred_boot;
    // B: the one functional state, 0 after reset
    reg        relock_en;
    reg        relock_seen;
    localparam [10:0] PHASE_MOD = 11'd1280;

    wire rd_px    = rd & (paddr == R_PXCNT);
    wire rd_line  = rd & (paddr == R_LINECNT);
    wire rd_full  = rd & (paddr == R_FULLCNT);
    wire rd_stall = rd & (paddr == R_STALLCNT);
    wire rd_lrow  = rd & (paddr == R_LASTROW);
    wire rd_stamp = rd & (paddr == R_STAMP);
    wire rd_ppseg = rd & (paddr == R_PPSEG);

    wire dbg_clear   = wr & (paddr == R_CTRL) & pwdata[0];
    wire snap_arm    = wr & (paddr == R_CTRL) & pwdata[1];
    wire relock_set  = wr & (paddr == R_CTRL) & pwdata[2];
    wire relock_clr  = wr & (paddr == R_CTRL) & pwdata[3];

    wire [16:0] px_sum = {1'b0, px_cnt} + {16'd0, px_carry}
                           + {16'd0, px_evt};
    wire [16:0] ln_sum = {1'b0, line_cnt} + {16'd0, ln_carry}
                           + {16'd0, ln_evt};
    wire [16:0] fl_sum = {1'b0, full_cnt} + {16'd0, fl_carry}
                           + {16'd0, fl_evt};

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            px_cnt <= 16'd0; line_cnt <= 16'd0; full_cnt <= 16'd0;
            last_row <= 16'd0; stamp <= 16'd0;
            px_carry <= 1'b0; ln_carry <= 1'b0; fl_carry <= 1'b0;
            und_seen <= 1'b0; phase_lost <= 1'b0; px_sat <= 1'b0;
            full_seen <= 1'b0; stall_seen <= 1'b0;
            pred_seg <= 11'd0; pred_boot <= 11'd0;
            relock_en <= 1'b0; relock_seen <= 1'b0;
        end else begin
            // ---- the relock switch: SET/CLEAR pulses, never touched by ----
            // ---- clear_all or by any read --------------------------------
            if (relock_set)      relock_en <= 1'b1;
            else if (relock_clr) relock_en <= 1'b0;

            if (rl_evt) relock_seen <= 1'b1;

            if (dbg_clear) begin
                // segment counters + sticky bits ONLY.  Not the pixel-domain
                // accumulator, not the startup snapshot, NOT the relock switch.
                px_cnt <= 16'd0; line_cnt <= 16'd0; full_cnt <= 16'd0;
                last_row <= 16'd0; stamp <= 16'd0;
                px_carry <= 1'b0; ln_carry <= 1'b0; fl_carry <= 1'b0;
                und_seen <= 1'b0; phase_lost <= 1'b0; px_sat <= 1'b0;
                full_seen <= 1'b0; stall_seen <= 1'b0;
                pred_seg <= 11'd0; relock_seen <= 1'b0;
            end else begin
                stamp <= stamp + 16'd1;

                if (ln_evt) begin und_seen <= 1'b1; phase_lost <= 1'b1; end
                if (fl_evt) full_seen <= 1'b1;
                if ((px_carry || px_evt) && px_sum[16]) px_sat <= 1'b1;
                if (reader_error)     stall_seen <= 1'b1;
                if (reader_stall_now) stall_seen <= 1'b1;

                // ---- A2: predicted phase error, mod 1280 ------------------
                // `pred_boot` is never cleared by APB; `pred_seg` is cleared by
                // a read of 0x80.  Both wrap at 1279 -> 0.
                if (px_evt) begin
                    pred_boot <= (pred_boot >= PHASE_MOD - 11'd1) ? 11'd0
                                                                 : pred_boot + 11'd1;
                end

                // ---- segment counters (r-c, no lost event) ----------------
                // APB returns the pre-edge count. Preserve the read-edge event
                // for the next segment, then add BOTH carry and any new event.
                // If reads are adjacent, move the old carry into the new count
                // before replacing it; it was not included in the returned data.
                // A 17-bit sum detects overflow for either a +1 or +2 increment.
                if (rd_px) begin
                    px_cnt <= {15'd0, px_carry};
                    px_carry <= px_evt;
                end else if (px_carry || px_evt) begin
                    px_carry <= 1'b0;
                    px_cnt <= px_sum[16] ? 16'hFFFF : px_sum[15:0];
                end

                if (rd_line) begin
                    line_cnt <= {15'd0, ln_carry};
                    ln_carry <= ln_evt;
                end else if (ln_carry || ln_evt) begin
                    ln_carry <= 1'b0;
                    line_cnt <= ln_sum[16] ? 16'hFFFF : ln_sum[15:0];
                end

                if (rd_full) begin
                    full_cnt <= {15'd0, fl_carry};
                    fl_carry <= fl_evt;
                end else if (fl_carry || fl_evt) begin
                    fl_carry <= 1'b0;
                    full_cnt <= fl_sum[16] ? 16'hFFFF : fl_sum[15:0];
                end

                if (lr_new)       last_row <= lrv_s2;
                else if (rd_lrow) last_row <= 16'd0;

                if (rd_stamp) stamp <= 16'd0;

                // ---- A2: segment phase --------------------------------
                if (rd_ppseg) begin
                    pred_seg <= 11'd0;
                end else if (px_evt) begin
                    pred_seg <= (pred_seg >= PHASE_MOD - 11'd1) ? 11'd0
                                                                : pred_seg + 11'd1;
                end
            end
        end
    end

    //====================================================== stall counters ==
    // Raw cycle counters with plain read-clear.  A read that races one cycle
    // loses at most 1 cycle out of a count that is 4 orders of magnitude
    // larger, so no carry is needed here (unlike the pixel/line counters).
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            stall_ar_cnt <= 16'd0;
            stall_r_cnt  <= 16'd0;
        end else if (dbg_clear) begin
            stall_ar_cnt <= 16'd0;
            stall_r_cnt  <= 16'd0;
        end else begin
            if (rd_stall) begin
                stall_ar_cnt <= ar_wait ? 16'd1 : 16'd0;
                stall_r_cnt  <= r_wait  ? 16'd1 : 16'd0;
            end else begin
                if (ar_wait && (stall_ar_cnt != 16'hFFFF))
                    stall_ar_cnt <= stall_ar_cnt + 16'd1;
                if (r_wait && (stall_r_cnt != 16'hFFFF))
                    stall_r_cnt <= stall_r_cnt + 16'd1;
            end
        end
    end

    // rtl10 A-only diagnostic ring. Existing C software need not change:
    // each nonzero read of PX_CNT seals the observed read-clear segment.
    // 0x88: write word index [6:0]; read {0xA0, record_total[15:0], 0, index}.
    // 0x8C: selected word, 32 records x four 32-bit words:
    //   0 clk timestamp modulo 2^32; 1 {max_AR_wait, max_R_wait};
    //   2 {max_reader_busy, requests_while_busy}; 3 {returned_PX, flags}.
    // Wait/busy lengths are consecutive 100MHz cycles, saturating at 65535.
    // This is observation only; it never gates requests or changes counters.
    reg [31:0] trace_tick;
    reg [15:0] trace_total, trace_ar_max, trace_r_max;
    reg [15:0] trace_busy_run, trace_busy_max, trace_missed;
    reg [6:0] trace_index;
    reg [5:0] trace_valid_count;
    reg [31:0] trace0 [0:31];
    reg [31:0] trace1 [0:31];
    reg [31:0] trace2 [0:31];
    reg [31:0] trace3 [0:31];
    wire [15:0] trace_ar_now = ar_wait ? ((ar_hold==16'hffff) ? ar_hold : ar_hold+16'd1) : 16'd0;
    wire [15:0] trace_r_now = r_wait ? ((r_hold==16'hffff) ? r_hold : r_hold+16'd1) : 16'd0;
    wire [15:0] trace_busy_now = reader_busy ? ((trace_busy_run==16'hffff) ? trace_busy_run : trace_busy_run+16'd1) : 16'd0;
    wire [15:0] trace_ar_peak = trace_ar_now>trace_ar_max ? trace_ar_now : trace_ar_max;
    wire [15:0] trace_r_peak = trace_r_now>trace_r_max ? trace_r_now : trace_r_max;
    wire [15:0] trace_busy_peak = trace_busy_now>trace_busy_max ? trace_busy_now : trace_busy_max;
    wire trace_drop = reader_line_req && reader_busy;
    wire [15:0] trace_drop_sum = (trace_drop && trace_missed!=16'hffff) ? trace_missed+16'd1 : trace_missed;
    wire [15:0] trace_flags = {9'd0,rlb_s2,reader_error,reader_busy,reader_rvalid,reader_rready,reader_arvalid,reader_arready};
    reg [31:0] trace_data;
    always @* begin
        if(trace_valid_count<32 && {1'b0,trace_index[6:2]}>=trace_valid_count) trace_data=0;
        else case(trace_index[1:0])
            0: trace_data=trace0[trace_index[6:2]];
            1: trace_data=trace1[trace_index[6:2]];
            2: trace_data=trace2[trace_index[6:2]];
            3: trace_data=trace3[trace_index[6:2]];
        endcase
    end
    always @(posedge clk or posedge reset) begin
        if(reset) begin
            trace_tick<=0; trace_total<=0; trace_index<=0; trace_valid_count<=0;
            trace_ar_max<=0; trace_r_max<=0; trace_busy_run<=0;
            trace_busy_max<=0; trace_missed<=0;
        end else begin
            trace_tick<=trace_tick+32'd1;
            trace_busy_run<=trace_busy_now;
            if(wr && paddr==8'h88) trace_index<=pwdata[6:0];
            if(dbg_clear) begin
                trace_total<=0; trace_valid_count<=0; trace_ar_max<=0; trace_r_max<=0;
                trace_busy_max<=0; trace_missed<=0;
            end else if(rd_px) begin
                if(px_cnt!=0) begin
                    trace0[trace_total[4:0]]<=trace_tick;
                    trace1[trace_total[4:0]]<={trace_ar_peak,trace_r_peak};
                    trace2[trace_total[4:0]]<={trace_busy_peak,trace_drop_sum};
                    trace3[trace_total[4:0]]<={px_cnt,trace_flags};
                    trace_total<=trace_total+16'd1;
                    if(trace_valid_count<32) trace_valid_count<=trace_valid_count+6'd1;
                end
                trace_ar_max<=0; trace_r_max<=0; trace_busy_max<=0; trace_missed<=0;
            end else begin
                trace_ar_max<=trace_ar_peak; trace_r_max<=trace_r_peak;
                trace_busy_max<=trace_busy_peak; trace_missed<=trace_drop_sum;
            end
        end
    end

    //=================================================== startup snapshot ====
    reg        snap_valid, snap_latch;
    reg [1:0]  boot_vs_cnt;
    reg [15:0] boot_px_cnt, boot_ln_cnt, boot_fl_cnt, boot_last_row;
    reg        boot_clean, boot_phase_ok;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            snap_valid <= 1'b0; snap_latch <= 1'b0; boot_vs_cnt <= 2'd0;
            boot_px_cnt <= 16'd0; boot_ln_cnt <= 16'd0;
            boot_fl_cnt <= 16'd0; boot_last_row <= 16'd0;
            boot_clean <= 1'b0; boot_phase_ok <= 1'b0;
        end else if (snap_arm) begin
            snap_valid <= 1'b0; snap_latch <= 1'b0; boot_vs_cnt <= 2'd0;
            boot_px_cnt <= 16'd0; boot_ln_cnt <= 16'd0;
            boot_fl_cnt <= 16'd0; boot_last_row <= 16'd0;
            boot_clean <= 1'b0; boot_phase_ok <= 1'b0;
        end else if (snap_latch) begin
            snap_latch    <= 1'b0;
            snap_valid    <= 1'b1;
            boot_clean    <= (boot_px_cnt == 16'd0) &&
                             (boot_ln_cnt == 16'd0) &&
                             (boot_fl_cnt == 16'd0);
            boot_phase_ok <= (boot_ln_cnt == 16'd0);
        end else if (!snap_valid) begin
            if (px_evt && (boot_px_cnt != 16'hFFFF)) boot_px_cnt <= boot_px_cnt + 16'd1;
            if (ln_evt && (boot_ln_cnt != 16'hFFFF)) boot_ln_cnt <= boot_ln_cnt + 16'd1;
            if (fl_evt && (boot_fl_cnt != 16'hFFFF)) boot_fl_cnt <= boot_fl_cnt + 16'd1;
            if (lr_new) boot_last_row <= lrv_s2;
            if (vs_evt) begin
                if (boot_vs_cnt == SNAP_VS)   snap_latch <= 1'b1;
                else if (boot_vs_cnt != 2'd3) boot_vs_cnt <= boot_vs_cnt + 2'd1;
            end
        end
    end

    //========================================================== read mux =====
    assign dbg_relock_en = relock_en;

    reg [31:0] status_word;
    always @(*) begin
        status_word    = 32'd0;
        status_word[0] = und_seen;
        status_word[1] = stall_seen;
        status_word[2] = full_seen;
        status_word[3] = phase_lost | px_sat;
        status_word[4] = starving_now;
        status_word[5] = reader_busy;
        status_word[6] = reader_error;
        status_word[7] = de_s2;
    end

    // read-back: bit2 shows the LIVE relock state, everything else reads 0.
    // Bits 0/1/3 are write-1 pulses and always read back 0.
    reg [31:0] ctrl_word;
    always @(*) begin
        ctrl_word    = 32'd0;
        ctrl_word[2] = relock_en;
    end

    reg [31:0] status2_word;
    always @(*) begin
        status2_word     = 32'd0;
        status2_word[0]  = reader_stall_now;
        status2_word[1]  = hv_s2;
        status2_word[2]  = reader_busy;
        status2_word[3]  = reader_error;
        status2_word[4]  = reader_line_req;
        status2_word[5]  = snap_valid;
        status2_word[6]  = boot_clean;
        status2_word[7]  = boot_phase_ok;
        status2_word[8]  = vs_s2;
        status2_word[9]  = fetch_tgl;
        status2_word[10] = relock_en;
        status2_word[11] = relock_seen;
        status2_word[12] = rlb_s2;
    end

    always @(*) begin
        case (paddr)
            8'h88: prdata = {8'ha0,trace_total,1'b0,trace_index};
            8'h8C: prdata = trace_data;
            R_STATUS:   prdata = status_word;
            R_PXCNT:    prdata = {16'd0, px_cnt};
            R_LINECNT:  prdata = {16'd0, line_cnt};
            R_CTRL:     prdata = ctrl_word;
            R_STALLCNT: prdata = {stall_r_cnt, stall_ar_cnt};
            R_LASTROW:  prdata = {16'd0, last_row};
            R_STAMP:    prdata = {16'd0, stamp};
            R_ID:       prdata = DBG_MAGIC;
            R_FULLCNT:  prdata = {16'd0, full_cnt};
            R_STATUS2:  prdata = status2_word;
            R_BOOT0:    prdata = {boot_ln_cnt,   boot_px_cnt};
            R_BOOT1:    prdata = {boot_last_row, boot_fl_cnt};
            R_PPSEG:    prdata = {21'd0, pred_seg};
            R_PPBOOT:   prdata = {21'd0, pred_boot};
            default:    prdata = 32'd0;
        endcase
    end

    //======================================================= self checks =====
`ifdef DISPLAY_DBG_ASSERT
    always @(posedge pclk) begin
        if (prst_n && (starve_line > HACT))
            $display("*** display_dbg ASSERT: starve_line=%0d > HACT=%0d (t=%0t)",
                     starve_line, HACT, $time);
    end
`endif

endmodule
