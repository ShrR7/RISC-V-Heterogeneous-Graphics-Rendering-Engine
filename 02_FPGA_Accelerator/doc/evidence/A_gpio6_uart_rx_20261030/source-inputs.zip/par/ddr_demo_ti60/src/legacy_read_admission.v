// A-owned complete-burst FIFO reservation. The legacy reader issues only one
// burst until RLAST; it is the sole writer of the 2048-word FIFO. WrDNum is a
// conservative core-domain level (read pointer synchronized from pixel clock).
// Reserve before exposing AR to any arbiter. No already-presented AR is gated.
module legacy_read_admission (
 input wire clk,input wire rstn,input wire [11:0] fifo_words,
 input wire [7:0] arlen,input wire s_valid,output wire s_ready,
 output wire m_valid,input wire m_ready,
 output reg offered,output reg [31:0] blocked_cycles
);
 wire [12:0] required_words={1'b0,fifo_words}+{5'd0,arlen}+13'd3;
 // Two spare words cover write-count update latency. No other FIFO producer.
 wire room=required_words<=13'd2048;
 assign m_valid=offered && s_valid;
 assign s_ready=offered && m_ready;
 always @(posedge clk or negedge rstn)begin
  if(!rstn)begin offered<=0;blocked_cycles<=0;end
  else begin
   if(m_valid && m_ready)offered<=0;
   else if(!offered && s_valid && room)offered<=1;
   if(s_valid && !offered && !room && blocked_cycles!=32'hffffffff)
    blocked_cycles<=blocked_cycles+1'b1;
  end
 end
endmodule
