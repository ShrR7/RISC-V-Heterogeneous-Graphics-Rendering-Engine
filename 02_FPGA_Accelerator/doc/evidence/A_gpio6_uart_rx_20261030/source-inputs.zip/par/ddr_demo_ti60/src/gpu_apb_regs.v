//============================================================================
// File        : gpu_apb_regs.v
// Description : APB3 slave register block for 2D GPU accelerator
//               (register file + start/dispatch/status for Fill/Copy engines)
// Team        : Team B (RTL Accelerator)
// Project     : gpu_accelerator
// Platform    : Efinix Ti60F225
//============================================================================
// Revision History:
//   v0.1  - 2026-09-10 : Stage 1 - basic register bank + dummy busy engine
//   v0.2  - 2026-09-17 : Stage 4 - STATUS.error driven by the active engine
//   v0.3  - 2026-09-19 : Stage 6 - FB_CTRL(0x28)/FB_STATUS(0x2C) double-buffer
//                        display swap handshake (see interface_spec.md)
//   v0.4  - 2026-10-09 : Stage 7 - ALPHA(0x30) global alpha 0~32 + CTRL bit[8]
//                        alpha_en modifier for op=10 (ALPHA-BLEND)
//============================================================================

`include "gpu_pkg.vh"

module gpu_apb_regs (
    // APB3 clock & reset
    input  wire        pclk,
    input  wire        presetn,

    // APB3 interface
    input  wire [31:0] paddr,     // address (offset from GPU base)
    input  wire        psel,
    input  wire        penable,
    input  wire        pwrite,
    input  wire [31:0] pwdata,
    output reg  [31:0] prdata,
    output wire        pready,
    output wire        pslverr,

    // Internal status output (to other GPU engines in later stages)
    output  wire        engine_start,
    output  wire [1:0]  engine_op,
    input  wire        engine_busy,
    input  wire        engine_done,
    input  wire        engine_error,   // Stage 4: copy engine error flag

    // Stage 6: double-buffer display swap handshake
    output wire        display_fb_sel_req,    // FB_CTRL[0]: 0=show FB0, 1=show FB1
    input  wire        display_fb_sel_active, // display side: buffer shown now

    output wire [31:0] reg_dst_addr,
    output wire [31:0] reg_src_addr,
    output wire [15:0] reg_width,
    output wire [15:0] reg_height,
    output wire [31:0] reg_dst_stride,
    output wire [31:0] reg_src_stride,
    output wire [15:0] reg_color,
    output wire        engine_alpha,     // Stage 7: CTRL bit[8] (op=10 modifier)
    output wire [5:0]  reg_alpha,        // Stage 7: ALPHA(0x30), 0~32
    output wire        engine_batch,     // Stage 8: CTRL bit[9] (list mode)
    output wire [31:0] reg_list_addr,    // Stage 8: LIST_ADDR(0x34), 16B aligned
    output wire [31:0] reg_list_cnt      // Stage 8: LIST_CNT(0x38), full u32
);

    //------------------------------------------------------------------------
    // Register storage (all 32-bit)
    //------------------------------------------------------------------------
    reg [31:0] ctrl_reg;
    reg [31:0] src_addr_reg;
    reg [31:0] dst_addr_reg;
    reg [31:0] width_reg;
    reg [31:0] height_reg;
    reg [31:0] src_stride_reg;
    reg [31:0] dst_stride_reg;
    reg [31:0] color_reg;
    reg [5:0]  alpha_reg;              // Stage 7: global alpha, 0~32
    reg [31:0] list_addr_reg;          // Stage 8: batch list DDR base
    reg [31:0] list_cnt_reg;           // Stage 8: batch list entry count

    // Stage 6: display buffer swap request (single bit; upper bits read as 0)
    reg        fb_sel_req_reg;

    // Stage 2: busy/done driven directly by external engine
    // Stage 4: error bit from the active engine (copy)
    wire       busy_bit  = engine_busy;
    wire       done_bit  = engine_done;
    wire       error_bit = engine_error;

    // Stage 6: swap is pending while the display side has not applied the
    // requested buffer selection yet.
    wire       swap_pending_bit = fb_sel_req_reg ^ display_fb_sel_active;

    //------------------------------------------------------------------------
    // APB3 response defaults
    //------------------------------------------------------------------------
    assign pready  = 1'b1;     // zero-wait state (single-cycle access)
    assign pslverr = 1'b0;     // no error response in Stage 1

    //------------------------------------------------------------------------
    // APB3 write logic (only in ACCESS phase: psel & penable & pwrite)
    //------------------------------------------------------------------------
    wire apb_write = psel & penable & pwrite;
    wire apb_read  = psel & penable & ~pwrite;

    always @(posedge pclk or negedge presetn) begin
        if (!presetn) begin
            ctrl_reg      <= 32'd0;
            src_addr_reg  <= 32'd0;
            dst_addr_reg  <= 32'd0;
            width_reg     <= 32'd0;
            height_reg    <= 32'd0;
            src_stride_reg<= 32'd0;
            dst_stride_reg<= 32'd0;
            color_reg     <= 32'd0;
            alpha_reg     <= 6'd32;     // power-on: opaque
            list_addr_reg <= 32'd0;     // Stage 8
            list_cnt_reg  <= 32'd0;     // Stage 8
            fb_sel_req_reg<= 1'b0;      // power-on: request FB0
        end else if (apb_write) begin
            case (paddr[7:0])
                `REG_CTRL:       ctrl_reg      <= pwdata;
                `REG_SRC_ADDR:   src_addr_reg  <= pwdata;
                `REG_DST_ADDR:   dst_addr_reg  <= pwdata;
                `REG_WIDTH:      width_reg     <= pwdata;
                `REG_HEIGHT:     height_reg    <= pwdata;
                `REG_SRC_STRIDE: src_stride_reg<= pwdata;
                `REG_DST_STRIDE: dst_stride_reg<= pwdata;
                `REG_COLOR:      color_reg     <= pwdata;
                `REG_FB_CTRL:    fb_sel_req_reg<= pwdata[`FB_CTRL_SEL_BIT];
                `REG_ALPHA:      alpha_reg     <= (pwdata[5:0] > 6'd32) ?
                                                  6'd32 : pwdata[5:0]; // clamp 0~32
                `REG_LIST_ADDR:  list_addr_reg <= pwdata;              // Stage 8
                `REG_LIST_CNT:   list_cnt_reg  <= pwdata;              // Stage 8
                // STATUS, ID and FB_STATUS are read-only; writes silently ignored
                default: ;
            endcase
        end
    end

    //------------------------------------------------------------------------
    // APB3 read logic (combinational, valid during ACCESS phase)
    //------------------------------------------------------------------------
    always @(*) begin
        if (apb_read) begin
            case (paddr[7:0])
                `REG_CTRL:       prdata = ctrl_reg;
                `REG_STATUS:     prdata = {29'd0, error_bit, done_bit, busy_bit};
                `REG_SRC_ADDR:   prdata = src_addr_reg;
                `REG_DST_ADDR:   prdata = dst_addr_reg;
                `REG_WIDTH:      prdata = width_reg;
                `REG_HEIGHT:     prdata = height_reg;
                `REG_SRC_STRIDE: prdata = src_stride_reg;
                `REG_DST_STRIDE: prdata = dst_stride_reg;
                `REG_COLOR:      prdata = color_reg;
                `REG_ID:         prdata = `GPU_MAGIC_ID;
                `REG_FB_CTRL:    prdata = {31'd0, fb_sel_req_reg};
                `REG_FB_STATUS:  prdata = {30'd0, swap_pending_bit,
                                           display_fb_sel_active};
                `REG_ALPHA:      prdata = {26'd0, alpha_reg};
                `REG_LIST_ADDR:  prdata = list_addr_reg;               // Stage 8
                `REG_LIST_CNT:   prdata = list_cnt_reg;                // Stage 8
                default:         prdata = 32'd0;
            endcase
        end else begin
            prdata = 32'd0;
        end
    end

    //------------------------------------------------------------------------
    // Start pulse detection (one-cycle, positive edge of CTRL[0])
    //------------------------------------------------------------------------
    reg        ctrl_start_d;
    wire       ctrl_start_w = ctrl_reg[`CTRL_START_BIT];
    wire       start_pulse;

    always @(posedge pclk or negedge presetn) begin
        if (!presetn)
            ctrl_start_d <= 1'b0;
        else
            ctrl_start_d <= ctrl_start_w;
    end

    assign start_pulse = ctrl_start_w & ~ctrl_start_d;

    //------------------------------------------------------------------------
    // Internal outputs to other engines (Stage 2+)
    //------------------------------------------------------------------------
    assign engine_start = start_pulse;
    assign engine_op    = ctrl_reg[`CTRL_OP_HI_BIT:`CTRL_OP_LO_BIT];
    assign engine_alpha = ctrl_reg[`CTRL_ALPHA_BIT];   // Stage 7
    assign engine_batch = ctrl_reg[`CTRL_BATCH_BIT];   // Stage 8

    // Stage 6: swap request goes to the display path (A side latches it at a
    // safe frame boundary and drives display_fb_sel_active back).
    assign display_fb_sel_req = fb_sel_req_reg;

    assign reg_dst_addr   = dst_addr_reg;
    assign reg_src_addr   = src_addr_reg;
    assign reg_width      = width_reg[15:0];
    assign reg_height     = height_reg[15:0];
    assign reg_dst_stride = dst_stride_reg;
    assign reg_src_stride = src_stride_reg;
    assign reg_color      = color_reg[15:0];
    assign reg_alpha      = alpha_reg;          // Stage 7
    assign reg_list_addr  = list_addr_reg;      // Stage 8
    assign reg_list_cnt   = list_cnt_reg;         // Stage 8: full u32 (engines
                                                  // refuse >1024 themselves;
                                                  // never truncate silently)

endmodule
