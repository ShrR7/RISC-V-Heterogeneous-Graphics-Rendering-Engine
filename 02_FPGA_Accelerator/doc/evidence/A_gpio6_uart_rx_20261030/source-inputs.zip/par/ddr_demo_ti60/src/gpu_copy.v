//============================================================================
// File        : gpu_copy.v
// Description : Block Copy engine for 2D GPU accelerator (Stage 4, op=01)
// Team        : Team B (RTL Accelerator)
//
// Architecture (Stage 7 wr-opt 3, 2026-10-13: cross-line ping-pong,
// same structure as gpu_bitblt):
//     * Read-ahead FSM (RA_*) streams whole source lines over AXI into a
//       DOUBLE line buffer (line_bufA/B): while the write side streams
//       line n out of buffer p, line n+1 is already being fetched into
//       buffer 1-p -- the per-line AXI read latency is hidden behind the
//       write phase.
//     * Write FSM (ST_WAIT/ST_WR/ST_DRAIN) unpacks pixels from the ready
//       buffer and presents them as a pixel stream to the SHARED
//       gpu_axi_master (the exact same write path Solid Fill uses).  Per
//       line it only pulses flush (closing the trailing write group); the
//       full B-drain wait happens ONCE at the end of the operation
//       (ST_DRAIN) -- the master's group buffer serialises in-flight
//       bursts safely.
//
//     Buffer handshake: fullA/fullB is set by the read-ahead when a buffer
//     holds a complete line, cleared by the write FSM on consume.  Kick
//     rule: line k+1 goes into buffer 1-cur as soon as the read-ahead is
//     idle and that buffer is free (program order guarantees it has been
//     fully streamed).  Both FSMs live in ONE clocked process so every
//     register has a single driver.
//
// Constraints (also documented for the driver):
//   - src_addr / dst_addr / strides must be EVEN (pixel aligned).
//     src_addr may be any even address: a 16-byte-misaligned head is
//     compensated by reading from the aligned floor and skipping the
//     head bytes during unpack.
//   - Overlapping SRC/DST rectangles are NOT supported (copy direction
//     undefined); software must guarantee non-overlap.
//   - width*2 + head(<=14) bytes must fit ONE line buffer
//     (MAX_LINE_BEATS*16 = 4 KB). 720p worst case: 1280 px * 2 = 2560 B
//     -> 160 beats, fits. An oversized line is refused: done+error, no
//     AXI traffic.
//   - width == 0 or height == 0 -> immediate done, no AXI traffic.
//
//   The shared-master drain handshake uses three observation wires from
//   gpu_top (the master itself is NOT modified):
//     wr_aw_hs : AW handshake this cycle   (m_axi_awvalid && m_axi_awready)
//     wr_b_hs  : B  handshake this cycle   (m_axi_bvalid  && m_axi_bready)
//     wr_idle  : master outputs quiescent  (!awvalid && !wvalid)
//   After the final flush we wait two settle cycles, then require
//   wr_idle && (aw_cnt == b_cnt) before asserting done - the CPU never
//   observes done while a write is still in flight.
//============================================================================

`include "gpu_pkg.vh"

module gpu_copy #(
    parameter MAX_LINE_BEATS = 256          // line buffer: 256 x 16 B = 4 KB
)(
    input  wire         clk,
    input  wire         rstn,

    input  wire         start,              // 1-cycle pulse (op == OP_COPY)
    output reg          busy,
    output reg          done,               // level: stays 1 until next start
    output reg          error,              // sticky until next start

    input  wire [31:0]  src_addr,
    input  wire [31:0]  dst_addr,
    input  wire [15:0]  width,              // pixels per line
    input  wire [15:0]  height,             // lines
    input  wire [31:0]  src_stride,         // bytes per line (source)
    input  wire [31:0]  dst_stride,         // bytes per line (dest)

    // ---- pixel stream out (to shared gpu_axi_master in gpu_top) -----------
    output wire [31:0]  pixel_addr,
    output wire [15:0]  pixel_data,
    output wire         pixel_valid,
    input  wire         pixel_ready,
    output reg          flush,              // 1-cycle pulse: end-of-line flush

    // ---- shared write-channel observation (from gpu_top) ------------------
    input  wire         wr_aw_hs,
    input  wire         wr_b_hs,
    input  wire         wr_idle,

    // ---- AXI4 read address channel ----------------------------------------
    output wire [31:0]  m_axi_araddr,
    output wire [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output reg          m_axi_arvalid,
    input  wire         m_axi_arready,

    // ---- AXI4 read data channel -------------------------------------------
    input  wire [127:0] m_axi_rdata,
    input  wire         m_axi_rlast,
    input  wire [1:0]   m_axi_rresp,        // 00 = OKAY; others set `error`
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready
);

    // AR constants (same as gpu_axi_reader: 16-byte beats, INCR)
    assign m_axi_arsize  = 3'b100;
    assign m_axi_arburst = 2'b01;

    // ---- write FSM states --------------------------------------------------
    localparam [1:0] ST_IDLE  = 2'd0,
                     ST_WAIT  = 2'd1,   // wait for full[cur]
                     ST_WR    = 2'd2,   // stream pixels of buffer cur
                     ST_DRAIN = 2'd3;   // op end: wait master drain

    // ---- read-ahead FSM states ----------------------------------------------
    localparam [1:0] RA_IDLE = 2'd0,
                     RA_AR   = 2'd1,
                     RA_R    = 2'd2;

    reg [1:0]   state;
    reg [1:0]   ra_state;

    // ---- ping-pong bookkeeping ----------------------------------------------
    reg         cur;            // buffer the write FSM consumes
    reg         fullA, fullB;   // buffer holds a complete, unread line
    reg  [3:0]  hoA, hoB;       // src head offset per buffer

    reg [15:0]  line_cnt;       // line being written: 0 .. height-1
    reg [15:0]  rd_line_idx;    // lines kicked to read-ahead so far
    reg [31:0]  rd_src_line;    // next src line address for read-ahead
    reg [31:0]  wr_dst_line;    // dst address of the line being written

    // ---- read-ahead datapath -------------------------------------------------
    reg         ra_buf;         // buffer being filled
    reg [31:0]  ra_remaining;   // bytes left to read for the current line
    reg [31:0]  ra_cur_addr;    // address of the next read burst
    reg [8:0]   ra_burst_beats; // beats of the read burst in flight (1..256)
    reg [8:0]   ra_wr_beat;     // line-buffer write index
    reg [31:0]  araddr_r;
    reg [7:0]   arlen_r;

    // ---- kick (write FSM -> read-ahead) --------------------------------------
    reg         kick;           // 1-cycle pulse
    reg         kick_buf;
    reg  [31:0] kick_src;

    // ---- write-side pixel datapath -------------------------------------------
    reg [15:0]  pix_idx;        // 0 .. width-1
    reg [15:0]  aw_cnt;         // AW handshakes seen since op start
    reg [15:0]  b_cnt;          // B  handshakes seen since op start
    reg [1:0]   wb_settle;      // 2-cycle settle after final flush

    // ---- stall watchdog (same philosophy as reader/master) ----------------
    localparam [23:0] STALL_LIMIT = 24'd200000;   // ~2 ms @ 100 MHz
    reg  [23:0] stall_cnt;
    wire        stall_abort = busy && (stall_cnt >= STALL_LIMIT);

    // ---- line buffers (ping-pong; sync-read BRAM template) ----------------
    reg [127:0] line_bufA [0:MAX_LINE_BEATS-1];
    reg [127:0] line_bufB [0:MAX_LINE_BEATS-1];

    //------------------------------------------------------------------------
    // Line-length maths: a line covers head + width*2 bytes, rounded up to 16
    //------------------------------------------------------------------------
    function [31:0] rd_bytes_of(input [31:0] saddr, input [15:0] w);
        reg [31:0] span;
        begin
            span = {28'd0, saddr[3:0]} + {14'd0, w, 1'b0};
            rd_bytes_of = {span[31:4] + {31'd0, |span[3:0]}, 4'b0};
        end
    endfunction

    function line_too_big(input [31:0] saddr, input [15:0] w);
        begin
            line_too_big = (rd_bytes_of(saddr, w) > (MAX_LINE_BEATS*16));
        end
    endfunction

    //------------------------------------------------------------------------
    // Read-ahead burst length calculation (identical rules to gpu_axi_reader):
    //   burst = min(16, ceil(ra_remaining/16), beats left to 4 KB boundary)
    //------------------------------------------------------------------------
    wire [12:0] bytes_to_4k  = 13'h1000 - {1'b0, ra_cur_addr[11:0]};
    wire [8:0]  beats_to_4k  = {1'b0, bytes_to_4k[12:4]};          // 1..256
    wire [8:0]  beats_remain = (|ra_remaining[31:12]) ? 9'd256 :
                               ({1'b0, ra_remaining[11:4]} + {8'd0, |ra_remaining[3:0]});
    wire [8:0]  burst_calc   = (beats_remain > 9'd16) ? 9'd16 : beats_remain;
    wire [8:0]  burst_next   = (burst_calc > beats_to_4k) ? beats_to_4k : burst_calc;

    //------------------------------------------------------------------------
    // Unpack: pixel pix_idx sits at byte head_off + pix_idx*2 inside the line.
    //
    // The line buffer is read with a SYNCHRONOUS read port (address this
    // cycle, data next cycle) so the synthesizer maps it to block RAM.
    // (The previous combinational read was mapped to logic memory: 32768
    // FFs + a 256:1 x 128-bit mux, which blew the Ti60F225 budget at P&R --
    // A's resource ticket, EFX-0657.)  Both buffers are read at the same
    // address and muxed by `cur` (constant per line).
    //
    // The pixel stream is therefore pipelined by one cycle: rb_data / rb_off
    // / addr_r / valid_r all describe the SAME pixel. Because pix_idx only
    // advances on a handshake, the read address must look ONE PIXEL AHEAD
    // during a handshake -- otherwise pix_idx's word is read again and the
    // whole line shifts by one pixel.
    //------------------------------------------------------------------------
    wire [15:0] pix_rd  = (valid_r && pixel_ready) ? (pix_idx + 16'd1) : pix_idx;
    wire [3:0]  cur_ho  = cur ? hoB : hoA;
    wire [13:0] byte_rd = {10'd0, cur_ho} + {pix_rd[12:0], 1'b0};

    // EFX-0657 fix (A's PR #47 template): EACH bank gets its own synchronous
    // read register; the `cur` mux sits AFTER the registers.  Efinity only
    // infers RAM10 when the read port is a plain `q <= mem[addr];` -- a mux
    // inside the read expression maps the whole array to FFs (rtl11: 66k FF).
    // `cur` is constant within a line and only flips in ST_WAIT (valid_i=0),
    // so cur_r is in phase with the registered data.
    reg  [127:0] rb_dataA;      // bank A read data, registered (RAM read port)
    reg  [127:0] rb_dataB;      // bank B read data, registered (RAM read port)
    reg          cur_r;         // `cur` delayed 1 cycle, in phase with data
    reg  [3:0]   rb_off;        // byte offset of the pixel inside the word
    reg  [31:0]  addr_r;        // dst address, in phase with the data
    reg          valid_i;       // pixel-valid produced by the FSM
    reg          valid_r;       // valid_i delayed 1 cycle -> in phase with data

    wire [127:0] rb_data = cur_r ? rb_dataB : rb_dataA;   // mux after regs

    assign pixel_valid = valid_r;
    assign pixel_addr  = addr_r;
    assign pixel_data  = rb_data[{rb_off[3:1], 4'b0} +: 16];

    // bank read ports: NO reset, NO mux -- the exact template A verified.
    always @(posedge clk) begin
        rb_dataA <= line_bufA[byte_rd[13:4]];
        rb_dataB <= line_bufB[byte_rd[13:4]];
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            cur_r   <= 1'b0;
            rb_off  <= 4'd0;
            addr_r  <= 32'd0;
            valid_r <= 1'b0;
        end else begin
            cur_r   <= cur;
            rb_off  <= byte_rd[3:0];
            addr_r  <= wr_dst_line + {15'd0, pix_rd, 1'b0};
            valid_r <= valid_i;
        end
    end

    // read channel: the internal buffer always accepts, no backpressure needed
    assign m_axi_rready = (ra_state == RA_R);
    assign m_axi_araddr = araddr_r;
    assign m_axi_arlen  = arlen_r;

    // ---- write-channel handshake counters ---------------------------------
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            aw_cnt <= 16'd0;
            b_cnt  <= 16'd0;
        end else if (state == ST_IDLE && start) begin
            aw_cnt <= 16'd0;
            b_cnt  <= 16'd0;
        end else begin
            if (wr_aw_hs) aw_cnt <= aw_cnt + 16'd1;
            if (wr_b_hs)  b_cnt  <= b_cnt  + 16'd1;
        end
    end

    //------------------------------------------------------------------------
    // Kick rule: line rd_line_idx goes into buffer 1-cur as soon as the
    // read-ahead is idle and that buffer is free.  The !kick term closes the
    // 1-cycle window in which a kick pulse is on its way but not yet latched
    // by the read-ahead (same fix as gpu_bitblt).
    //------------------------------------------------------------------------
    wire want_kick = busy && !kick &&
                     (rd_line_idx < height) &&
                     (rd_line_idx == line_cnt + 16'd1) &&
                     (ra_state == RA_IDLE) &&
                     !(cur ? fullA : fullB);

    //------------------------------------------------------------------------
    // Single clocked process: write FSM + read-ahead FSM (single driver per
    // register; the two parts never touch the same flag in the same cycle:
    // read-ahead sets full[ra_buf], the write side clears full[cur]).
    //------------------------------------------------------------------------
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            // write FSM
            state         <= ST_IDLE;
            busy          <= 1'b0;
            done          <= 1'b0;
            error         <= 1'b0;
            cur           <= 1'b0;
            line_cnt      <= 16'd0;
            rd_line_idx   <= 16'd0;
            rd_src_line   <= 32'd0;
            wr_dst_line   <= 32'd0;
            pix_idx       <= 16'd0;
            valid_i       <= 1'b0;
            flush         <= 1'b0;
            wb_settle     <= 2'd0;
            stall_cnt     <= 24'd0;
            // kick
            kick          <= 1'b0;
            kick_buf      <= 1'b0;
            kick_src      <= 32'd0;
            // read-ahead
            ra_state       <= RA_IDLE;
            ra_buf         <= 1'b0;
            ra_remaining   <= 32'd0;
            ra_cur_addr    <= 32'd0;
            ra_burst_beats <= 9'd0;
            ra_wr_beat     <= 9'd0;
            araddr_r       <= 32'd0;
            arlen_r        <= 8'd0;
            m_axi_arvalid  <= 1'b0;
            fullA          <= 1'b0;
            fullB          <= 1'b0;
            hoA            <= 4'd0;
            hoB            <= 4'd0;
        end else if (stall_abort) begin
            // watchdog: drop everything, flag it, report done so the CPU
            // never hangs (CPU reads STATUS.error for the cause)
            state         <= ST_IDLE;
            busy          <= 1'b0;
            done          <= 1'b1;
            error         <= 1'b1;
            valid_i       <= 1'b0;
            flush         <= 1'b0;
            kick          <= 1'b0;
            ra_state      <= RA_IDLE;
            m_axi_arvalid <= 1'b0;
            fullA         <= 1'b0;
            fullB         <= 1'b0;
            stall_cnt     <= 24'd0;
        end else begin
            flush <= 1'b0;              // default: one-cycle pulse
            kick  <= 1'b0;              // default: one-cycle pulse

            // ======================= write FSM =============================
            if (want_kick) begin
                kick        <= 1'b1;
                kick_buf    <= ~cur;
                kick_src    <= rd_src_line;
                rd_src_line <= rd_src_line + src_stride;
                rd_line_idx <= rd_line_idx + 16'd1;
            end

            case (state)

                // ---- wait for start ---------------------------------------
                ST_IDLE: begin
                    valid_i <= 1'b0;
                    busy    <= 1'b0;
                    if (start) begin
                        error <= 1'b0;
                        if (width == 16'd0 || height == 16'd0) begin
                            done <= 1'b1;               // empty op: done at once
                        end else if (line_too_big(src_addr, width)) begin
                            // line wider than the buffer: refuse cleanly
                            done  <= 1'b1;
                            error <= 1'b1;
                        end else begin
                            done        <= 1'b0;
                            busy        <= 1'b1;
                            fullA       <= 1'b0;        // drop stale flags from
                            fullB       <= 1'b0;        // any aborted op
                            cur         <= 1'b0;
                            line_cnt    <= 16'd0;
                            wr_dst_line <= dst_addr;
                            // kick line 0 into buffer A
                            kick        <= 1'b1;
                            kick_buf    <= 1'b0;
                            kick_src    <= src_addr;
                            rd_src_line <= src_addr + src_stride;
                            rd_line_idx <= 16'd1;
                            state       <= ST_WAIT;
                        end
                    end
                end

                // ---- wait for the current buffer to be filled -------------
                ST_WAIT: begin
                    if (cur ? fullB : fullA) begin
                        if (cur) fullB <= 1'b0;
                        else     fullA <= 1'b0;
                        pix_idx <= 16'd0;
                        valid_i <= 1'b1;
                        state   <= ST_WR;
                    end
                end

                // ---- stream pixels to the shared write master -------------
                ST_WR: begin
                    if (valid_r && pixel_ready) begin
                        if (pix_idx == width - 16'd1) begin
                            valid_i <= 1'b0;
                            flush   <= 1'b1;    // close the trailing write group
                            if (line_cnt == height - 16'd1) begin
                                wb_settle <= 2'd2;
                                state     <= ST_DRAIN;
                            end else begin
                                line_cnt    <= line_cnt + 16'd1;
                                cur         <= ~cur;
                                wr_dst_line <= wr_dst_line + dst_stride;
                                state       <= ST_WAIT;
                            end
                        end else begin
                            pix_idx <= pix_idx + 16'd1;
                        end
                    end
                end

                // ---- end of op: wait for the write master to drain --------
                ST_DRAIN: begin
                    if (wb_settle != 2'd0) begin
                        // Two bubble cycles: after our flush pulse the master
                        // commits the buffered groups and only registers
                        // awvalid afterwards.  Sampling quiescence earlier
                        // would false-pass while the last group is still
                        // unwritten (tb T2/T3/T4 lesson).
                        wb_settle <= wb_settle - 2'd1;
                    end else if (wr_idle && (aw_cnt == b_cnt)) begin
                        done  <= 1'b1;
                        busy  <= 1'b0;
                        state <= ST_IDLE;
                    end
                end

                default: state <= ST_IDLE;
            endcase

            // ==================== read-ahead FSM ===========================
            case (ra_state)
                RA_IDLE: begin
                    m_axi_arvalid <= 1'b0;
                    if (kick) begin
                        ra_buf        <= kick_buf;
                        ra_remaining  <= rd_bytes_of(kick_src, width);
                        ra_cur_addr   <= {kick_src[31:4], 4'b0000};
                        ra_wr_beat    <= 9'd0;
                        if (kick_buf) hoB <= kick_src[3:0];
                        else          hoA <= kick_src[3:0];
                        ra_state      <= RA_AR;
                    end
                end

                // ---- issue one read burst (assert-and-hold) ---------------
                RA_AR: begin
                    if (!m_axi_arvalid) begin
                        araddr_r       <= ra_cur_addr;
                        arlen_r        <= burst_next[7:0] - 8'd1;
                        ra_burst_beats <= burst_next;
                        m_axi_arvalid  <= 1'b1;
                    end else if (m_axi_arready) begin
                        m_axi_arvalid <= 1'b0;
                        ra_state      <= RA_R;
                    end
                end

                // ---- receive beats into the kicked buffer -----------------
                RA_R: begin
                    if (m_axi_rvalid && m_axi_rready) begin
                        if (ra_buf) line_bufB[ra_wr_beat] <= m_axi_rdata;
                        else        line_bufA[ra_wr_beat] <= m_axi_rdata;
                        ra_wr_beat <= ra_wr_beat + 9'd1;
                        if (m_axi_rresp != 2'b00)
                            error <= 1'b1;          // flag, keep draining
                        if (m_axi_rlast) begin
                            if (ra_remaining == {19'd0, ra_burst_beats, 4'b0}) begin
                                // whole line buffered -> mark ready
                                if (ra_buf) fullB <= 1'b1;
                                else        fullA <= 1'b1;
                                ra_state <= RA_IDLE;
                            end else begin
                                ra_cur_addr  <= ra_cur_addr + {19'd0, ra_burst_beats, 4'b0};
                                ra_remaining <= ra_remaining - {19'd0, ra_burst_beats, 4'b0};
                                ra_state     <= RA_AR;
                            end
                        end
                    end
                end

                default: ra_state <= RA_IDLE;
            endcase

            if (!busy) stall_cnt <= 24'd0;
            else if (stall_cnt != 24'hFFFFFF) stall_cnt <= stall_cnt + 1'b1;
        end
    end

endmodule
