// A-owned diagnostic observer. No outputs affect the rendering/read path.
// Pixel words are captured on the FIRST missing-pixel clock. Core words are
// captured when the held pixel event has crossed three core synchronizer FFs.
// Data is bundled and held until the explicit REAR command is acknowledged.
module bullet_first_missing (
    input wire clk,input wire rstn,input wire pclk,
    input wire missing,input wire [255:0] pixel_context,
    input wire [1023:0] current_B_context,
    input wire [511:0] outer_context,input wire history_tick,input wire [223:0] history_context,
    input wire [1023:0] core_context,
    input wire [15:0] paddr,input wire psel,input wire penable,input wire pwrite,
    input wire [31:0] pwdata,output wire sel,output reg [31:0] prdata,
    output wire pslverr,output wire [31:0] core_clock_gray
);
    reg [31:0] core_clock;
    assign core_clock_gray=core_clock^(core_clock>>1);
    reg rearm,complete,armed_core;
    reg [1279:0] frozen;
    reg [255:0] held_pixel;
    reg captured,ack;
    (* async_reg="true" *) reg arm1,arm2;
    (* async_reg="true" *) reg cap1,cap2,cap3,ack1,ack2;
    wire handshake_busy=ack2!=rearm;
    wire busy=handshake_busy || !armed_core;
    wire extra_sel=psel && ((paddr>=16'h0280 && paddr<16'h0400) || paddr[15:11]==5'b00010);
    assign sel=psel && ((paddr>=16'h0180 && paddr<16'h0280) || extra_sel);
    wire [7:0] off=paddr-16'h0180;
    wire access=sel && penable;
    wire command=access && pwrite && paddr==16'h0188 &&
        pwdata==32'h52454152 && !busy;
    assign pslverr=access && ((|paddr[1:0]) ||
        (pwrite && !command));
    integer index;
    always @* begin
        prdata=0;index=off[7:2];
        if(extra_sel)prdata=history_data;
        else if(sel)case(index)
            0:prdata=32'h464d4953; // FMIS
            1:prdata={29'd0,busy,cap3,complete};
            2:prdata=0; // write REAR; other values/slave writes are rejected
            3:prdata=32'h00010002;
            default:begin
                if(index>=4 && index<44 && complete)
                    prdata=frozen[(index-4)*32+:32];
                if(index==44)prdata=32'h0000000f; // first-event/dual-domain capability
                // 45..63 reserved, read zero.
            end
        endcase
    end
    wire trigger=!busy && armed_core && cap3 && !complete;
    wire [31:0] history_data;
    bullet_diag_history history(.clk(clk),.rstn(rstn),.rearm(command),.trigger(trigger),
        .sample_tick(history_tick),.sample_context({history_context,core_clock}),
        .current_B_context(current_B_context),.outer_context(outer_context),.paddr(paddr),.prdata(history_data));
    always @(posedge pclk or negedge rstn) begin
        if(!rstn)begin arm1<=0;arm2<=0;ack<=0;captured<=0;held_pixel<=0;end
        else begin
            arm1<=rearm;arm2<=arm1;
            if(arm2!=ack)begin ack<=arm2;captured<=0;end
            else if(missing && !captured)begin
                held_pixel<=pixel_context;captured<=1;
            end
        end
    end
    always @(posedge clk or negedge rstn) begin
        if(!rstn)begin
            core_clock<=0;rearm<=0;complete<=0;armed_core<=1;frozen<=0;
            cap1<=0;cap2<=0;cap3<=0;ack1<=0;ack2<=0;
        end else begin
            core_clock<=core_clock+1'b1;
            cap1<=captured;cap2<=cap1;cap3<=cap2;ack1<=ack;ack2<=ack1;
            // cap3 cannot be a stale event after rearm: wait for the pixel
            // acknowledgement AND for its cleared captured level to return.
            if(command)begin rearm<=!rearm;complete<=0;armed_core<=0;end
            else if(!handshake_busy && !cap3)armed_core<=1;
            else if(!busy && armed_core && cap3 && !complete)begin
                frozen<={core_context[1023:32],core_clock,held_pixel};complete<=1;
            end
        end
    end
endmodule
