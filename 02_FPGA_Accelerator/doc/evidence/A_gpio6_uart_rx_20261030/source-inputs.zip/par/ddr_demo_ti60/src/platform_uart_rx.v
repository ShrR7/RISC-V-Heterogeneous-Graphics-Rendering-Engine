`timescale 1ns/1ps

module platform_uart_rx #(
    parameter integer CLOCK_HZ = 100000000,
    parameter integer BAUD = 115200
) (
    input wire clk,
    input wire reset,
    input wire rx,
    input wire [15:0] paddr,
    input wire psel,
    input wire penable,
    input wire pwrite,
    input wire [31:0] pwdata,
    output wire sel,
    output reg [31:0] prdata,
    output wire pready,
    output wire pslverr
);
    localparam integer BIT_CYCLES = (CLOCK_HZ + BAUD / 2) / BAUD;
    localparam integer TIMER_WIDTH = $clog2(BIT_CYCLES);
    localparam [2:0] RX_IDLE = 0, RX_START = 1, RX_DATA = 2,
                     RX_STOP = 3, RX_BREAK = 4;

    (* async_reg = "true" *) reg rx_meta;
    (* async_reg = "true" *) reg rx_sync;
    reg [2:0] rx_state;
    reg [TIMER_WIDTH-1:0] rx_timer;
    reg [2:0] rx_bit;
    reg [7:0] rx_shift;
    reg [7:0] rx_byte;
    reg rx_valid;
    reg rx_frame_error;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            rx_meta <= 1;
            rx_sync <= 1;
        end else begin
            rx_meta <= rx;
            rx_sync <= rx_meta;
        end
    end

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            rx_state <= RX_IDLE;
            rx_timer <= 0;
            rx_bit <= 0;
            rx_shift <= 0;
            rx_byte <= 0;
            rx_valid <= 0;
            rx_frame_error <= 0;
        end else begin
            rx_valid <= 0;
            rx_frame_error <= 0;
            case (rx_state)
                RX_IDLE: if (!rx_sync) begin
                    rx_timer <= BIT_CYCLES / 2 - 1;
                    rx_state <= RX_START;
                end
                RX_START: if (rx_timer != 0) rx_timer <= rx_timer - 1'b1;
                else if (rx_sync) rx_state <= RX_IDLE;
                else begin
                    rx_timer <= BIT_CYCLES - 1;
                    rx_bit <= 0;
                    rx_state <= RX_DATA;
                end
                RX_DATA: if (rx_timer != 0) rx_timer <= rx_timer - 1'b1;
                else begin
                    rx_shift[rx_bit] <= rx_sync;
                    rx_timer <= BIT_CYCLES - 1;
                    if (rx_bit == 7) rx_state <= RX_STOP;
                    else rx_bit <= rx_bit + 1'b1;
                end
                RX_STOP: if (rx_timer != 0) rx_timer <= rx_timer - 1'b1;
                else if (rx_sync) begin
                    rx_byte <= rx_shift;
                    rx_valid <= 1;
                    rx_state <= RX_IDLE;
                end else begin
                    rx_frame_error <= 1;
                    rx_state <= RX_BREAK;
                end
                RX_BREAK: if (rx_sync) rx_state <= RX_IDLE;
                default: rx_state <= RX_IDLE;
            endcase
        end
    end

    reg [7:0] fifo_mem [0:255];
    reg [7:0] read_ptr;
    reg [7:0] write_ptr;
    reg [8:0] fifo_count;
    reg [7:0] fifo_q;
    reg forward_valid;
    reg [7:0] forward_data;
    reg [31:0] overflow_count;
    reg [31:0] frame_error_count;

    assign sel = psel && paddr[15:5] == (16'h0900 >> 5);
    assign pready = 1;
    assign pslverr = 0;
    wire access = sel && penable;
    wire control_write = access && pwrite && paddr[4:0] == 5'h14;
    wire flush = control_write && pwdata[0];
    wire clear_stats = control_write && pwdata[1];
    wire pop = access && !pwrite && paddr[4:0] == 5'h04 && fifo_count != 0 && !flush;
    wire push = rx_valid && (fifo_count != 256 || pop) && !flush;
    wire overflow = rx_valid && fifo_count == 256 && !pop && !flush;
    wire [7:0] read_address = read_ptr + pop;
    wire [7:0] head_data = forward_valid ? forward_data : fifo_q;

    always @(posedge clk) begin
        if (push) fifo_mem[write_ptr] <= rx_byte;
        fifo_q <= fifo_mem[read_address];
        forward_data <= rx_byte;
    end

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            read_ptr <= 0;
            write_ptr <= 0;
            fifo_count <= 0;
            forward_valid <= 0;
            overflow_count <= 0;
            frame_error_count <= 0;
        end else begin
            forward_valid <= push && write_ptr == read_address;
            if (flush) begin
                read_ptr <= 0;
                write_ptr <= 0;
                fifo_count <= 0;
                forward_valid <= 0;
            end else begin
                if (pop) read_ptr <= read_ptr + 1'b1;
                if (push) write_ptr <= write_ptr + 1'b1;
                case ({push, pop})
                    2'b10: fifo_count <= fifo_count + 1'b1;
                    2'b01: fifo_count <= fifo_count - 1'b1;
                    default: ;
                endcase
            end
            if (clear_stats) begin
                overflow_count <= {31'd0, overflow};
                frame_error_count <= {31'd0, rx_frame_error};
            end else begin
                if (overflow && overflow_count != 32'hFFFFFFFF)
                    overflow_count <= overflow_count + 1'b1;
                if (rx_frame_error && frame_error_count != 32'hFFFFFFFF)
                    frame_error_count <= frame_error_count + 1'b1;
            end
        end
    end

    always @(*) begin
        prdata = 0;
        if (sel) begin
            case (paddr[4:0])
                5'h00: prdata = 32'h55365258;
                5'h04: prdata = fifo_count != 0 ? {1'b1, 23'd0, head_data} : 0;
                5'h08: prdata = {23'd0, fifo_count};
                5'h0C: prdata = overflow_count;
                5'h10: prdata = frame_error_count;
                5'h18: prdata = BAUD;
                5'h1C: prdata = {16'h0001, 12'd0, rx_sync, rx_state != RX_IDLE,
                                fifo_count == 256, fifo_count == 0};
                default: ;
            endcase
        end
    end
endmodule
