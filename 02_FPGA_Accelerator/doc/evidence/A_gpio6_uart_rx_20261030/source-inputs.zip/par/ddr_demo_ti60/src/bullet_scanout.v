// Team A: atomic rows across core/pixel clocks. B's line RAM remains owned
// by B until every synchronous read result is copied and line_ack is pulsed.
// Eight 2048-pixel slots contain 1280 useful RGB565 pixels each. Gray pointers
// publish only complete rows; row/frame tags remain stable until retirement.
module bullet_scanout (
    input wire clk, input wire rstn, input wire pclk, input wire prstn,
    input wire mode_req, input wire clear_stats,
    input wire [7:0] render_epoch, input wire render_valid,
    input wire line_done, input wire [15:0] line_num, input wire line_bank,
    output reg [10:0] disp_rd_idx, output reg disp_rd_bank,
    input wire [15:0] disp_rd_data, output reg line_ack,
    input wire [15:0] h_cnt, input wire [15:0] v_cnt, input wire de,
    output wire [15:0] pix, output wire have,
    output reg mode_active_pixel, output wire mode_active_core,
    output wire frame_tick, output wire [7:0] frame_epoch,
    output wire copy_busy, output wire [3:0] queued_lines,
    output wire [31:0] missing_pixels, output wire [31:0] missing_lines,
    output wire [31:0] displayed_frames,
    input wire [31:0] debug_core_gray, input wire [31:0] debug_legacy_pixel,
    output wire debug_missing,output wire [255:0] debug_pixel,
    output reg debug_line_toggle,output reg [31:0] debug_line_context,
    output wire [31:0] debug_copy
);
    wire reset_n = rstn && prstn;
    localparam [1:0] IDLE=0, PRIME=1, COPY=2, ACK_GAP=3;
    reg [1:0] state;
    reg [10:0] write_idx;
    reg [8:0] copy_row;
    reg [7:0] copy_epoch;
    reg copy_publish;
    reg [15:0] rows [0:16383];
    // Tiny bundled metadata is deliberately FF storage, not a RAM with an
    // asynchronous read port. The pixel-side mux selects only committed tags.
    reg [16:0] tag0,tag1,tag2,tag3,tag4,tag5,tag6,tag7;
    reg [16:0] head_tag;
    reg [3:0] wr_bin, wr_gray, rd_bin, rd_gray;
    (* async_reg="true" *) reg [3:0] rd_g1,rd_g2,wr_g1,wr_g2;
    function [3:0] gray4(input [3:0] x); gray4=x^(x>>1); endfunction
    function [3:0] bin4(input [3:0] x);
        begin bin4[3]=x[3];bin4[2]=bin4[3]^x[2];
            bin4[1]=bin4[2]^x[1];bin4[0]=bin4[1]^x[0]; end
    endfunction
    function [31:0] gray32(input [31:0] x); gray32=x^(x>>1); endfunction
    function [31:0] bin32(input [31:0] x);
        integer i;begin bin32[31]=x[31];
            for(i=30;i>=0;i=i-1) bin32[i]=bin32[i+1]^x[i]; end
    endfunction
    wire [3:0] retired_core=bin4(rd_g2);
    wire full=(wr_bin[3]!=retired_core[3]) && (wr_bin[2:0]==retired_core[2:0]);
    wire nonempty=rd_gray!=wr_g2;
    assign queued_lines=wr_bin-retired_core;
    assign copy_busy=state!=IDLE;
    always @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin rd_g1<=0;rd_g2<=0;end
        else begin rd_g1<=rd_gray;rd_g2<=rd_g1;end
    end
    always @(posedge pclk or negedge reset_n) begin
        if(!reset_n) begin wr_g1<=0;wr_g2<=0;end
        else begin wr_g1<=wr_gray;wr_g2<=wr_g1;end
    end
    // Single write port, whole 16-bit words. No reset on the RAM/read port.
    always @(posedge clk) begin
        if(state==COPY && copy_publish)
            rows[{wr_bin[2:0],write_idx}]<=disp_rd_data;
    end
    always @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin
            state<=IDLE;write_idx<=0;disp_rd_idx<=0;disp_rd_bank<=0;
            line_ack<=0;wr_bin<=0;wr_gray<=0;copy_row<=0;
            copy_epoch<=0;copy_publish<=0;
        end else begin
            line_ack<=0;
            case(state)
                IDLE: if(line_done && (!full || !render_valid)) begin
                    disp_rd_idx<=0;disp_rd_bank<=line_bank;write_idx<=0;
                    copy_row<=line_num[8:0];copy_epoch<=render_epoch;
                    copy_publish<=render_valid;state<=PRIME;
                end
                PRIME: begin disp_rd_idx<=1;state<=COPY;end
                COPY: begin
                    if(disp_rd_idx<1279) disp_rd_idx<=disp_rd_idx+1'b1;
                    if(write_idx==1279) begin
                        if(copy_publish) begin
                            case(wr_bin[2:0])
                                0:tag0<={copy_epoch,copy_row};1:tag1<={copy_epoch,copy_row};
                                2:tag2<={copy_epoch,copy_row};3:tag3<={copy_epoch,copy_row};
                                4:tag4<={copy_epoch,copy_row};5:tag5<={copy_epoch,copy_row};
                                6:tag6<={copy_epoch,copy_row};7:tag7<={copy_epoch,copy_row};
                            endcase
                            wr_bin<=wr_bin+1'b1;wr_gray<=gray4(wr_bin+1'b1);
                        end
                        line_ack<=1;state<=ACK_GAP;
                    end else write_idx<=write_idx+1'b1;
                end
                // B can keep line_done high while promoting the second row.
                ACK_GAP: state<=IDLE;
            endcase
        end
    end

    (* async_reg="true" *) reg mode_p1,mode_p2;
    reg [7:0] pixel_epoch;
    reg video_toggle,clear_toggle;
    (* async_reg="true" *) reg vt1,vt2,vt3,vt4,ma1,ma2;
    (* async_reg="true" *) reg [7:0] ep1,ep2;
    (* async_reg="true" *) reg cl1,cl2,cl3;
    // The extra event stage gives the bundled, frame-stable epoch bus an
    // additional complete destination cycle beyond its two synchronizers.
    assign frame_tick=vt3^vt4;
    assign frame_epoch=ep2;
    assign mode_active_core=ma2;
    always @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin
            vt1<=0;vt2<=0;vt3<=0;vt4<=0;ma1<=0;ma2<=0;ep1<=0;ep2<=0;
            clear_toggle<=0;
        end else begin
            vt1<=video_toggle;vt2<=vt1;vt3<=vt2;vt4<=vt3;
            ma1<=mode_active_pixel;ma2<=ma1;ep1<=pixel_epoch;ep2<=ep1;
            if(clear_stats) clear_toggle<=!clear_toggle;
        end
    end
    always @(posedge pclk or negedge reset_n) begin
        if(!reset_n) begin mode_p1<=0;mode_p2<=0;cl1<=0;cl2<=0;cl3<=0;end
        else begin mode_p1<=mode_req;mode_p2<=mode_p1;
            cl1<=clear_toggle;cl2<=cl1;cl3<=cl2;end
    end
    always @* begin
        case(rd_bin[2:0])
            0:head_tag=tag0;1:head_tag=tag1;2:head_tag=tag2;3:head_tag=tag3;
            4:head_tag=tag4;5:head_tag=tag5;6:head_tag=tag6;7:head_tag=tag7;
        endcase
    end
    wire [8:0] head_row=head_tag[8:0];
    wire [7:0] head_epoch=head_tag[16:9];
    wire [15:0] next_v=(v_cnt==749)?16'd0:v_cnt+16'd1;
    wire [10:0] next_x=(h_cnt<1279)?h_cnt[10:0]+11'd1:11'd0;
    reg [15:0] pixel_q;
    reg line_have,bad_frame;
    reg [31:0] miss_px_p,miss_ln_p,good_p,miss_px_g,miss_ln_g,good_g;
    always @(posedge pclk) pixel_q<=rows[{rd_bin[2:0],next_x}];
    assign pix=(de && line_have)?pixel_q:16'd0;
    assign have=line_have;
    always @(posedge pclk or negedge reset_n) begin
        if(!reset_n) begin
            rd_bin<=0;rd_gray<=0;line_have<=0;mode_active_pixel<=0;
            pixel_epoch<=0;video_toggle<=0;bad_frame<=0;
            miss_px_p<=0;miss_ln_p<=0;good_p<=0;
            miss_px_g<=0;miss_ln_g<=0;good_g<=0;
        end else begin
            // Start preparation in the 30-line vertical blank. The mode is
            // stable for the complete next HDMI frame; legacy scanout runs on.
            if(v_cnt==720 && h_cnt==0) begin
                pixel_epoch<=pixel_epoch+1'b1;video_toggle<=!video_toggle;
                mode_active_pixel<=mode_p2;bad_frame<=0;
            end
            if(h_cnt==1649) begin
                line_have<=mode_active_pixel && next_v<480 && nonempty &&
                           head_epoch==pixel_epoch && head_row==next_v[8:0];
            end
            if(h_cnt==1279 && v_cnt<480 && mode_active_pixel && line_have) begin
                rd_bin<=rd_bin+1'b1;rd_gray<=gray4(rd_bin+1'b1);line_have<=0;
            end else if((h_cnt>=1280 || v_cnt>=480) && !line_have && nonempty &&
                (!mode_active_pixel || head_epoch!=pixel_epoch ||
                 (v_cnt>=480 && v_cnt<720) || (v_cnt<480 && head_row<next_v))) begin
                // Drop only rows that can no longer belong to this scan.
                // Future rows of this frame remain queued. Never shift a late
                // row into a different visible row or reuse an old-frame row.
                rd_bin<=rd_bin+1'b1;rd_gray<=gray4(rd_bin+1'b1);
            end
            if(mode_active_pixel && v_cnt<480 && de && !line_have) begin
                bad_frame<=1;
                if(miss_px_p!=32'hffffffff) begin
                    miss_px_p<=miss_px_p+1'b1;miss_px_g<=gray32(miss_px_p+1'b1);
                end
                if(h_cnt==0 && miss_ln_p!=32'hffffffff) begin
                    miss_ln_p<=miss_ln_p+1'b1;miss_ln_g<=gray32(miss_ln_p+1'b1);
                end
            end
            if(mode_active_pixel && v_cnt==479 && h_cnt==1279 && line_have && !bad_frame) begin
                good_p<=good_p+1'b1;good_g<=gray32(good_p+1'b1);
            end
            if(cl2^cl3) begin
                miss_px_p<=0;miss_ln_p<=0;good_p<=0;
                miss_px_g<=0;miss_ln_g<=0;good_g<=0;
            end
        end
    end
    (* async_reg="true" *) reg [31:0] pxg1,pxg2,lng1,lng2,gg1,gg2;
    always @(posedge clk or negedge reset_n) begin
        if(!reset_n) begin pxg1<=0;pxg2<=0;lng1<=0;lng2<=0;gg1<=0;gg2<=0;end
        else begin pxg1<=miss_px_g;pxg2<=pxg1;lng1<=miss_ln_g;lng2<=lng1;
            gg1<=good_g;gg2<=gg1;end
    end
    reg [31:0] debug_pixel_clock;
    (* async_reg="true" *) reg [31:0] debug_time1,debug_time2;
    always @(posedge pclk or negedge rstn) begin
        if(!rstn)begin debug_pixel_clock<=0;debug_time1<=0;debug_time2<=0;end
        else begin debug_pixel_clock<=debug_pixel_clock+1'b1;
            debug_time1<=debug_core_gray;debug_time2<=debug_time1;end
    end
    // Bundled line metadata is stable for a complete scanline. The core
    // observes the toggle after three FFs, then samples the held bundle.
    always @(posedge pclk or negedge reset_n)begin
        if(!reset_n)begin debug_line_toggle<=0;debug_line_context<=0;end
        else if(h_cnt==0)begin
            debug_line_toggle<=!debug_line_toggle;
            debug_line_context<={9'd0,mode_active_pixel,(bin4(wr_g2)-rd_bin),pixel_epoch,v_cnt[9:0]};
        end
    end
    assign debug_missing=reset_n && mode_active_pixel && v_cnt<480 && de && !line_have;
    // Low word first. Head tag is meaningful only when bit16(nonempty) is 1.
    assign debug_pixel={debug_legacy_pixel,miss_ln_p,miss_px_p,
        bin32(debug_time2),debug_pixel_clock,
        {17'd0,mode_active_pixel,line_have,nonempty,bin4(wr_g2)-rd_bin,wr_g2,rd_bin},
        {15'd0,head_tag},{4'd0,pixel_epoch,v_cnt[8:0],h_cnt[10:0]}};
    assign debug_copy={full,copy_publish,state,copy_epoch,copy_row,write_idx};
    assign missing_pixels=bin32(pxg2);
    assign missing_lines=bin32(lng2);
    assign displayed_frames=bin32(gg2);
endmodule
