//============================================================================
// File        : hdmi_sync.v
// Description : 720p60 video timing generator + framebuffer line fetch request
//               (pixel clock domain, Stage 3 / M2)
// Team        : Team A (FPGA/SoC/display platform)
//
// Timing (CEA-861 720p60, positive sync):
//   H: 1280 active + 110 front porch + 40 sync + 220 back porch = 1650
//   V:  720 active +   5 front porch +  5 sync +  20 back porch =  750
//   pixel clock 74.375 MHz -> 60.1 Hz
//
// Line fetch policy (A rtl10):
//   PREFETCH_LINES=1 preserves the legacy one-line schedule. It gives only
//   (HTOTAL-HACT-8) pclk of lead, about 4.9 us, NOT a full line period.
//   Production uses 8: fetch L+8 during line L blanking, and fetch rows 0..7
//   across the last active line / vertical blank. Eight buffered lines fit
//   in the existing 2048-word FIFO (8*160=1280 words at 720p).
//   Exactly VACT requests per frame. No old-buffer request is moved across
//   the existing swap point; row 0 starts only after fb_sel_active changes.
//   In prefetch mode reset starts in the last active line's blanking, so the
//   first visible frame has rows 0..7 primed instead of consuming row 8 early.
//   The top level queues descriptors while the unchanged B reader is busy.
//
// Clock domain crossing:
//   line_req_tgl TOGGLES on every request and is synchronized in the AXI
//   domain (2 FF + edge detect). A one-cycle pulse must NOT be used directly:
//   a 13.4 ns pixel-domain pulse can be missed by a 10 ns AXI clock.
//   line_addr is stable from one request to the next, so it may cross as a
//   multi-bit value together with the toggle.
//============================================================================

module hdmi_sync #(
    parameter integer PREFETCH_LINES = 1, // 1..min(VACT-1, vertical_blank+1)
    parameter [31:0] FB_BASE   = 32'h0020_0000,   // framebuffer FB0 base in DDR3
    parameter [31:0] FB1_BASE  = 32'h0040_0000,   // framebuffer FB1 base (Stage 6)
    parameter [31:0] FB_STRIDE = 32'd2560,        // bytes per line (720p RGB565)
    parameter [15:0] HACT = 16'd1280,
    parameter [15:0] HFP  = 16'd110,
    parameter [15:0] HST  = 16'd40,
    parameter [15:0] HBP  = 16'd220,
    parameter [15:0] VACT = 16'd720,
    parameter [15:0] VFP  = 16'd5,
    parameter [15:0] VST  = 16'd5,
    parameter [15:0] VBP  = 16'd20
) (
    input  wire        pclk,
    input  wire        prst_n,

    // ---- Stage 6 double-buffer swap (A-1) ---------------------------------
    input  wire        fb_sel_req,     // from FB_CTRL[0], APB clock domain
    output reg         fb_sel_active,  // buffer actually scanned out (0=FB0)

    // ---- framebuffer line request (goes to the AXI domain) ----------------
    output reg         line_req_tgl,   // toggles once per request
    output reg  [31:0] line_addr,      // DDR3 byte address of that line

    // ---- video timing ------------------------------------------------------
    output wire        hs,
    output wire        vs,
    output wire        de,
    output wire [15:0] h_cnt,
    output wire [15:0] v_cnt,
    output wire        line_start      // 1-cycle pulse at the first active pixel
);

    localparam [15:0] HTOTAL  = HACT + HFP + HST + HBP;   // 1650
    localparam [15:0] VTOTAL  = VACT + VFP + VST + VBP;   //  750
    localparam [15:0] HSYNC0  = HACT + HFP;               // 1390
    localparam [15:0] HSYNC1  = HACT + HFP + HST;         // 1430
    localparam [15:0] VSYNC0  = VACT + VFP;               //  725
    localparam [15:0] VSYNC1  = VACT + VFP + VST;         //  730

    reg [15:0] hc;
    reg [15:0] vc;

    assign h_cnt = hc;
    assign v_cnt = vc;

    assign hs = (hc >= HSYNC0) && (hc < HSYNC1);
    assign vs = (vc >= VSYNC0) && (vc < VSYNC1);
    assign de = (hc < HACT) && (vc < VACT);

    assign line_start = (hc == 16'd0) && (vc < VACT);

    // ---- H / V counters ----------------------------------------------------
    always @(posedge pclk or negedge prst_n) begin
        if (!prst_n) begin
            hc <= (PREFETCH_LINES > 1) ? HACT : 16'd0;
            vc <= (PREFETCH_LINES > 1) ? VACT-16'd1 : 16'd0;
        end else if (hc == (HTOTAL - 16'd1)) begin
            hc <= 16'd0;
            vc <= (vc == (VTOTAL - 16'd1)) ? 16'd0 : (vc + 16'd1);
        end else begin
            hc <= hc + 16'd1;
        end
    end

    // ---- request the NEXT line during the horizontal blanking --------------
    localparam [15:0] LOOKAHEAD = PREFETCH_LINES;
    wire fetch_active = vc < (VACT-LOOKAHEAD);
    wire fetch_wrap = (vc >= VACT-16'd1) && (vc < VACT-16'd1+LOOKAHEAD);
    wire [15:0] next_line = fetch_wrap ? vc-(VACT-16'd1) : vc+LOOKAHEAD;
    wire req_now = (hc == HACT+16'd8) && (fetch_active || fetch_wrap);

    //========================================================================
    // Stage 6: double-buffer swap (A-1, see 三人今日执行计划_关卡6.md §5.3)
    //
    // fb_sel_req comes from gpu_top's FB_CTRL[0] in the APB (core) clock
    // domain; fb_sel_active is the buffer this module is scanning out, in the
    // pclk domain. Both are single-bit levels, so a 2-flop synchronizer each
    // way is enough (the reverse direction is done in ddr3_example_top.v).
    //
    // The request is applied ONLY at the safe swap point vc == VACT-1 &&
    // hc == 0 (start of the last active line):
    //   - line VACT-1 was already requested PREFETCH_LINES lines earlier; it keeps
    //     the old base and is unaffected;
    //   - the request for line 0 of the NEXT frame is issued later, at
    //     hc == HACT+8 of this same line, so it already uses the new base;
    //   - therefore no scan line ever mixes two buffers, and no frame does
    //     either (no tearing).
    //========================================================================
    reg req_meta, req_sync;

    always @(posedge pclk or negedge prst_n) begin
        if (!prst_n) begin
            req_meta <= 1'b0;
            req_sync <= 1'b0;
        end else begin
            req_meta <= fb_sel_req;
            req_sync <= req_meta;
        end
    end

    wire swap_point = (hc == 16'd0) && (vc == (VACT - 16'd1));

    always @(posedge pclk or negedge prst_n) begin
        if (!prst_n)                       fb_sel_active <= 1'b0;
        else if (swap_point)               fb_sel_active <= req_sync;
    end

    wire [31:0] fb_base = fb_sel_active ? FB1_BASE : FB_BASE;

    always @(posedge pclk or negedge prst_n) begin
        if (!prst_n) begin
            line_req_tgl <= 1'b0;
            line_addr    <= FB_BASE;
        end else if (req_now) begin
            line_req_tgl <= ~line_req_tgl;
            line_addr    <= fb_base + (next_line * FB_STRIDE);
        end
    end

endmodule
