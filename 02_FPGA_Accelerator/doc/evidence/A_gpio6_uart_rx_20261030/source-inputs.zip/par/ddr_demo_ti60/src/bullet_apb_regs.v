// Team A: separate APB page, absolute peripheral offsets 0x0100..0x017f.
// Frame requests wait for the scanout's vertical-blank event. No command can
// reset/cancel an AXI burst; cancel only removes a software frame request.
module bullet_apb_regs (
    input wire clk,input wire rstn,input wire [15:0] paddr,input wire psel,
    input wire penable,input wire pwrite,input wire [31:0] pwdata,
    output wire sel,output reg [31:0] prdata,output wire pready,output wire pslverr,
    output reg mode_req,output reg repeat_mode,
    output reg [31:0] atlas_base,output reg [31:0] desc_base,
    output reg [31:0] desc_count,output reg [31:0] bg_base,
    output reg [15:0] color_key,output reg alpha_en,output reg [5:0] alpha_val,
    output reg start_atlas,output reg start_frame,output reg clear_stats,
    output reg [7:0] render_epoch,
    input wire atlas_busy,input wire atlas_done,input wire atlas_error,
    input wire frame_busy,input wire frame_done,input wire frame_error,
    input wire [31:0] max_line_cycles,
    input wire video_mode_active,input wire frame_tick,input wire [7:0] video_epoch,
    input wire copy_busy,input wire [3:0] queued_lines,
    input wire [31:0] missing_pixels,input wire [31:0] missing_lines,
    input wire [31:0] displayed_frames,
    output reg armed,output reg atlas_ready
);
    assign sel=psel && paddr[15:7]==9'd2;
    assign pready=1;
    wire access=sel && penable;
    wire wr=access && pwrite;
    wire [6:0] off=paddr[6:0];
    reg known,writable,configuration;
    reg [31:0] done_count,skipped_frames,command_errors,frame_cycles,last_frame_cycles;
    reg [31:0] last_max_line;
    reg atlas_busy_q,frame_busy_q,halted;
    wire active_busy=atlas_busy || frame_busy || start_atlas || start_frame;
    wire locked=active_busy || armed;
    wire config_error=configuration && locked;
    wire ctrl_error=(off==7'h04) && (|pwdata[31:2]);
    wire alpha_error=(off==7'h24) && ((pwdata & 32'hfffffec0)!=0 || pwdata[5:0]>32);
    wire command=(off==7'h08);
    wire atlas_cmd=pwdata[0];wire frame_cmd=pwdata[1];wire cancel_cmd=pwdata[3];
    wire command_bad=command && ((|pwdata[31:4]) || (atlas_cmd && frame_cmd) ||
        (frame_cmd && cancel_cmd) ||
        (atlas_cmd && (locked || (|atlas_base[3:0]))) ||
        (frame_cmd && (locked || !atlas_ready || desc_count>32'd2048 ||
                       (|desc_base[3:0]) || (|bg_base[3:0]))));
    assign pslverr=access && ((|paddr[1:0]) || !known ||
        (pwrite && (!writable || config_error || ctrl_error || alpha_error || command_bad)));
    always @* begin
        known=1;writable=0;configuration=0;prdata=0;
        case(off)
            7'h00:prdata=32'h42554c39; // BUL9; existing GPU1 ID is unchanged.
            7'h04:begin prdata={30'd0,repeat_mode,mode_req};writable=1;end
            7'h08:begin prdata=0;writable=1;end
            7'h0c:prdata={21'd0,halted,copy_busy,video_mode_active,armed,atlas_ready,
                frame_error,atlas_error,frame_done,atlas_done,frame_busy,atlas_busy};
            7'h10:begin prdata=atlas_base;writable=1;configuration=1;end
            7'h14:begin prdata=desc_base;writable=1;configuration=1;end
            7'h18:begin prdata=desc_count;writable=1;configuration=1;end
            7'h1c:begin prdata=bg_base;writable=1;configuration=1;end
            7'h20:begin prdata={16'd0,color_key};writable=1;configuration=1;end
            7'h24:begin prdata={23'd0,alpha_en,2'd0,alpha_val};writable=1;configuration=1;end
            7'h28:prdata=max_line_cycles;
            7'h2c:prdata=missing_pixels;
            7'h30:prdata=missing_lines;
            7'h34:prdata=displayed_frames;
            7'h38:prdata=done_count;
            7'h3c:prdata=skipped_frames;
            7'h40:prdata={23'd0,copy_busy,4'd0,queued_lines};
            7'h44:prdata=last_max_line;
            7'h48:prdata=command_errors;
            7'h4c:prdata=last_frame_cycles;
            7'h50:prdata=32'h00010007; // page revision 1 + first-missing diagnostic page, RGB565/16x16
            7'h54:prdata=32'd2048;
            7'h58:prdata=32'd32;
            default:known=0;
        endcase
        if(!sel)prdata=0;
    end
    always @(posedge clk or negedge rstn) begin
        if(!rstn) begin
            mode_req<=0;repeat_mode<=0;atlas_base<=0;desc_base<=0;desc_count<=0;
            bg_base<=0;color_key<=0;alpha_en<=0;alpha_val<=16;
            start_atlas<=0;start_frame<=0;clear_stats<=0;render_epoch<=0;
            armed<=0;atlas_ready<=0;atlas_busy_q<=0;frame_busy_q<=0;halted<=0;
            done_count<=0;skipped_frames<=0;command_errors<=0;
            frame_cycles<=0;last_frame_cycles<=0;last_max_line<=0;
        end else begin
            start_atlas<=0;start_frame<=0;clear_stats<=0;
            atlas_busy_q<=atlas_busy;frame_busy_q<=frame_busy;
            if(atlas_busy_q && !atlas_busy)atlas_ready<=atlas_done && !atlas_error;
            if(frame_busy && frame_cycles!=32'hffffffff)frame_cycles<=frame_cycles+1'b1;
            if(frame_busy_q && !frame_busy && frame_done) begin
                last_frame_cycles<=frame_cycles;last_max_line<=max_line_cycles;
                if(frame_error)begin halted<=1;armed<=0;end
                else done_count<=done_count+1'b1;
            end
            if(frame_tick && armed && video_mode_active && !halted &&
                !(frame_busy_q && !frame_busy && frame_done && frame_error)) begin
                if(!active_busy && atlas_ready)begin
                    start_frame<=1;render_epoch<=video_epoch;frame_cycles<=0;
                    if(!repeat_mode)armed<=0;
                end else if(skipped_frames!=32'hffffffff)skipped_frames<=skipped_frames+1'b1;
            end
            if(wr && pslverr && command_errors!=32'hffffffff)
                command_errors<=command_errors+1'b1;
            if(wr && !pslverr) begin
                case(off)
                    7'h04:begin mode_req<=pwdata[0];repeat_mode<=pwdata[1];end
                    7'h08:begin
                        if(pwdata[2])begin
                            clear_stats<=1;command_errors<=0;done_count<=0;skipped_frames<=0;
                        end
                        if(atlas_cmd)begin start_atlas<=1;atlas_ready<=0;end
                        if(frame_cmd)begin armed<=1;halted<=0;end
                        if(cancel_cmd)armed<=0;
                    end
                    7'h10:atlas_base<=pwdata;
                    7'h14:desc_base<=pwdata;
                    7'h18:desc_count<=pwdata;
                    7'h1c:bg_base<=pwdata;
                    7'h20:color_key<=pwdata[15:0];
                    7'h24:begin alpha_en<=pwdata[8];alpha_val<=pwdata[5:0];end
                    default:begin end
                endcase
            end
        end
    end
endmodule
