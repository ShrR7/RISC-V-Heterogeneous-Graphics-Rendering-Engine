//============================================================================
// File        : bullet_desc_loader.v
// Description : Stage 9 bullet-engine front end: load an array of 16-byte
//               bullet descriptors from DDR into on-chip RAM, then build
//               vertical-band lists for the scanline renderer.
// Team        : Team B (RTL Accelerator)
//
// Descriptor layout (little-endian, 16 B):
//   +0 s16 x, +2 s16 y, +4 s16 vx, +6 s16 vy,
//   +8 u16 sprite_id, +10 u16 flags (bit0 active), +12 u32 reserved.
//
// Bands: 30 bands of 16 display lines (480 lines total).  A 16-pixel-high
// sprite can straddle at most two bands, so a scanline only needs the
// current band and the previous one.  Descriptors are appended in their
// original order, preserving overlap/alpha semantics.
//
// Flow:
//   1. AXI-read all descriptors (bursts <=16 beats, never cross 4 KB;
//      RREADY stays high for the whole burst -- display-friendly rule).
//      Count descriptors per band while loading.
//   2. PREFIX: one cycle per band, compute band_base[] = prefix sum.
//   3. SCAN: read each descriptor from on-chip RAM and append its ID to
//      band_mem[band_base[b] + band_used[b]].
//
// Error semantics: CNT=0 -> done with no traffic; base must be 16B aligned;
// CNT>MAX_DESC -> done+error before any traffic.  RRESP!=OKAY flags error,
// drains the current burst, and stops before any further AR.  Watchdog is
// progress-reset, so a healthy full-2048 load never times out.
//
// RAM read template: each memory has plain synchronous read registers.
// band_base/band_used are tiny register arrays, not BRAM.
//============================================================================

module bullet_desc_loader #(
    parameter MAX_DESC = 2048,
    parameter BANDS    = 30,
    parameter DESC_W   = 11,       // enough for 0..2047
    parameter PTR_W    = 12        // enough for 0..2048
)(
    input  wire         clk,
    input  wire         rstn,
    input  wire         start,
    output reg          busy,
    output reg          done,
    output reg          error,
    input  wire [31:0]  desc_base,
    input  wire [15:0]  desc_count,

    output reg  [31:0]  m_axi_araddr,
    output reg  [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output reg          m_axi_arvalid,
    input  wire         m_axi_arready,
    input  wire [127:0] m_axi_rdata,
    input  wire         m_axi_rlast,
    input  wire [1:0]   m_axi_rresp,
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready,

    // descriptor RAM read port (synchronous, one-cycle latency)
    input  wire [DESC_W-1:0] desc_rd_idx,
    output reg  [127:0]      desc_rd_data,

    // band metadata read ports (synchronous)
    input  wire [4:0]        band_rd_idx,
    output reg  [PTR_W-1:0]  band_rd_base,
    output reg  [PTR_W-1:0]  band_rd_count,

    // band ID memory read port (synchronous)
    input  wire [PTR_W-1:0]  band_mem_rd_addr,
    output reg  [DESC_W-1:0] band_mem_rd_id,
    output wire [2:0]        dbg_state
);

    assign dbg_state = state;

    assign m_axi_arsize  = 3'b100;       // 16 B per descriptor/beat
    assign m_axi_arburst = 2'b01;        // INCR
    assign m_axi_rready  = (state == ST_R);

    localparam [2:0] ST_IDLE   = 3'd0,
                     ST_AR     = 3'd1,
                     ST_R      = 3'd2,
                     ST_PREFIX = 3'd3,
                     ST_SCAN_RD= 3'd4,
                     ST_SCAN_WR= 3'd5;

    reg [2:0] state;

    reg [31:0] ar_addr;
    reg [15:0] desc_left;
    reg [PTR_W-1:0] wr_idx;
    reg [PTR_W-1:0] scan_idx;
    reg [8:0] burst_beats;
    reg [5:0] prefix_idx;
    reg       stop_after_burst;

    reg [127:0] desc_ram [0:MAX_DESC-1];
    reg [DESC_W-1:0] band_mem [0:MAX_DESC-1];
    reg [PTR_W-1:0] band_base  [0:BANDS-1];
    reg [PTR_W-1:0] band_count [0:BANDS-1];
    reg [PTR_W-1:0] band_used  [0:BANDS-1];

    reg [127:0] scan_data;

    localparam [23:0] STALL_LIMIT = 24'd200000;
    reg [23:0] stall_cnt;
    wire stall_abort = busy && (stall_cnt >= STALL_LIMIT);

    integer i;

    function desc_active(input [127:0] d);
        reg signed [15:0] yy;
        begin
            yy = d[31:16];
            desc_active = d[80] && (yy > -16) && (yy < 480);
        end
    endfunction

    function [4:0] desc_band(input [127:0] d);
        reg signed [15:0] yy;
        begin
            yy = d[31:16];
            if (yy < 0)
                desc_band = 5'd0;
            else
                desc_band = yy[8:4];
        end
    endfunction

    // burst = min(16, desc_left, beats left to 4 KB boundary)
    wire [12:0] bytes_to_4k = 13'h1000 - {1'b0, ar_addr[11:0]};
    wire [8:0]  beats_to_4k = {1'b0, bytes_to_4k[12:4]};
    wire [8:0]  burst_calc  = (desc_left > 16'd16) ? 9'd16 : desc_left[8:0];
    wire [8:0]  burst_next  = (burst_calc > beats_to_4k) ? beats_to_4k : burst_calc;

    // External/internal read ports.  The two descriptor reads are plain
    // synchronous ports; no combinational memory mux is used.
    always @(posedge clk) begin
        desc_rd_data   <= desc_ram[desc_rd_idx];
        scan_data      <= desc_ram[scan_idx[DESC_W-1:0]];
        band_rd_base   <= band_base[band_rd_idx];
        band_rd_count  <= band_count[band_rd_idx];
        band_mem_rd_id <= band_mem[band_mem_rd_addr];
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            state            <= ST_IDLE;
            busy             <= 1'b0;
            done             <= 1'b0;
            error            <= 1'b0;
            ar_addr          <= 32'd0;
            desc_left        <= 16'd0;
            wr_idx           <= {PTR_W{1'b0}};
            scan_idx         <= {PTR_W{1'b0}};
            burst_beats      <= 9'd0;
            prefix_idx       <= 6'd0;
            stop_after_burst <= 1'b0;
            stall_cnt        <= 24'd0;
            m_axi_araddr     <= 32'd0;
            m_axi_arlen      <= 8'd0;
            m_axi_arvalid    <= 1'b0;
            for (i = 0; i < BANDS; i = i + 1) begin
                band_base[i]  <= {PTR_W{1'b0}};
                band_count[i] <= {PTR_W{1'b0}};
                band_used[i]  <= {PTR_W{1'b0}};
            end
        end else if (stall_abort) begin
            state         <= ST_IDLE;
            busy          <= 1'b0;
            done          <= 1'b1;
            error         <= 1'b1;
            m_axi_arvalid <= 1'b0;
            stall_cnt     <= 24'd0;
        end else begin
            if (!busy || (m_axi_arvalid && m_axi_arready) ||
                (m_axi_rvalid && m_axi_rready) ||
                (state == ST_PREFIX) || (state == ST_SCAN_RD) ||
                (state == ST_SCAN_WR))
                stall_cnt <= 24'd0;
            else if (stall_cnt != 24'hFFFFFF)
                stall_cnt <= stall_cnt + 1'b1;

            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        done  <= 1'b0;
                        error <= 1'b0;
                        for (i = 0; i < BANDS; i = i + 1) begin
                            band_base[i]  <= {PTR_W{1'b0}};
                            band_count[i] <= {PTR_W{1'b0}};
                            band_used[i]  <= {PTR_W{1'b0}};
                        end
                        if (desc_count == 16'd0) begin
                            done <= 1'b1;
                        end else if (|desc_base[3:0] ||
                                     (desc_count > MAX_DESC)) begin
                            done  <= 1'b1;
                            error <= 1'b1;
                        end else begin
                            busy             <= 1'b1;
                            ar_addr          <= desc_base;
                            desc_left        <= desc_count;
                            wr_idx           <= {PTR_W{1'b0}};
                            scan_idx         <= {PTR_W{1'b0}};
                            stop_after_burst <= 1'b0;
                            state            <= ST_AR;
                        end
                    end
                end

                ST_AR: begin
                    if (!m_axi_arvalid) begin
                        m_axi_araddr  <= ar_addr;
                        m_axi_arlen   <= burst_next[7:0] - 8'd1;
                        burst_beats   <= burst_next;
                        m_axi_arvalid <= 1'b1;
                    end else if (m_axi_arready) begin
                        m_axi_arvalid <= 1'b0;
                        state         <= ST_R;
                    end
                end

                ST_R: begin
                    if (m_axi_rvalid && m_axi_rready) begin
                        desc_ram[wr_idx[DESC_W-1:0]] <= m_axi_rdata;
                        wr_idx <= wr_idx + 1'b1;
                        if (desc_active(m_axi_rdata))
                            band_count[desc_band(m_axi_rdata)] <=
                                band_count[desc_band(m_axi_rdata)] + 1'b1;
                        if (m_axi_rresp != 2'b00) begin
                            error            <= 1'b1;
                            stop_after_burst <= 1'b1;
                        end
                        if (m_axi_rlast) begin
                            if (stop_after_burst || (m_axi_rresp != 2'b00)) begin
                                state <= ST_IDLE;
                                busy  <= 1'b0;
                                done  <= 1'b1;
                            end else if (desc_left == {7'd0, burst_beats}) begin
                                prefix_idx <= 6'd0;
                                state      <= ST_PREFIX;
                            end else begin
                                ar_addr   <= ar_addr + {23'd0, burst_beats, 4'b0};
                                desc_left <= desc_left - {7'd0, burst_beats};
                                state     <= ST_AR;
                            end
                        end
                    end
                end

                ST_PREFIX: begin
                    if (prefix_idx == 6'd0)
                        band_base[0] <= {PTR_W{1'b0}};
                    else
                        band_base[prefix_idx] <=
                            band_base[prefix_idx-1] + band_count[prefix_idx-1];
                    band_used[prefix_idx] <= {PTR_W{1'b0}};
                    if (prefix_idx == BANDS-1) begin
                        scan_idx <= {PTR_W{1'b0}};
                        state    <= ST_SCAN_RD;
                    end else begin
                        prefix_idx <= prefix_idx + 1'b1;
                    end
                end

                ST_SCAN_RD: begin
                    // scan_data <= desc_ram[scan_idx] happens in the read-port
                    // block; one cycle later ST_SCAN_WR consumes it.
                    state <= ST_SCAN_WR;
                end

                ST_SCAN_WR: begin
                    if (desc_active(scan_data)) begin
                        band_mem[band_base[desc_band(scan_data)] +
                                 band_used[desc_band(scan_data)]] <=
                            scan_idx[DESC_W-1:0];
                        band_used[desc_band(scan_data)] <=
                            band_used[desc_band(scan_data)] + 1'b1;
                    end
                    if (scan_idx == desc_count-1) begin
                        state <= ST_IDLE;
                        busy  <= 1'b0;
                        done  <= 1'b1;
                    end else begin
                        scan_idx <= scan_idx + 1'b1;
                        state    <= ST_SCAN_RD;
                    end
                end

                default: state <= ST_IDLE;
            endcase
        end
    end

endmodule
