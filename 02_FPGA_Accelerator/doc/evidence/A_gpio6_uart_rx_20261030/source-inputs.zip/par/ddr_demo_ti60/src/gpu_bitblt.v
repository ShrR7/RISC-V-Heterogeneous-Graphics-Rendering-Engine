//============================================================================
// File        : gpu_bitblt.v
// Description : BitBlt engine with Color Keying + Alpha Blending for the
//               2D GPU accelerator (Stage 5 op=10; Stage 7 alpha modifier
//               and write-path optimizations; Stage 8 BLIT_BATCH list mode
//               with on-chip sprite cache)
// Team        : Team B (RTL Accelerator)
//
// Architecture (Stage 7 wr-opt 3, 2026-10-13: cross-line ping-pong):
//     Two cooperating FSMs replace the old linear READ->WRITE->loop:
//
//     * Read-ahead FSM (RA_*) streams whole lines over AXI into a DOUBLE
//       line buffer (line_bufA/B; alpha adds dst_bufA/B).  While the write
//       side streams line n out of buffer p, the read-ahead already fetches
//       line n+1 into buffer 1-p: the AXI read latency (~rd_lat cycles per
//       line) is hidden behind the write phase.  In alpha mode each
//       buffered line consists of the SRC line followed by the DST line.
//     * Write FSM (ST_WAIT/ST_WR/ST_DRAIN) unpacks pixels from the ready
//       buffer, applies color-key handling and alpha blending, and streams
//       pixels to the SHARED gpu_axi_master.  Per line it only pulses flush
//       (closing the trailing write group); the full B-drain wait happens
//       ONCE at the end of the operation (ST_DRAIN), not per line -- the
//       master's own group buffer serialises in-flight bursts safely.
//
//     Buffer handshake: fullA/fullB is set by the read-ahead when a buffer
//     holds a complete line and cleared by the write FSM when it starts
//     consuming it.  Kick rule: line k+1 is kicked into buffer 1-cur as soon
//     as the read-ahead is idle and that buffer is free (its previous line
//     has been fully streamed -- guaranteed by program order).  Both FSMs
//     live in ONE clocked process so every register has a single driver;
//     the two parts never touch the same flag in the same cycle (read-ahead
//     sets full[ra_buf], the write side clears full[cur], ra_buf == !cur).
//
// Colour key (wr-opt 1): leading key pixels of a line (before the first
//     opaque pixel) are consumed locally -- head margins stay free.  After
//     the first opaque pixel, key pixels are PRESENTED with pixel_hole=1:
//     they occupy their byte lane with wstrb=0 and the 16-byte write group
//     stays open across the hole.  All-hole groups are suppressed by the
//     master (no AXI traffic).  Background under holes/margins is preserved.
//
// Alpha (alpha_en = 1, CTRL bit[8] + ALPHA(0x30)): every non-key pixel is
//     blended per RGB565 channel against the buffered destination line:
//         out_c = (src_c * a + dst_c * (32 - a) + 16) >> 5      a = 0..32
//     (+16 = round-to-nearest).  a=32 degenerates to an exact copy; a=0
//     writes the destination back unchanged.  Key pixels are still holes.
//
// Stage 8 BLIT_BATCH (batch = CTRL bit[9], op=10):
//     Sprite parameters (SADDR/WIDTH/HEIGHT/strides/KEY/ALPHA) are written
//     once; the CPU places N destination addresses in DDR as a list of
//     4-byte entries at LIST_ADDR (0x34, 16B aligned), count in LIST_CNT
//     (0x38).  One command then blits the same sprite to all N targets:
//
//     * Sprite cache: if the whole sprite fits 4 KB (line_bytes*height <=
//       4096, line_bytes computed with the worst-case head offset 15), a
//       loader FSM (LD_*) reads the sprite from DDR EXACTLY ONCE into
//       sprite_cache (256 x 16 B BRAM) before the first instance.  Cache
//       line y is stored raw (16B-aligned words incl. head bytes) at
//       y*line_bytes; ho_tab[y] remembers (src+y*src_stride)[3:0].
//     * Instance loop (ST_B_LIST): destination i is pulled from a 128-bit
//       list beat (4 entries per beat, fetched on demand).  Every instance
//       streams `height` lines; every line end pulses flush (the shared
//       master's group assembler requires a group boundary wherever the
//       pixel stream is not address-contiguous -- same rule as gpu_fill's
//       batch mode).
//     * Non-alpha cached instances need NO line buffer and NO read-ahead:
//       pixels flow straight from sprite_cache, one bubble per line
//       (ST_B_REARM re-pipes the BRAM read).
//     * Alpha cached instances still RMW the destination: the read-ahead
//       runs in dst-only mode (kick_dst_only), fetching each dst line into
//       dst_bufA/B while the src pixel comes from sprite_cache.
//     * Sprites larger than the cache DEGRADE to the normal per-instance
//       flow (src re-read from DDR for every instance): only the CPU
//       dispatch tax is saved, pixels stay identical.
//     * LIST_CNT=0 -> immediate done, zero traffic; LIST_ADDR misaligned
//       -> done + error, zero traffic (same semantics as FILL_BATCH).
//
// Constraints: identical to gpu_copy (even addresses, no overlap,
//   4 KB line buffer limit per buffer, zero sizes -> immediate done).
//   color_key is the COLOR register (0x20) reinterpreted while op=10
//   (Stage 5 frozen protocol amendment, see interface_spec.md).  In alpha
//   mode the DST line must also fit the 4 KB line buffer.
//
//   Final drain handshake with the shared master is identical to gpu_copy:
//   wr_aw_hs / wr_b_hs / wr_idle + 2-cycle settle after the final flush.
//============================================================================

`include "gpu_pkg.vh"

module gpu_bitblt #(
    parameter MAX_LINE_BEATS = 256          // line buffer: 256 x 16 B = 4 KB
)(
    input  wire         clk,
    input  wire         rstn,

    input  wire         start,              // 1-cycle pulse (op == OP_BITBLT)
    output reg          busy,
    output reg          done,               // level: stays 1 until next start
    output reg          error,              // sticky until next start

    input  wire [31:0]  src_addr,
    input  wire [31:0]  dst_addr,
    input  wire [15:0]  width,              // pixels per line
    input  wire [15:0]  height,             // lines
    input  wire [31:0]  src_stride,         // bytes per line (source)
    input  wire [31:0]  dst_stride,         // bytes per line (dest)
    input  wire [15:0]  color_key,          // transparent color (RGB565)
    input  wire         alpha_en,           // Stage 7: CTRL bit[8], op=10 modifier
    input  wire [5:0]   alpha_val,          // Stage 7: ALPHA(0x30), 0~32
    input  wire         batch,              // Stage 8: CTRL bit[9], op=10 modifier
    input  wire [31:0]  list_addr,          // Stage 8: LIST_ADDR(0x34), 4B/entry
    input  wire [31:0]  list_cnt,           // Stage 8: LIST_CNT(0x38), full u32

    // ---- pixel stream out (to shared gpu_axi_master in gpu_top) -----------
    output wire [31:0]  pixel_addr,
    output wire [15:0]  pixel_data,
    output wire         pixel_valid,
    output wire         pixel_hole,         // wr-opt 1: key hole inside a group
    input  wire         pixel_ready,
    output reg          flush,              // 1-cycle pulse: end-of-line flush

    // ---- shared write-channel observation (from gpu_top) ------------------
    input  wire         wr_aw_hs,
    input  wire         wr_b_hs,
    input  wire         wr_idle,

    // ---- AXI4 read address channel ----------------------------------------
    output wire [31:0]  m_axi_araddr,
    output wire [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output wire         m_axi_arvalid,
    input  wire         m_axi_arready,

    // ---- AXI4 read data channel -------------------------------------------
    input  wire [127:0] m_axi_rdata,
    input  wire         m_axi_rlast,
    input  wire [1:0]   m_axi_rresp,        // 00 = OKAY; others set `error`
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready
);

    // AR constants (same as gpu_axi_reader: 16-byte beats, INCR)
    assign m_axi_arsize  = 3'b100;
    assign m_axi_arburst = 2'b01;

    // ---- write FSM states --------------------------------------------------
    localparam [2:0] ST_IDLE    = 3'd0,
                     ST_WAIT    = 3'd1,  // wait for full[cur]
                     ST_WR      = 3'd2,  // stream pixels of buffer cur / cache
                     ST_DRAIN   = 3'd3,  // op end: wait master drain
                     ST_B_LD    = 3'd4,  // batch: sprite cache load in flight
                     ST_B_LIST  = 3'd5,  // batch: pick next instance dst
                     ST_B_REARM = 3'd6,  // batch cached: 1-bubble line re-pipe
                     ST_B_IDRAIN= 3'd7;  // batch alpha: per-instance write drain

    // ---- read-ahead FSM states ----------------------------------------------
    localparam [1:0] RA_IDLE = 2'd0,
                     RA_AR   = 2'd1,
                     RA_R    = 2'd2;

    // ---- batch loader FSM states (sprite cache fill / list beat fetch) -----
    localparam [1:0] LD_IDLE = 2'd0,
                     LD_AR   = 2'd1,
                     LD_R    = 2'd2;

    reg [2:0]   state;
    reg [1:0]   ra_state;
    reg [1:0]   ld_state;

    // ---- ping-pong bookkeeping ----------------------------------------------
    reg         cur;            // buffer the write FSM consumes
    reg         fullA, fullB;   // buffer holds a complete, unread line
    reg  [3:0]  hoA, hoB;       // src head offset per buffer
    reg  [3:0]  hodA, hodB;     // dst head offset per buffer (alpha)

    reg [15:0]  line_cnt;       // line being written: 0 .. height-1
    reg [15:0]  rd_line_idx;    // lines kicked to read-ahead so far
    reg [31:0]  rd_src_line;    // next src line address for read-ahead
    reg [31:0]  rd_dst_line;    // next dst line address for read-ahead
    reg [31:0]  wr_dst_line;    // dst address of the line being written

    // ---- read-ahead datapath -------------------------------------------------
    reg         ra_buf;         // buffer being filled
    reg         ra_target;      // 0 = src line, 1 = dst line (alpha)
    reg [31:0]  ra_dst_addr;    // latched dst line base (alpha second pass)
    reg [31:0]  ra_remaining;   // bytes left to read for the current line
    reg [31:0]  ra_cur_addr;    // address of the next read burst
    reg [8:0]   ra_burst_beats; // beats of the read burst in flight (1..256)
    reg [8:0]   ra_wr_beat;     // line-buffer write index
    reg [31:0]  araddr_r;
    reg [7:0]   arlen_r;
    reg         ra_arvalid;

    // ---- kick (write FSM -> read-ahead) --------------------------------------
    reg         kick;           // 1-cycle pulse
    reg         kick_buf;
    reg  [31:0] kick_src, kick_dst;

    // ---- write-side pixel datapath -------------------------------------------
    reg [15:0]  pix_idx;        // 0 .. width-1
    reg [15:0]  aw_cnt;         // AW handshakes seen since op start
    reg [15:0]  b_cnt;          // B  handshakes seen since op start
    reg [1:0]   wb_settle;      // 2-cycle settle after final flush

    // ---- Stage 8 batch bookkeeping -------------------------------------------
    reg         batch_mode;     // latched `batch` for the op in flight
    reg         cacheable;      // sprite fits the on-chip cache
    reg [12:0]  lb_bytes;       // per-line cache pitch (worst-case ho=15)
    reg [12:0]  c_line_base;    // cache byte offset of the line being written
    reg [15:0]  inst_idx;       // instance being issued: 0 .. list_cnt-1
    reg         list_ready;     // list_beat holds entries for inst_idx[1:0]
    reg         list_pend;      // a list-beat request is in flight
    reg [127:0] list_beat;      // 4 x 32-bit dst addresses

    // ---- Stage 8 loader FSM (sprite cache fill / list beat fetch) -----------
    reg         ld_req;         // 1-cycle pulse from the write FSM
    reg         ld_req_mode;    // 0 = sprite load, 1 = single list beat
    reg [31:0]  ld_req_addr;    // list beat address (mode 1)
    reg         ld_mode;        // latched mode
    reg [15:0]  ld_line;        // sprite line being loaded
    reg [31:0]  ld_line_addr;   // unaligned DDR address of that line
    reg [8:0]   ld_word_base;   // cache word index of line start
    reg [8:0]   ld_wr_word;     // beat index within the current line
    reg [31:0]  ld_remaining;   // bytes left to read for the current line/beat
    reg [31:0]  ld_cur_addr;    // address of the next read burst
    reg [8:0]   ld_burst_beats; // beats of the burst in flight
    reg [31:0]  ld_araddr;
    reg [7:0]   ld_arlen;
    reg         ld_arvalid;
    reg         ld_done;        // 1-cycle pulse: load/fetch complete

    // ---- stall watchdog (same philosophy as reader/master) ----------------
    // Progress-reset: any pixel/AXI activity re-arms the counter.  A batch
    // op legitimately runs far longer than STALL_LIMIT total cycles, so a
    // free-running counter would false-abort it; only a genuine stall (no
    // progress for ~2 ms) is an error.
    localparam [23:0] STALL_LIMIT = 24'd200000;   // ~2 ms @ 100 MHz
    reg  [23:0] stall_cnt;
    wire        stall_abort = busy && (stall_cnt >= STALL_LIMIT);

    // ---- line buffers (ping-pong; sync-read BRAM template) ----------------
    reg [127:0] line_bufA [0:MAX_LINE_BEATS-1];
    reg [127:0] line_bufB [0:MAX_LINE_BEATS-1];
    reg [127:0] dst_bufA  [0:MAX_LINE_BEATS-1];  // Stage 7: dst line (alpha)
    reg [127:0] dst_bufB  [0:MAX_LINE_BEATS-1];

    // ---- Stage 8: sprite cache (256 x 16 B = 4 KB) + per-line head offset --
    reg [127:0] sprite_cache [0:255];
    reg [3:0]   ho_tab [0:255];                  // (src + y*src_stride)[3:0]

    //------------------------------------------------------------------------
    // Line-length maths: a line covers head + width*2 bytes, rounded up to 16
    //------------------------------------------------------------------------
    function [31:0] rd_bytes_of(input [31:0] saddr, input [15:0] w);
        reg [31:0] span;
        begin
            span = {28'd0, saddr[3:0]} + {14'd0, w, 1'b0};
            rd_bytes_of = {span[31:4] + {31'd0, |span[3:0]}, 4'b0};
        end
    endfunction

    function line_too_big(input [31:0] saddr, input [15:0] w);
        begin
            line_too_big = (rd_bytes_of(saddr, w) > (MAX_LINE_BEATS*16));
        end
    endfunction

    //------------------------------------------------------------------------
    // Stage 8 cache sizing: per-line pitch uses the WORST head offset (15) so
    // every line's true span fits the reserved pitch; the sprite is cacheable
    // when pitch*height <= 4096 B (256 words).  height <= 256 is implied.
    //------------------------------------------------------------------------
    wire [31:0] lb_calc     = (({15'd0, width, 1'b0} + 32'd15) >> 4) << 4;
    wire [8:0]  lb_words_w  = lb_calc[12:4];
    wire [24:0] cache_need  = {16'd0, lb_words_w} * {9'd0, height};
    wire        cacheable_w = (lb_calc[31:13] == 19'd0) &&
                              (cache_need <= 25'd256);

    //------------------------------------------------------------------------
    // Read-ahead burst length calculation (identical rules to gpu_axi_reader):
    //   burst = min(16, ceil(ra_remaining/16), beats left to 4 KB boundary)
    //------------------------------------------------------------------------
    wire [12:0] bytes_to_4k  = 13'h1000 - {1'b0, ra_cur_addr[11:0]};
    wire [8:0]  beats_to_4k  = {1'b0, bytes_to_4k[12:4]};          // 1..256
    wire [8:0]  beats_remain = (|ra_remaining[31:12]) ? 9'd256 :
                               ({1'b0, ra_remaining[11:4]} + {8'd0, |ra_remaining[3:0]});
    wire [8:0]  burst_calc   = (beats_remain > 9'd16) ? 9'd16 : beats_remain;
    wire [8:0]  burst_next   = (burst_calc > beats_to_4k) ? beats_to_4k : burst_calc;

    // loader burst calculation (same rules, own registers)
    wire [31:0] ld_next_line    = ld_line_addr + src_stride;
    wire [12:0] ld_bytes_to_4k  = 13'h1000 - {1'b0, ld_cur_addr[11:0]};
    wire [8:0]  ld_beats_to_4k  = {1'b0, ld_bytes_to_4k[12:4]};
    wire [8:0]  ld_beats_remain = (|ld_remaining[31:12]) ? 9'd256 :
                                  ({1'b0, ld_remaining[11:4]} + {8'd0, |ld_remaining[3:0]});
    wire [8:0]  ld_burst_calc   = (ld_beats_remain > 9'd16) ? 9'd16 : ld_beats_remain;
    wire [8:0]  ld_burst_next   = (ld_burst_calc > ld_beats_to_4k) ? ld_beats_to_4k : ld_burst_calc;

    //------------------------------------------------------------------------
    // Unpack + Color Key handling.
    //
    // Synchronous line-buffer read (BRAM template: address this cycle, data
    // next cycle).  The pixel stream is pipelined by one cycle: rb_data /
    // rb_off / addr_r / valid_r all describe the SAME pixel.  Both buffers
    // are read at the same address and muxed by `cur` (constant per line).
    //
    // wr-opt 1: leading key pixels of a line (seen_opaque=0) are consumed
    // locally; afterwards key pixels go to the master with pixel_hole=1.
    //
    // Because pix_idx only advances on a consume event, the read address
    // must look ONE PIXEL AHEAD during a consume -- otherwise the line
    // would shift by one pixel (same pitfall as gpu_copy).
    //------------------------------------------------------------------------
    // EFX-0657 fix (A's PR #47 template): EACH bank gets its own synchronous
    // read register; the `cur` mux sits AFTER the registers.  Efinity only
    // infers RAM10 when the read port is a plain `q <= mem[addr];` -- a mux
    // inside the read expression maps the whole array to FFs (rtl11: bitblt
    // alone was 131,801 FF).  `cur` is constant within a line and only flips
    // in ST_WAIT (valid_i=0), so cur_r is in phase with the registered data.
    // Stage 8 adds rb_dataC (sprite cache) with the same independent
    // registered read; the batch mux also sits after the register.
    reg  [127:0] rb_dataA;      // src bank A read data, registered
    reg  [127:0] rb_dataB;      // src bank B read data, registered
    reg  [127:0] db_dataA;      // dst bank A read data, registered
    reg  [127:0] db_dataB;      // dst bank B read data, registered
    reg  [127:0] rb_dataC;      // sprite cache read data, registered (Stage 8)
    reg          cur_r;         // `cur` delayed 1 cycle, in phase with data
    reg          batch_cache_r; // batch&cacheable delayed, in phase with data
    reg  [3:0]   rb_off;        // byte offset of the pixel inside the word
    reg  [31:0]  addr_r;        // dst address, in phase with the data
    reg          valid_i;       // pixel-valid produced by the FSM
    reg          valid_r;       // valid_i delayed 1 cycle -> in phase with data
    reg          seen_opaque;   // per-line: first opaque pixel emitted?

    wire [127:0] rb_data  = cur_r ? rb_dataB : rb_dataA;      // mux after regs
    wire [127:0] src_word = batch_cache_r ? rb_dataC : rb_data;

    wire [15:0] cur_pix   = src_word[{rb_off[3:1], 4'b0} +: 16];
    wire        cur_iskey = (cur_pix == color_key);
    // head margin: local consume; interior hole: presented with hole=1
    wire        head_skip = valid_r && cur_iskey && !seen_opaque;
    // consume = master handshake (presented pixel) OR local head-margin drop
    wire        advance   = head_skip || (valid_r && pixel_ready);

    // Never look past the last pixel: the cycle after the final consume is a
    // pipeline drain bubble (valid_i is being cleared).  Without the clamp the
    // bubble would sample the first word BEYOND the current line, which still
    // holds stale data from the previous operation; in an all-key line that
    // stale word can be non-key and leak to the master as a phantom write.
    wire [15:0] pix_rd  = (advance && (pix_idx != width - 16'd1)) ?
                          (pix_idx + 16'd1) : pix_idx;

    wire [3:0]  cur_ho    = cur ? hoB  : hoA;      // src head offset, this line
    wire [3:0]  cur_hod   = cur ? hodB : hodA;     // dst head offset (alpha)
    wire [13:0] byte_rd     = {10'd0, cur_ho}  + {pix_rd[12:0], 1'b0};
    wire [13:0] byte_rd_dst = {10'd0, cur_hod} + {pix_rd[12:0], 1'b0};

    // Stage 8: cache addressing for the line being streamed
    //   byte = c_line_base + ho_tab[line] + pix*2      (all < 4096 in use)
    wire [3:0]  cur_ho_c  = ho_tab[line_cnt[7:0]];
    wire [13:0] byte_rd_c = {1'b0, c_line_base} + {10'd0, cur_ho_c} +
                            {pix_rd[12:0], 1'b0};

    // Stage 7: destination pixel pipeline (same BRAM template, same phase)
    reg  [3:0]   db_off;
    wire [127:0] db_data = cur_r ? db_dataB : db_dataA;   // mux after regs
    wire [15:0] cur_dst = db_data[{db_off[3:1], 4'b0} +: 16];

    //------------------------------------------------------------------------
    // RGB565 alpha blend, per channel, round-to-nearest:
    //   out = (src*a + dst*(32-a) + 16) >> 5,  a in 0..32
    // a=32 -> exactly src; a=0 -> exactly dst.  Three <= 6x6-bit multiplies
    // (Ti60 maps them to DSP/LUT); accumulators need 13 bits max:
    //   31*32 + 31*32 + 16 = 2000 < 8192.
    //------------------------------------------------------------------------
    function [15:0] blend565(input [15:0] s, input [15:0] d, input [5:0] a);
        reg [5:0]  ia;
        reg [12:0] acc_r, acc_g, acc_b;
        begin
            ia    = 6'd32 - a;
            acc_r = {8'd0, s[15:11]} * a + {8'd0, d[15:11]} * ia + 13'd16;
            acc_g = {7'd0, s[10:5]}  * a + {7'd0, d[10:5]}  * ia + 13'd16;
            acc_b = {8'd0, s[4:0]}   * a + {8'd0, d[4:0]}   * ia + 13'd16;
            blend565 = {acc_r[9:5], acc_g[10:5], acc_b[9:5]};
        end
    endfunction

    // head-margin key pixels never leave; interior holes leave with hole=1
    assign pixel_valid = valid_r && !(cur_iskey && !seen_opaque);
    assign pixel_hole  = cur_iskey;
    assign pixel_addr  = addr_r;
    assign pixel_data  = alpha_en ? blend565(cur_pix, cur_dst, alpha_val)
                                  : cur_pix;        // Stage 5 path unchanged

    // bank read ports: NO reset, NO mux -- the exact template A verified.
    always @(posedge clk) begin
        rb_dataA <= line_bufA[byte_rd[13:4]];
        rb_dataB <= line_bufB[byte_rd[13:4]];
        db_dataA <= dst_bufA[byte_rd_dst[13:4]];
        db_dataB <= dst_bufB[byte_rd_dst[13:4]];
        rb_dataC <= sprite_cache[byte_rd_c[11:4]];   // Stage 8
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            cur_r         <= 1'b0;
            batch_cache_r <= 1'b0;
            rb_off        <= 4'd0;
            db_off        <= 4'd0;
            addr_r        <= 32'd0;
            valid_r       <= 1'b0;
        end else begin
            cur_r         <= cur;
            batch_cache_r <= batch_mode && cacheable;
            rb_off        <= (batch_mode && cacheable) ? byte_rd_c[3:0]
                                                       : byte_rd[3:0];
            db_off        <= byte_rd_dst[3:0];
            addr_r        <= wr_dst_line + {15'd0, pix_rd, 1'b0};
            valid_r       <= valid_i;
        end
    end

    // read channel: loader owns AR while active, read-ahead owns it otherwise
    // (mutually exclusive in time: LD runs during ST_B_LD/ST_B_LIST, RA only
    // during line streaming).  R is accepted by whichever FSM is in _R.
    assign m_axi_araddr  = ld_arvalid ? ld_araddr : araddr_r;
    assign m_axi_arlen   = ld_arvalid ? ld_arlen  : arlen_r;
    assign m_axi_arvalid = ld_arvalid | ra_arvalid;
    assign m_axi_rready  = (ra_state == RA_R) || (ld_state == LD_R);

    // ---- write-channel handshake counters ---------------------------------
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            aw_cnt <= 16'd0;
            b_cnt  <= 16'd0;
        end else if (state == ST_IDLE && start) begin
            aw_cnt <= 16'd0;
            b_cnt  <= 16'd0;
        end else begin
            if (wr_aw_hs) aw_cnt <= aw_cnt + 16'd1;
            if (wr_b_hs)  b_cnt  <= b_cnt  + 16'd1;
        end
    end

    // Kick rule: line rd_line_idx goes into buffer 1-cur as soon as the
    // read-ahead is idle and that buffer is free.  Buffer 1-cur is guaranteed
    // fully streamed by program order (cur only advances after the previous
    // line's last pixel was consumed).  The !kick term closes a 1-cycle
    // window: while a kick pulse is still on its way the read-ahead has not
    // latched it yet and still reads as RA_IDLE -- without the guard the next
    // line's kick would fire into the same window and be lost (found by
    // code review before first sim).
    // Stage 8: rd_line_idx is held at `height` whenever no read-ahead may
    // run (cached non-alpha instances, list/cache-load phases).
    //------------------------------------------------------------------------
    wire want_kick = busy && !kick &&
                     (rd_line_idx < height) &&
                     (rd_line_idx == line_cnt + 16'd1) &&
                     (ra_state == RA_IDLE) &&
                     !(cur ? fullA : fullB);

    // alpha + cached sprite: read-ahead fetches ONLY the dst line (RMW);
    // the src pixel comes from sprite_cache instead of line_bufA/B.
    wire        dst_only_kick = batch_mode && cacheable && alpha_en;
    wire [31:0] kick_base     = dst_only_kick ? kick_dst : kick_src;

    // current instance destination (lane of the buffered list beat)
    wire [31:0] dst_inst = list_beat[{inst_idx[1:0], 5'b0} +: 32];

    // watchdog progress: any datapath or bus activity re-arms the counter
    wire progress = advance ||
                    (m_axi_rvalid && m_axi_rready) ||
                    (m_axi_arvalid && m_axi_arready) ||
                    wr_aw_hs || wr_b_hs || kick || ld_done;

    //------------------------------------------------------------------------
    // Single clocked process: write FSM + read-ahead FSM + loader FSM
    // (single driver per register; the parts never touch the same flag in
    // the same cycle).
    //------------------------------------------------------------------------
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            // write FSM
            state         <= ST_IDLE;
            busy          <= 1'b0;
            done          <= 1'b0;
            error         <= 1'b0;
            cur           <= 1'b0;
            line_cnt      <= 16'd0;
            rd_line_idx   <= 16'd0;
            rd_src_line   <= 32'd0;
            rd_dst_line   <= 32'd0;
            wr_dst_line   <= 32'd0;
            pix_idx       <= 16'd0;
            seen_opaque   <= 1'b0;
            valid_i       <= 1'b0;
            flush         <= 1'b0;
            wb_settle     <= 2'd0;
            stall_cnt     <= 24'd0;
            // kick
            kick          <= 1'b0;
            kick_buf      <= 1'b0;
            kick_src      <= 32'd0;
            kick_dst      <= 32'd0;
            // read-ahead
            ra_state       <= RA_IDLE;
            ra_buf         <= 1'b0;
            ra_target      <= 1'b0;
            ra_dst_addr    <= 32'd0;
            ra_remaining   <= 32'd0;
            ra_cur_addr    <= 32'd0;
            ra_burst_beats <= 9'd0;
            ra_wr_beat     <= 9'd0;
            araddr_r       <= 32'd0;
            arlen_r        <= 8'd0;
            ra_arvalid     <= 1'b0;
            fullA          <= 1'b0;
            fullB          <= 1'b0;
            hoA            <= 4'd0;
            hoB            <= 4'd0;
            hodA           <= 4'd0;
            hodB           <= 4'd0;
            // batch
            batch_mode     <= 1'b0;
            cacheable      <= 1'b0;
            lb_bytes       <= 13'd0;
            c_line_base    <= 13'd0;
            inst_idx       <= 16'd0;
            list_ready     <= 1'b0;
            list_pend      <= 1'b0;
            list_beat      <= 128'd0;
            // loader
            ld_state       <= LD_IDLE;
            ld_req         <= 1'b0;
            ld_req_mode    <= 1'b0;
            ld_req_addr    <= 32'd0;
            ld_mode        <= 1'b0;
            ld_line        <= 16'd0;
            ld_line_addr   <= 32'd0;
            ld_word_base   <= 9'd0;
            ld_wr_word     <= 9'd0;
            ld_remaining   <= 32'd0;
            ld_cur_addr    <= 32'd0;
            ld_burst_beats <= 9'd0;
            ld_araddr      <= 32'd0;
            ld_arlen       <= 8'd0;
            ld_arvalid     <= 1'b0;
            ld_done        <= 1'b0;
        end else if (stall_abort) begin
            // watchdog: drop everything, flag it, report done so the CPU
            // never hangs (CPU reads STATUS.error for the cause)
            state         <= ST_IDLE;
            busy          <= 1'b0;
            done          <= 1'b1;
            error         <= 1'b1;
            valid_i       <= 1'b0;
            flush         <= 1'b0;
            kick          <= 1'b0;
            ra_state      <= RA_IDLE;
            ra_arvalid    <= 1'b0;
            fullA         <= 1'b0;
            fullB         <= 1'b0;
            stall_cnt     <= 24'd0;
            list_pend     <= 1'b0;
            ld_state      <= LD_IDLE;
            ld_req        <= 1'b0;
            ld_arvalid    <= 1'b0;
            ld_done       <= 1'b0;
        end else begin
            flush   <= 1'b0;            // default: one-cycle pulse
            kick    <= 1'b0;            // default: one-cycle pulse
            ld_req  <= 1'b0;            // default: one-cycle pulse
            ld_done <= 1'b0;            // default: one-cycle pulse

            if (ld_done && ld_mode) begin
                list_ready <= 1'b1;     // requested list beat has arrived
                list_pend  <= 1'b0;     // request round-trip complete
            end

            // ======================= write FSM =============================
            if (want_kick) begin
                kick        <= 1'b1;
                kick_buf    <= ~cur;
                kick_src    <= rd_src_line;
                kick_dst    <= rd_dst_line;
                rd_src_line <= rd_src_line + src_stride;
                rd_dst_line <= rd_dst_line + dst_stride;
                rd_line_idx <= rd_line_idx + 16'd1;
            end

            case (state)

                // ---- wait for start ---------------------------------------
                ST_IDLE: begin
                    valid_i <= 1'b0;
                    busy    <= 1'b0;
                    if (start) begin
                        error <= 1'b0;
                        if (width == 16'd0 || height == 16'd0) begin
                            done <= 1'b1;               // empty op: done at once
                        end else if (batch && (list_cnt == 32'd0)) begin
                            done <= 1'b1;               // empty list: zero traffic
                        end else if (batch && (|list_addr[3:0])) begin
                            // list beats are 16 B: base must be 16B aligned
                            done  <= 1'b1;
                            error <= 1'b1;
                        end else if (batch && (list_cnt > 32'd1024)) begin
                            // out-of-spec count: refuse before any bus
                            // request; full-u32 compare, never truncated
                            // (A's Stage-8 review requirement)
                            done  <= 1'b1;
                            error <= 1'b1;
                        end else if (line_too_big(src_addr, width) &&
                                     !(batch && cacheable_w)) begin
                            // line wider than the ping-pong buffer: refuse.
                            // (cached sprites never touch line_bufA/B, so the
                            //  limit does not apply to them)
                            done  <= 1'b1;
                            error <= 1'b1;
                        end else if (!batch && alpha_en &&
                                     line_too_big(dst_addr, width)) begin
                            done  <= 1'b1;
                            error <= 1'b1;
                        end else begin
                            done        <= 1'b0;
                            busy        <= 1'b1;
                            fullA       <= 1'b0;        // drop stale flags from
                            fullB       <= 1'b0;        // any aborted op
                            cur         <= 1'b0;
                            line_cnt    <= 16'd0;
                            batch_mode  <= batch;
                            cacheable   <= batch && cacheable_w;
                            lb_bytes    <= lb_calc[12:0];
                            c_line_base <= 13'd0;
                            inst_idx    <= 16'd0;
                            list_ready  <= 1'b0;
                            list_pend   <= 1'b0;
                            if (batch) begin
                                rd_line_idx <= height;  // no read-ahead yet
                                if (cacheable_w) begin
                                    // load the whole sprite into the cache
                                    ld_req      <= 1'b1;
                                    ld_req_mode <= 1'b0;
                                    ld_req_addr <= 32'd0;
                                    state       <= ST_B_LD;
                                end else begin
                                    state       <= ST_B_LIST;
                                end
                            end else begin
                                wr_dst_line <= dst_addr;
                                // kick line 0 into buffer A
                                kick        <= 1'b1;
                                kick_buf    <= 1'b0;
                                kick_src    <= src_addr;
                                kick_dst    <= dst_addr;
                                rd_src_line <= src_addr + src_stride;
                                rd_dst_line <= dst_addr + dst_stride;
                                rd_line_idx <= 16'd1;
                                state       <= ST_WAIT;
                            end
                        end
                    end
                end

                // ---- batch: wait for the sprite cache load -----------------
                ST_B_LD: begin
                    if (ld_done)
                        state <= ST_B_LIST;
                end

                // ---- batch: fetch/pick the next instance destination ------
                ST_B_LIST: begin
                    if (error) begin
                        // error flagged mid-batch (bad RRESP etc.): do NOT
                        // issue further instances; drain what was accepted
                        // and report (A's Stage-8 review requirement)
                        wb_settle <= 2'd2;
                        state     <= ST_DRAIN;
                    end else if (inst_idx == list_cnt[15:0]) begin
                        // all instances streamed: drain the write master
                        wb_settle <= 2'd2;
                        state     <= ST_DRAIN;
                    end else if ((inst_idx[1:0] != 2'd0) || list_ready) begin
                        // dst_inst is valid: set the instance up
                        wr_dst_line <= dst_inst;
                        line_cnt    <= 16'd0;
                        pix_idx     <= 16'd0;
                        seen_opaque <= 1'b0;
                        cur         <= 1'b0;
                        fullA       <= 1'b0;
                        fullB       <= 1'b0;
                        c_line_base <= 13'd0;
                        valid_i     <= 1'b0;
                        if (alpha_en && !cacheable &&
                            line_too_big(dst_inst, width)) begin
                            // degrade path: this dst line cannot fit the
                            // buffer -> flag and drain what was written
                            error     <= 1'b1;
                            wb_settle <= 2'd2;
                            state     <= ST_DRAIN;
                        end else if (cacheable && !alpha_en) begin
                            rd_line_idx <= height;      // no read-ahead at all
                            state       <= ST_B_REARM;
                        end else begin
                            // alpha-cached (dst-only kicks) or degrade
                            // (normal src[+dst] kicks): line 0 into buffer A
                            kick        <= 1'b1;
                            kick_buf    <= 1'b0;
                            kick_src    <= src_addr;
                            kick_dst    <= dst_inst;
                            rd_src_line <= src_addr + src_stride;
                            rd_dst_line <= dst_inst + dst_stride;
                            rd_line_idx <= 16'd1;
                            state       <= ST_WAIT;
                        end
                    end else if (!list_pend && (ld_state == LD_IDLE)) begin
                        // need the next 16B list beat (4 dst addresses)
                        ld_req      <= 1'b1;
                        ld_req_mode <= 1'b1;
                        ld_req_addr <= list_addr + {14'd0, inst_idx[15:2], 4'b0};
                        list_pend   <= 1'b1;
                    end
                end

                // ---- batch cached: one bubble to re-pipe the BRAM read ----
                ST_B_REARM: begin
                    valid_i <= 1'b1;
                    state   <= ST_WR;
                end

                // ---- batch alpha: drain writes before the next instance ---
                // identical quiescence rule to ST_DRAIN, but continues the
                // batch instead of finishing the op
                ST_B_IDRAIN: begin
                    if (wb_settle != 2'd0)
                        wb_settle <= wb_settle - 2'd1;
                    else if (wr_idle && (aw_cnt == b_cnt))
                        state <= ST_B_LIST;
                end

                // ---- wait for the current buffer to be filled -------------
                ST_WAIT: begin
                    if (cur ? fullB : fullA) begin
                        if (cur) fullB <= 1'b0;
                        else     fullA <= 1'b0;
                        pix_idx     <= 16'd0;
                        seen_opaque <= 1'b0;    // new line: head margins free
                        valid_i     <= 1'b1;
                        state       <= ST_WR;
                    end
                end

                // ---- stream pixels to the shared write master -------------
                // head-margin key pixels are consumed locally; interior key
                // pixels are presented with pixel_hole=1 (group stays open)
                ST_WR: begin
                    if (valid_r && !cur_iskey && pixel_ready)
                        seen_opaque <= 1'b1;    // first opaque pixel emitted
                    if (advance) begin
                        if (pix_idx == width - 16'd1) begin
                            valid_i <= 1'b0;
                            flush   <= 1'b1;    // close the trailing write group
                            if (line_cnt == height - 16'd1) begin
                                if (batch_mode) begin
                                    // instance complete -> next list entry
                                    inst_idx <= inst_idx + 16'd1;
                                    if (inst_idx[1:0] == 2'd3)
                                        list_ready <= 1'b0;   // beat consumed
                                    if (alpha_en) begin
                                        // RMW ordering rule (A's review #5):
                                        // the NEXT instance's dst reads must
                                        // observe THIS instance's writes ->
                                        // drain the write channel per
                                        // instance (alpha is an effect path,
                                        // the extra drain is affordable)
                                        wb_settle <= 2'd2;
                                        state     <= ST_B_IDRAIN;
                                    end else begin
                                        state <= ST_B_LIST;
                                    end
                                end else begin
                                    wb_settle <= 2'd2;
                                    state     <= ST_DRAIN;
                                end
                            end else if (batch_mode && cacheable && !alpha_en) begin
                                // cached line switch: no buffer wait, just
                                // re-pipe the cache read through one bubble
                                line_cnt    <= line_cnt + 16'd1;
                                pix_idx     <= 16'd0;
                                seen_opaque <= 1'b0;
                                c_line_base <= c_line_base + lb_bytes;
                                wr_dst_line <= wr_dst_line + dst_stride;
                                state       <= ST_B_REARM;
                            end else begin
                                line_cnt    <= line_cnt + 16'd1;
                                cur         <= ~cur;
                                wr_dst_line <= wr_dst_line + dst_stride;
                                if (batch_mode && cacheable)
                                    c_line_base <= c_line_base + lb_bytes;
                                state       <= ST_WAIT;
                            end
                        end else begin
                            pix_idx <= pix_idx + 16'd1;
                        end
                    end
                end

                // ---- end of op: wait for the write master to drain --------
                ST_DRAIN: begin
                    if (wb_settle != 2'd0) begin
                        // Two bubble cycles: after our flush pulse the master
                        // commits the buffered groups and only registers
                        // awvalid afterwards.  Sampling quiescence earlier
                        // would false-pass while data is still unwritten
                        // (same lesson as gpu_copy tb T2/T3/T4).
                        wb_settle <= wb_settle - 2'd1;
                    end else if (wr_idle && (aw_cnt == b_cnt)) begin
                        done  <= 1'b1;
                        busy  <= 1'b0;
                        state <= ST_IDLE;
                    end
                end

                default: state <= ST_IDLE;
            endcase

            // ==================== read-ahead FSM ===========================
            case (ra_state)
                RA_IDLE: begin
                    ra_arvalid <= 1'b0;
                    if (kick) begin
                        ra_buf        <= kick_buf;
                        ra_target     <= dst_only_kick;
                        ra_dst_addr   <= kick_dst;
                        ra_remaining  <= rd_bytes_of(kick_base, width);
                        ra_cur_addr   <= {kick_base[31:4], 4'b0000};
                        ra_wr_beat    <= 9'd0;
                        if (kick_buf) begin
                            hodB <= kick_dst[3:0];
                            if (!dst_only_kick) hoB <= kick_src[3:0];
                        end else begin
                            hodA <= kick_dst[3:0];
                            if (!dst_only_kick) hoA <= kick_src[3:0];
                        end
                        ra_state <= RA_AR;
                    end
                end

                // ---- issue one read burst (assert-and-hold) ---------------
                RA_AR: begin
                    if (!ra_arvalid) begin
                        araddr_r       <= ra_cur_addr;
                        arlen_r        <= burst_next[7:0] - 8'd1;
                        ra_burst_beats <= burst_next;
                        ra_arvalid     <= 1'b1;
                    end else if (m_axi_arready) begin
                        ra_arvalid <= 1'b0;
                        ra_state   <= RA_R;
                    end
                end

                // ---- receive beats into the kicked buffer -----------------
                RA_R: begin
                    if (m_axi_rvalid && m_axi_rready) begin
                        if (ra_target) begin
                            if (ra_buf) dst_bufB[ra_wr_beat]  <= m_axi_rdata;
                            else        dst_bufA[ra_wr_beat]  <= m_axi_rdata;
                        end else begin
                            if (ra_buf) line_bufB[ra_wr_beat] <= m_axi_rdata;
                            else        line_bufA[ra_wr_beat] <= m_axi_rdata;
                        end
                        ra_wr_beat <= ra_wr_beat + 9'd1;
                        if (m_axi_rresp != 2'b00)
                            error <= 1'b1;          // flag, keep draining
                        if (m_axi_rlast) begin
                            if (ra_remaining == {19'd0, ra_burst_beats, 4'b0}) begin
                                if (alpha_en && !ra_target) begin
                                    // src line buffered -> fetch the dst line
                                    ra_target    <= 1'b1;
                                    ra_cur_addr  <= {ra_dst_addr[31:4], 4'b0000};
                                    ra_remaining <= rd_bytes_of(ra_dst_addr, width);
                                    ra_wr_beat   <= 9'd0;
                                    ra_state     <= RA_AR;
                                end else begin
                                    // whole line(s) buffered -> mark ready
                                    if (ra_buf) fullB <= 1'b1;
                                    else        fullA <= 1'b1;
                                    ra_state <= RA_IDLE;
                                end
                            end else begin
                                ra_cur_addr  <= ra_cur_addr + {19'd0, ra_burst_beats, 4'b0};
                                ra_remaining <= ra_remaining - {19'd0, ra_burst_beats, 4'b0};
                                ra_state     <= RA_AR;
                            end
                        end
                    end
                end

                default: ra_state <= RA_IDLE;
            endcase

            // ====================== loader FSM (Stage 8) ===================
            // Sprite load (mode 0): line-by-line, identical burst rules to
            // the read-ahead; raw aligned words land at
            //   sprite_cache[ld_word_base + ld_wr_word]
            // and ho_tab[line] records the line's head offset.
            // List fetch (mode 1): exactly one 16B beat into list_beat.
            case (ld_state)
                LD_IDLE: begin
                    ld_arvalid <= 1'b0;
                    if (ld_req) begin
                        ld_mode    <= ld_req_mode;
                        ld_wr_word <= 9'd0;
                        if (ld_req_mode) begin
                            ld_remaining <= 32'd16;
                            ld_cur_addr  <= ld_req_addr;
                        end else begin
                            ld_line        <= 16'd0;
                            ld_line_addr   <= src_addr;
                            ld_word_base   <= 9'd0;
                            ld_remaining   <= rd_bytes_of(src_addr, width);
                            ld_cur_addr    <= {src_addr[31:4], 4'b0000};
                            ho_tab[8'd0]   <= src_addr[3:0];
                        end
                        ld_state <= LD_AR;
                    end
                end

                LD_AR: begin
                    if (!ld_arvalid) begin
                        ld_araddr      <= ld_cur_addr;
                        ld_arlen       <= ld_burst_next[7:0] - 8'd1;
                        ld_burst_beats <= ld_burst_next;
                        ld_arvalid     <= 1'b1;
                    end else if (m_axi_arready) begin
                        ld_arvalid <= 1'b0;
                        ld_state   <= LD_R;
                    end
                end

                LD_R: begin
                    if (m_axi_rvalid && m_axi_rready) begin
                        if (ld_mode)
                            list_beat <= m_axi_rdata;
                        else
                            sprite_cache[ld_word_base + ld_wr_word] <= m_axi_rdata;
                        ld_wr_word <= ld_wr_word + 9'd1;
                        if (m_axi_rresp != 2'b00)
                            error <= 1'b1;          // flag, keep draining
                        if (m_axi_rlast) begin
                            if (ld_mode) begin
                                ld_done  <= 1'b1;
                                ld_state <= LD_IDLE;
                            end else if (ld_remaining == {19'd0, ld_burst_beats, 4'b0}) begin
                                if (ld_line == height - 16'd1) begin
                                    // whole sprite cached
                                    ld_done  <= 1'b1;
                                    ld_state <= LD_IDLE;
                                end else begin
                                    // next sprite line
                                    ld_line      <= ld_line + 16'd1;
                                    ld_line_addr <= ld_line_addr + src_stride;
                                    ld_word_base <= ld_word_base +
                                                    {4'd0, lb_bytes[12:4]};
                                    ld_remaining <= rd_bytes_of(ld_next_line,
                                                                width);
                                    ld_cur_addr  <= {ld_next_line[31:4],
                                                     4'b0000};
                                    ld_wr_word   <= 9'd0;
                                    ho_tab[ld_line[7:0] + 8'd1] <=
                                        ld_next_line[3:0];
                                    ld_state     <= LD_AR;
                                end
                            end else begin
                                ld_cur_addr  <= ld_cur_addr + {19'd0, ld_burst_beats, 4'b0};
                                ld_remaining <= ld_remaining - {19'd0, ld_burst_beats, 4'b0};
                                ld_state     <= LD_AR;
                            end
                        end
                    end
                end

                default: ld_state <= LD_IDLE;
            endcase

            if (!busy || progress) stall_cnt <= 24'd0;
            else if (stall_cnt != 24'hFFFFFF) stall_cnt <= stall_cnt + 1'b1;
        end
    end

endmodule
