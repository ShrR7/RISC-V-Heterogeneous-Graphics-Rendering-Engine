// A-owned first-fault history: 64 records x 8 words, one 32-bit RAM port.
// Record bundles are latched at the line event; serial storage never stalls AXI.
// A record in flight at the trigger is committed before frozen goes high.
module bullet_diag_history(
    input wire clk,input wire rstn,input wire rearm,input wire trigger,
    input wire sample_tick,input wire [255:0] sample_context,
    input wire [1023:0] current_B_context,
    input wire [511:0] outer_context,input wire [15:0] paddr,
    output reg [31:0] prdata
);
    reg [31:0] mem[0:511];reg [31:0] q;
    reg [255:0] record;
    reg [511:0] frozen_outer;reg [1023:0] frozen_B;
    reg [5:0] next_slot;reg [6:0] count;
    reg [2:0] word_index;reg writing,stopped;
    reg [31:0] dropped;
    wire frozen=stopped && !writing;
    always @(posedge clk)begin
        if(writing && !rearm)mem[{next_slot,word_index}]<=record[word_index*32+:32];
        q<=mem[paddr[10:2]];
    end
    always @(posedge clk or negedge rstn)begin
        if(!rstn)begin
            record<=0;frozen_outer<=0;frozen_B<=0;next_slot<=0;count<=0;word_index<=0;
            writing<=0;stopped<=0;dropped<=0;
        end else if(rearm)begin
            next_slot<=0;count<=0;word_index<=0;writing<=0;stopped<=0;dropped<=0;frozen_outer<=0;frozen_B<=0;
        end else begin
            if(trigger && !stopped)begin stopped<=1;frozen_outer<=outer_context;frozen_B<=current_B_context;end
            if(writing)begin
                if(word_index==7)begin
                    writing<=0;next_slot<=next_slot+1'b1;
                    if(count<64)count<=count+1'b1;
                end else word_index<=word_index+1'b1;
            end
            if(sample_tick && !stopped && !trigger)begin
                if(!writing)begin record<=sample_context;writing<=1;word_index<=0;end
                else if(!(&dropped))dropped<=dropped+1'b1;
            end
        end
    end
    always @*begin
        prdata=0;
        case(paddr)
            16'h0280:prdata=32'h48535432; // HST2
            16'h0284:prdata={17'd0,next_slot,count,writing,frozen};
            16'h0288:prdata=32'h00400008; // 64 records, 8 words
            16'h028c:prdata=dropped;
            default:begin
                if(paddr>=16'h0300 && paddr<16'h0340 && frozen)
                    prdata=frozen_outer[paddr[5:2]*32+:32];
                if(paddr>=16'h0340 && paddr<16'h03c0 && frozen)
                    prdata=frozen_B[((paddr-16'h0340)>>2)*32+:32];
                if(paddr[15:11]==5'b00010 && frozen &&
                    (count==64 || {1'b0,paddr[10:5]}<count))prdata=q;
            end
        endcase
    end
endmodule
