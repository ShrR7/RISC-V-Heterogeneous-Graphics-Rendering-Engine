//============================================================================
// File        : gpu_axi_master.v
// Description : AXI4 write-only master, 128-bit data, 8 RGB565 pixels per beat
// Team        : Team B (RTL Accelerator)  [128-bit version by A]
//
// Stage 7 write-opt 2 (short write bursts, 2026-10-13):
//   Groups are now collected into a BUF-deep buffer and written as ONE
//   multi-beat INCR burst (awlen = n-1) instead of one single-beat
//   transaction per group.  A burst closes (is issued) when:
//     - the buffer is full (BUF groups),
//     - the incoming pixel does not continue the current group (gap),
//     - the producer asserts flush (line end / fill done),
//     - the next group would cross a 4 KB boundary (AXI rule).
//   Continuity is guaranteed structurally: a commit WITHOUT issue happens
//   only for a full (cnt==8) group that started at byte offset 0, so the
//   next group always starts at base+16.  The per-group B-response wait is
//   now amortised over the whole burst (measured: one transaction costs
//   6 + b_lat cycles; a 16x16 sprite line halves its transaction count,
//   full-screen fills chain up to BUF groups per burst).
//
// Stage 7 write-opt 1 (in-group hole merging):
//   pixel_hole marks a colour-key hole: the byte lane is occupied (the group
//   does not split) but its wstrb bits stay 0.  A burst consisting of a
//   SINGLE all-hole group is suppressed entirely (no AXI traffic); an
//   all-hole group inside a longer burst is written as a wstrb=0 beat
//   (harmless, keeps the burst contiguous).
//
// Earlier behaviour notes (still valid):
//   - AW/W VALID is held until READY is observed high (required by AXI4)
//   - a ~2 ms stall watchdog aborts a transaction that never gets a response,
//     so a dead DDR path cannot freeze the CPU (the CPU runs code from DDR)
//
// Pixel-stream handshake (IMPORTANT - this was a real bug):
//   pixel_ready MUST be combinational.  With a registered pixel_ready the
//   producer sees ready=1 during the very cycle in which this master decides
//   to close the group, completes the handshake, and the pixel is then thrown
//   away.  pixel_ready is therefore driven by can_accept below, so it is low
//   in every cycle in which the presented pixel would not be packed.
//
// Stage 5 fix (found by tb_gpu_stage5 T2, color-key gaps):
//   a group must close when the incoming pixel crosses the 16-byte boundary
//   of the CURRENT group (px_same_grp below).  BitBlt runs can start
//   mid-group; without the boundary rule the 8th pixel would wrap to lane 0
//   of the SAME group and overwrite earlier bytes.
//
// Byte enable mapping (also a real bug once):
//   a pixel at byte offset `off` inside the 16-byte group occupies bytes
//   off and off+1  ->  wstrb_buf[off +: 2]
//   its data goes into the 16-bit lane off/2 -> wbuf[off/2 * 16 +: 16]
//   i.e. wstrb uses addr[3:0] (byte granularity) while wbuf uses addr[3:1]
//   (pixel granularity).  Do not use the same index for both.
//
// Drain observation contract with the engines (unchanged):
//   after the producer's flush pulse the master commits and issues whatever
//   is buffered; wr_aw_hs / wr_b_hs counts stay 1:1 (one B per burst) and
//   wr_idle (= !awvalid && !wvalid, computed in gpu_top) only rises once the
//   burst is on the wire, so the engines' "settle 2 + wr_idle + aw==b" drain
//   check keeps working verbatim.
//============================================================================

`include "gpu_pkg.vh"

module gpu_axi_master #(
    parameter BUF = 8                   // group buffer depth (max burst len)
)(
    input  wire         aclk,
    input  wire         aresetn,

    // ---- pixel stream from the engines (muxed in gpu_top) -----------------
    input  wire [31:0]  pixel_addr,
    input  wire [15:0]  pixel_data,
    input  wire         pixel_valid,
    input  wire         pixel_hole,     // wr-opt 1: key hole inside a group
    output wire         pixel_ready,

    // ---- AXI4 write address channel ---------------------------------------
    output reg  [31:0]  m_axi_awaddr,
    output reg  [7:0]   m_axi_awlen,
    output reg  [2:0]   m_axi_awsize,
    output reg  [1:0]   m_axi_awburst,
    output reg          m_axi_awvalid,
    input  wire         m_axi_awready,

    // ---- AXI4 write data channel ------------------------------------------
    output reg  [127:0] m_axi_wdata,
    output reg  [15:0]  m_axi_wstrb,
    output reg          m_axi_wlast,
    output reg          m_axi_wvalid,
    input  wire         m_axi_wready,

    // ---- AXI4 write response channel --------------------------------------
    input  wire [1:0]   m_axi_bresp,
    input  wire         m_axi_bvalid,
    output wire         m_axi_bready,

    // ---- flush (line end / fill done): write out everything pending -------
    input  wire         flush
);

    localparam [2:0] ST_IDLE = 3'd0,
                     ST_PACK = 3'd1,
                     ST_AW   = 3'd2,
                     ST_W    = 3'd3,
                     ST_B    = 3'd4;

    reg [2:0]   state;

    // ---- current (open) group ---------------------------------------------
    reg [3:0]   cnt;          // pixels in the current group (0..8)
    reg [31:0]  grp_base;     // 16-byte aligned group base address
    reg [31:0]  last_addr;    // address of the last accepted pixel
    reg [127:0] wbuf;         // 16-byte group data
    reg [15:0]  wstrb_buf;    // matching byte enables

    // ---- committed-group buffer (burst assembly) ---------------------------
    reg [127:0] buf_data [0:BUF-1];
    reg [15:0]  buf_strb [0:BUF-1];
    reg [3:0]   buf_n;        // committed groups waiting (0..BUF)
    reg [31:0]  burst_base;   // base address of slot 0
    reg [7:0]   awlen_r;      // burst length - 1, latched at issue
    reg [3:0]   w_idx;        // W beat index while streaming

    // ---- stall watchdog ----------------------------------------------------
    localparam [23:0] STALL_LIMIT = 24'd200000;   // ~2 ms @ 100 MHz
    reg  [23:0] stall_cnt;
    wire        stall_abort = (state != ST_IDLE) && (stall_cnt >= STALL_LIMIT);

    // ---- pixel stream handshake (combinational, see header) ----------------
    wire px_continues = (pixel_addr == (last_addr + 32'd2));
    // same 16-byte group: consecutive AND the boundary has not been crossed
    wire px_same_grp  = px_continues && (pixel_addr[3:0] != 4'h0);
    // cnt==0: fresh group right after a commit - any pixel may start it
    // (px_same_grp would be false on the 16B boundary and deadlock us)
    wire can_accept   = (state == ST_IDLE) ||
                        ((state == ST_PACK) && !flush &&
                         ((cnt == 4'd0) || ((cnt != 4'd8) && px_same_grp)));
    assign pixel_ready  = can_accept;

    // ---- B channel: bready high for exactly as long as we are in ST_B -----
    assign m_axi_bready = (state == ST_B);

    // ---- close / issue decision (evaluated in ST_PACK with cnt>0) ---------
    // A 16B-boundary crossing closes the group but does NOT force an issue:
    // the pending pixel starts the next group at base+16, so the burst stays
    // contiguous and keeps chaining.  Only a true address gap (stride jump),
    // flush, a full buffer or an impending 4 KB cross closes the burst.
    wire close_bnd   = pixel_valid && px_continues && (pixel_addr[3:0] == 4'h0);
    wire close_gap   = pixel_valid && !px_continues;  // true gap (stride jump)
    wire issue_full  = (buf_n == BUF-1);              // buffer would be full
    wire issue_4k    = (grp_base[11:0] == 12'hFF0);   // next group crosses 4KB

    integer bi;
    always @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            state         <= ST_IDLE;
            cnt           <= 4'd0;
            buf_n         <= 4'd0;
            burst_base    <= 32'd0;
            awlen_r       <= 8'd0;
            w_idx         <= 4'd0;
            m_axi_awvalid <= 1'b0;
            m_axi_wvalid  <= 1'b0;
            m_axi_awaddr  <= 32'd0;
            m_axi_awlen   <= 8'd0;
            m_axi_awsize  <= 3'b100;
            m_axi_awburst <= 2'b01;
            m_axi_wdata   <= 128'd0;
            m_axi_wstrb   <= 16'd0;
            m_axi_wlast   <= 1'b1;
            wbuf          <= 128'd0;
            wstrb_buf     <= 16'd0;
            grp_base      <= 32'd0;
            last_addr     <= 32'd0;
            stall_cnt     <= 24'd0;
        end else if (stall_abort) begin
            // watchdog: drop the stuck transaction and return to IDLE
            state         <= ST_IDLE;
            cnt           <= 4'd0;
            buf_n         <= 4'd0;
            m_axi_awvalid <= 1'b0;
            m_axi_wvalid  <= 1'b0;
            stall_cnt     <= 24'd0;
        end else begin
            case (state)

                // ---- first pixel of the very first group ------------------
                // (entered only with an empty buffer; committed groups keep
                //  us in ST_PACK)
                ST_IDLE: begin
                    m_axi_awvalid <= 1'b0;
                    m_axi_wvalid  <= 1'b0;
                    cnt           <= 4'd0;
                    if (pixel_valid && pixel_ready) begin
                        grp_base  <= pixel_addr & 32'hFFFFFFF0;
                        wbuf      <= 128'd0;
                        wstrb_buf <= 16'd0;
                        if (!pixel_hole) begin
                            wbuf      [pixel_addr[3:1]*16 +: 16] <= pixel_data;
                            wstrb_buf [pixel_addr[3:0]     +: 2 ] <= 2'b11;
                        end
                        last_addr <= pixel_addr;
                        cnt       <= 4'd1;
                        state     <= ST_PACK;
                    end
                end

                // ---- pack pixels; commit closed groups; issue bursts ------
                ST_PACK: begin
                    if (cnt == 4'd0) begin
                        // fresh group; committed groups may wait in the buffer
                        if (flush) begin
                            if (buf_n != 4'd0) begin
                                if (buf_n == 4'd1 && buf_strb[0] == 16'd0) begin
                                    buf_n <= 4'd0;      // suppress all-hole
                                    state <= ST_IDLE;
                                end else begin
                                    awlen_r <= {4'd0, buf_n} - 8'd1;
                                    buf_n   <= 4'd0;
                                    state   <= ST_AW;
                                end
                            end
                        end else if (pixel_valid && pixel_ready) begin
                            grp_base  <= pixel_addr & 32'hFFFFFFF0;
                            wbuf      <= 128'd0;
                            wstrb_buf <= 16'd0;
                            if (!pixel_hole) begin
                                wbuf      [pixel_addr[3:1]*16 +: 16] <= pixel_data;
                                wstrb_buf [pixel_addr[3:0]     +: 2 ] <= 2'b11;
                            end
                            last_addr <= pixel_addr;
                            cnt       <= 4'd1;
                        end
                    end else if ((cnt == 4'd8) || flush || close_bnd || close_gap) begin
                        // close the current group (full / line end / boundary
                        // cross / true gap): commit it into the buffer, then
                        // decide whether the burst goes out now.
                        // NOTE: no pixel handshake can happen this cycle
                        // (pixel_ready is low), so wbuf/wstrb_buf are final.
                        buf_data[buf_n] <= wbuf;
                        buf_strb[buf_n] <= wstrb_buf;
                        if (buf_n == 4'd0)
                            burst_base <= grp_base;
                        cnt <= 4'd0;
                        if (flush || close_gap || issue_full || issue_4k) begin
                            if (buf_n == 4'd0 && wstrb_buf == 16'd0) begin
                                state <= ST_IDLE;       // suppress all-hole
                            end else begin
                                awlen_r <= {4'd0, buf_n};   // (buf_n+1) - 1
                                state   <= ST_AW;
                            end
                            buf_n <= 4'd0;
                        end else begin
                            buf_n <= buf_n + 4'd1;      // keep collecting
                        end
                    end else if (pixel_valid && pixel_ready) begin
                        if (!pixel_hole) begin
                            wbuf      [pixel_addr[3:1]*16 +: 16] <= pixel_data;
                            wstrb_buf [pixel_addr[3:0]     +: 2 ] <= 2'b11;
                        end
                        last_addr <= pixel_addr;
                        cnt       <= cnt + 4'd1;
                    end
                end

                // ---- write address: one burst for the whole buffer --------
                ST_AW: begin
                    m_axi_awaddr  <= burst_base;
                    m_axi_awlen   <= awlen_r;
                    m_axi_awsize  <= 3'b100;      // 16 bytes
                    m_axi_awburst <= 2'b01;       // INCR
                    if (!m_axi_awvalid) begin
                        m_axi_awvalid <= 1'b1;    // assert and hold until READY
                    end else if (m_axi_awready) begin
                        m_axi_awvalid <= 1'b0;
                        w_idx         <= 4'd0;
                        state         <= ST_W;
                    end
                end

                // ---- write data: stream the buffered groups ---------------
                ST_W: begin
                    if (!m_axi_wvalid) begin
                        m_axi_wdata  <= buf_data[0];
                        m_axi_wstrb  <= buf_strb[0];
                        m_axi_wlast  <= (awlen_r == 8'd0);
                        m_axi_wvalid <= 1'b1;
                    end else if (m_axi_wready) begin
                        if (w_idx == awlen_r[3:0]) begin
                            m_axi_wvalid <= 1'b0;
                            state        <= ST_B;
                        end else begin
                            w_idx        <= w_idx + 4'd1;
                            m_axi_wdata  <= buf_data[w_idx + 4'd1];
                            m_axi_wstrb  <= buf_strb[w_idx + 4'd1];
                            m_axi_wlast  <= ((w_idx + 4'd1) == awlen_r[3:0]);
                        end
                    end
                end

                // ---- write response ---------------------------------------
                ST_B: begin
                    if (m_axi_bvalid) begin
                        cnt   <= 4'd0;
                        state <= ST_IDLE;
                    end
                end

                default: state <= ST_IDLE;
            endcase

            if (state == ST_IDLE) stall_cnt <= 24'd0;
            else if (stall_cnt != 24'hFFFFFF) stall_cnt <= stall_cnt + 1'b1;
        end
    end

    // buf_data/buf_strb are write-only towards the buffer and read-only
    // towards AXI; no initialisation needed (suppression checks strb==0 only
    // for committed slots).

endmodule
