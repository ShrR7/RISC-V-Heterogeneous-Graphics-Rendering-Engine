// Team A: production attachment shared by the board top and concurrent tests.
// The old APB slave is deselected on the complete BUL9 page, including setup.
// Legacy reader/FIFO/serializer continue running for immediate frame-safe fallback.
module bullet_display_subsystem (
    input wire clk,
    input wire rstn,
    input wire [7:0] m0_arid,
    input wire [31:0] m0_araddr,
    input wire [7:0] m0_arlen,
    input wire [2:0] m0_arsize,
    input wire [1:0] m0_arburst,
    input wire [1:0] m0_arlock,
    input wire m0_arvalid,
    output wire m0_arready,
    output wire [7:0] m0_rid,
    output wire [127:0] m0_rdata,
    output wire m0_rlast,
    output wire [1:0] m0_rresp,
    output wire m0_rvalid,
    input wire m0_rready,
    input wire [7:0] m2_arid,
    input wire [31:0] m2_araddr,
    input wire [7:0] m2_arlen,
    input wire [2:0] m2_arsize,
    input wire [1:0] m2_arburst,
    input wire [1:0] m2_arlock,
    input wire m2_arvalid,
    output wire m2_arready,
    output wire [7:0] m2_rid,
    output wire [127:0] m2_rdata,
    output wire m2_rlast,
    output wire [1:0] m2_rresp,
    output wire m2_rvalid,
    input wire m2_rready,
    output wire [7:0] s_arid,
    output wire [31:0] s_araddr,
    output wire [7:0] s_arlen,
    output wire [2:0] s_arsize,
    output wire [1:0] s_arburst,
    output wire [1:0] s_arlock,
    output wire s_arvalid,
    input wire s_arready,
    input wire [7:0] s_rid,
    input wire [127:0] s_rdata,
    input wire s_rlast,
    input wire [1:0] s_rresp,
    input wire s_rvalid,
    output wire s_rready,
    input wire [31:0] debug_legacy_pixel,input wire [31:0] debug_legacy_core,
    output wire [2:0] display_qos,input wire [95:0] debug_write_admission,
    input wire [511:0] debug_bus,input wire [31:0] debug_outer,
    input wire pclk,input wire prstn,
    input wire [15:0] paddr,input wire psel,input wire penable,input wire pwrite,
    input wire [31:0] pwdata,output wire [31:0] prdata,output wire pready,output wire pslverr,
    output wire legacy_psel,input wire [31:0] legacy_prdata,
    input wire legacy_pready,input wire legacy_pslverr,
    input wire [15:0] h_cnt,input wire [15:0] v_cnt,input wire de,
    input wire [15:0] legacy_pix,input wire legacy_have,
    output wire [15:0] pix,output wire have,output wire mode_active
);
    wire [15:0] debug_arbiters;
    wire legacy_av,legacy_ar,legacy_offered;wire [31:0] legacy_blocked;
    legacy_read_admission legacy_credit(.clk(clk),.rstn(rstn),
        .fifo_words(debug_legacy_core[11:0]),.arlen(m0_arlen),
        .s_valid(m0_arvalid),.s_ready(m0_arready),.m_valid(legacy_av),.m_ready(legacy_ar),
        .offered(legacy_offered),.blocked_cycles(legacy_blocked));
    wire page;wire [31:0] bullet_prdata;wire bullet_pready,bullet_pslverr;
    wire [15:0] bullet_pix;wire bullet_have;
    wire [7:0] m1_arid;
    wire [31:0] m1_araddr;
    wire [7:0] m1_arlen;
    wire [2:0] m1_arsize;
    wire [1:0] m1_arburst;
    wire [1:0] m1_arlock;
    wire m1_arvalid;
    wire m1_arready;
    wire [7:0] m1_rid;
    wire [127:0] m1_rdata;
    wire m1_rlast;
    wire [1:0] m1_rresp;
    wire m1_rvalid;
    wire m1_rready;
    assign legacy_psel=psel && !page;
    assign prdata=page?bullet_prdata:legacy_prdata;
    assign pready=page?bullet_pready:legacy_pready;
    assign pslverr=page?bullet_pslverr:legacy_pslverr;
    wire select_bullet=mode_active && v_cnt<16'd480;
    assign pix=select_bullet?bullet_pix:legacy_pix;
    assign have=select_bullet?bullet_have:legacy_have;
    bullet_platform platform (
        .display_qos(display_qos),.debug_admission({legacy_blocked,debug_write_admission}),
        .debug_legacy_pixel(debug_legacy_pixel),.debug_legacy_core(debug_legacy_core),
        .debug_bus(debug_bus),.debug_outer(debug_outer),.debug_arbiters(debug_arbiters),
        .clk(clk),.rstn(rstn),.pclk(pclk),.prstn(prstn),
        .paddr(paddr),.psel(psel),.penable(penable),.pwrite(pwrite),.pwdata(pwdata),
        .apb_sel(page),.prdata(bullet_prdata),.pready(bullet_pready),.pslverr(bullet_pslverr),
        .h_cnt(h_cnt),.v_cnt(v_cnt),.de(de),.pix(bullet_pix),.have(bullet_have),.mode_active(mode_active),
        .m_axi_arid(m1_arid),
        .m_axi_araddr(m1_araddr),
        .m_axi_arlen(m1_arlen),
        .m_axi_arsize(m1_arsize),
        .m_axi_arburst(m1_arburst),
        .m_axi_arlock(m1_arlock),
        .m_axi_arvalid(m1_arvalid),
        .m_axi_arready(m1_arready),
        .m_axi_rdata(m1_rdata),
        .m_axi_rlast(m1_rlast),
        .m_axi_rresp(m1_rresp),
        .m_axi_rvalid(m1_rvalid),
        .m_axi_rready(m1_rready)
    );
    bullet_axir_arb3 reads (
        .debug_state(debug_arbiters),
        .clk(clk),
        .rstn(rstn),
        .m0_arid(m0_arid),
        .m0_araddr(m0_araddr),
        .m0_arlen(m0_arlen),
        .m0_arsize(m0_arsize),
        .m0_arburst(m0_arburst),
        .m0_arlock(m0_arlock),
        .m0_arvalid(legacy_av),
        .m0_arready(legacy_ar),
        .m0_rid(m0_rid),
        .m0_rdata(m0_rdata),
        .m0_rlast(m0_rlast),
        .m0_rresp(m0_rresp),
        .m0_rvalid(m0_rvalid),
        .m0_rready(m0_rready),
        .m1_arid(m1_arid),
        .m1_araddr(m1_araddr),
        .m1_arlen(m1_arlen),
        .m1_arsize(m1_arsize),
        .m1_arburst(m1_arburst),
        .m1_arlock(m1_arlock),
        .m1_arvalid(m1_arvalid),
        .m1_arready(m1_arready),
        .m1_rid(m1_rid),
        .m1_rdata(m1_rdata),
        .m1_rlast(m1_rlast),
        .m1_rresp(m1_rresp),
        .m1_rvalid(m1_rvalid),
        .m1_rready(m1_rready),
        .m2_arid(m2_arid),
        .m2_araddr(m2_araddr),
        .m2_arlen(m2_arlen),
        .m2_arsize(m2_arsize),
        .m2_arburst(m2_arburst),
        .m2_arlock(m2_arlock),
        .m2_arvalid(m2_arvalid),
        .m2_arready(m2_arready),
        .m2_rid(m2_rid),
        .m2_rdata(m2_rdata),
        .m2_rlast(m2_rlast),
        .m2_rresp(m2_rresp),
        .m2_rvalid(m2_rvalid),
        .m2_rready(m2_rready),
        .s_arid(s_arid),
        .s_araddr(s_araddr),
        .s_arlen(s_arlen),
        .s_arsize(s_arsize),
        .s_arburst(s_arburst),
        .s_arlock(s_arlock),
        .s_arvalid(s_arvalid),
        .s_arready(s_arready),
        .s_rid(s_rid),
        .s_rdata(s_rdata),
        .s_rlast(s_rlast),
        .s_rresp(s_rresp),
        .s_rvalid(s_rvalid),
        .s_rready(s_rready)
    );
endmodule
