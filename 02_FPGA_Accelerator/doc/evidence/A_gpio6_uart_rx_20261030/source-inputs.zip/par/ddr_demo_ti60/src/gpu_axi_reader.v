//============================================================================
// File        : gpu_axi_reader.v
// Description : AXI4 read-only master for the display fetch path (Stage 3).
//               Reads one framebuffer line from DDR3 and pushes the beats
//               into the async DC_FIFO that feeds the pixel clock domain.
// Team        : Team B (RTL Accelerator)
//
// Place in the system:
//   DDR3 controller <- Axi_Mux master port
//                        <- Axi_Mux slave port 1 READ channel (AR/R)
//                             <- this module -> DC_FIFO -> sync_gen -> HDMI
//
// Behaviour:
//   - On line_req, latches line_base/line_bytes and reads one full line as
//     a chain of INCR bursts, each burst <= 16 beats of 16 bytes (arsize=4).
//   - Bursts NEVER cross a 4KB boundary (AXI4 requirement): the burst length
//     is clipped to min(16, ceil(remaining/16), beats_left_to_4KB).
//   - ARVALID is asserted and held until ARREADY is seen high (AXI4 rule,
//     same style as gpu_axi_master).
//   - R-channel backpressure: m_axi_rready = !fifo_full, so a full DC_FIFO
//     stalls the AXI read instead of dropping data. No re-fetch logic is
//     needed (unlike the write path), the slave simply holds RVALID.
//   - A ~2 ms stall watchdog aborts a stuck transaction and raises `error`,
//     so a dead DDR path cannot wedge the display fetch FSM forever.
//
// Interface contract (IMPORTANT for A's integration):
//   - line_req : single-cycle pulse in the aclk domain. If it comes from the
//                pixel clock domain it MUST be synchronized (2-FF + edge
//                detect) BEFORE entering this module - that logic lives in
//                the top level, not here.
//   - line_base/line_bytes : sampled at the line_req pulse; must stay stable
//                while busy=1. line_base MUST be 16-byte aligned (framebuffer
//                base 0x00200000 and stride 2560/1280 both are, so every line
//                start is aligned automatically). line_bytes MUST be a
//                multiple of 16
//                (720p: 1280*2 = 2560 B = 160 beats, exact; 640*2 = 1280 B
//                = 80 beats, exact). AXI always transfers whole 16B beats;
//                a non-multiple line_bytes would push tail garbage into the
//                FIFO and shift the next line.
//   - Next line_req is only accepted after line_done (busy=0). A line_req
//                arriving while busy is IGNORED.
//   - line_done : single-cycle pulse when the last beat of the line has
//                been written into the FIFO.
//============================================================================

`include "gpu_pkg.vh"

module gpu_axi_reader (
    input  wire         aclk,
    input  wire         aresetn,

    // ---- line fetch request (aclk domain) ---------------------------------
    input  wire         line_req,       // 1-cycle pulse: start reading a line
    input  wire [31:0]  line_base,      // DDR3 byte address of line start
    input  wire [31:0]  line_bytes,     // bytes per line (multiple of 16!)

    // ---- status -----------------------------------------------------------
    output wire         busy,           // a line fetch is in progress
    output reg          line_done,      // 1-cycle pulse: line fully in FIFO
    output reg          error,          // sticky until next line_req

    // ---- DC_FIFO write side (aclk domain) ---------------------------------
    input  wire         fifo_full,
    output wire [127:0] fifo_wdata,
    output wire         fifo_wen,

    // ---- AXI4 read address channel (Axi_Mux S1 AR) ------------------------
    output wire [7:0]   m_axi_arid,
    output reg  [31:0]  m_axi_araddr,
    output reg  [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output wire [1:0]   m_axi_arlock,
    output reg          m_axi_arvalid,
    input  wire         m_axi_arready,

    // ---- AXI4 read data channel (Axi_Mux S1 R) ----------------------------
    input  wire [7:0]   m_axi_rid,      // ignored: only one outstanding burst
    input  wire [127:0] m_axi_rdata,
    input  wire         m_axi_rlast,
    input  wire [1:0]   m_axi_rresp,    // 00 = OKAY; others set `error`
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready
);

    // AXI_Mux S1 has no ID field on the gpu_axi_master write side either; the
    // DDR3 controller ID is 4 bits but the mux port carries 8. Tie to 0.
    assign m_axi_arid    = 8'h00;
    assign m_axi_arsize  = 3'b100;      // 16 bytes per beat (128-bit)
    assign m_axi_arburst = 2'b01;       // INCR
    assign m_axi_arlock  = 2'b00;       // normal access

    localparam [1:0] ST_IDLE = 2'd0,
                     ST_AR   = 2'd1,
                     ST_R    = 2'd2,
                     ST_DONE = 2'd3;

    reg [1:0]   state;
    reg [31:0]  cur_addr;     // address of the next burst
    reg [31:0]  remaining;    // bytes left in the current line
    reg [8:0]   burst_beats;  // beats of the burst being issued (1..256)
    reg [8:0]   beat_cnt;     // beats still expected on the R channel

    assign busy = (state != ST_IDLE);

    // ---- stall watchdog (same philosophy as gpu_axi_master) ---------------
    localparam [23:0] STALL_LIMIT = 24'd200000;   // ~2 ms @ 100 MHz
    reg  [23:0] stall_cnt;
    wire        stall_abort = busy && (stall_cnt >= STALL_LIMIT);

    // ---- burst length calculation -----------------------------------------
    // beats left to the next 4KB boundary: (0x1000 - addr[11:0]) / 16.
    // cur_addr is 16-byte aligned, so the low nibble of the difference is 0.
    wire [12:0] bytes_to_4k  = 13'h1000 - {1'b0, cur_addr[11:0]};
    wire [8:0]  beats_to_4k  = {1'b0, bytes_to_4k[12:4]};          // 1..256

    // ceil(remaining / 16), clipped to 256 (lines are a few KB at most).
    // NOTE: the clipping test must look at remaining[31:12], not [31:4]:
    // for remaining = 4096, remaining[31:4] = 256 is NOT > 256, so the
    // low-nibble path would read remaining[11:4] = 0 and yield 0 beats.
    wire [8:0]  beats_remain = (|remaining[31:12]) ? 9'd256 :
                               ({1'b0, remaining[11:4]} + {8'd0, |remaining[3:0]});

    // burst_beats = min(16, beats_remain, beats_to_4k)
    wire [8:0]  burst_calc   = (beats_remain > 9'd16)  ? 9'd16 : beats_remain;
    wire [8:0]  burst_next   = (burst_calc > beats_to_4k) ? beats_to_4k
                                                          : burst_calc;

    // ---- FIFO push: combinational, qualified by real R-channel handshake ---
    assign m_axi_rready = (state == ST_R) && !fifo_full;
    assign fifo_wen     = (state == ST_R) && m_axi_rvalid && !fifo_full;
    assign fifo_wdata   = m_axi_rdata;

    always @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            state         <= ST_IDLE;
            cur_addr      <= 32'd0;
            remaining     <= 32'd0;
            burst_beats   <= 9'd0;
            beat_cnt      <= 9'd0;
            m_axi_araddr  <= 32'd0;
            m_axi_arlen   <= 8'd0;
            m_axi_arvalid <= 1'b0;
            line_done     <= 1'b0;
            error         <= 1'b0;
            stall_cnt     <= 24'd0;
        end else if (stall_abort) begin
            // watchdog: drop the stuck fetch, flag it, wait for next line_req
            state         <= ST_IDLE;
            m_axi_arvalid <= 1'b0;
            error         <= 1'b1;
            line_done     <= 1'b1;      // unblock the display side scheduler
            stall_cnt     <= 24'd0;
        end else begin
            line_done <= 1'b0;          // default: one-cycle pulse

            case (state)

                // ---- wait for a line fetch request ------------------------
                ST_IDLE: begin
                    m_axi_arvalid <= 1'b0;
                    if (line_req) begin
                        error <= 1'b0;
                        if (line_bytes == 32'd0) begin
                            line_done <= 1'b1;      // empty line: done at once
                        end else begin
                            // latch parameters; the first burst length is
                            // computed combinationally in ST_AR from these
                            cur_addr  <= line_base;
                            remaining <= line_bytes;
                            state     <= ST_AR;
                        end
                    end
                end

                // ---- issue one burst on the AR channel --------------------
                ST_AR: begin
                    if (!m_axi_arvalid) begin
                        m_axi_araddr  <= cur_addr;
                        m_axi_arlen   <= burst_next[7:0] - 8'd1;
                        burst_beats   <= burst_next;
                        m_axi_arvalid <= 1'b1;      // assert and hold
                    end else if (m_axi_arready) begin
                        m_axi_arvalid <= 1'b0;
                        beat_cnt      <= burst_beats;
                        state         <= ST_R;
                    end
                end

                // ---- receive beats, push into DC_FIFO ---------------------
                ST_R: begin
                    if (m_axi_rvalid && m_axi_rready) begin
                        beat_cnt <= beat_cnt - 9'd1;
                        if (m_axi_rresp != 2'b00)
                            error <= 1'b1;          // SLVERR/DECERR: flag, keep draining
                        if (m_axi_rlast) begin
                            // burst finished: advance to the next one
                            // ({19'd0, burst_beats, 4'b0} = burst_beats * 16)
                            cur_addr  <= cur_addr + {19'd0, burst_beats, 4'b0};
                            remaining <= remaining - {19'd0, burst_beats, 4'b0};
                            if (remaining == {19'd0, burst_beats, 4'b0})
                                state <= ST_DONE;   // that was the last burst
                            else
                                state <= ST_AR;     // issue next burst
                        end
                    end
                end

                // ---- line complete ----------------------------------------
                ST_DONE: begin
                    line_done <= 1'b1;
                    state     <= ST_IDLE;
                end

                default: state <= ST_IDLE;
            endcase

            if (state == ST_IDLE) stall_cnt <= 24'd0;
            else if (stall_cnt != 24'hFFFFFF) stall_cnt <= stall_cnt + 1'b1;
        end
    end

endmodule
