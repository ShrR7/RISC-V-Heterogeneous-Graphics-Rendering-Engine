//============================================================================
// File        : gpu_fill.v
// Description : Solid Fill engine for 2D GPU accelerator
// Team        : Team B (RTL Accelerator)
//
// Stage 8 changes (FILL_BATCH, interface_spec v0.6 draft):
//   - CTRL bit[9] (batch) + LIST_ADDR(0x34) + LIST_CNT(0x38): instead of one
//     rectangle the engine walks a DDR list of N entries, 8 B each:
//       +0  dst_addr[31:0]   (absolute, byte address)
//       +4  w[15:0]          (pixels; 0 -> entry skipped)
//       +6  h[15:0]          (lines;  0 -> entry skipped)
//     filling each with COLOR through the same pixel stream as before.
//   - LIST_ADDR must be 16-byte aligned, otherwise error=1 and nothing is
//     written.  LIST_CNT=0 -> immediate done, zero AXI traffic.
//   - LIST_CNT is a full u32 register; >1024 is refused with done+error
//     BEFORE any bus request (never silently truncated -- A review 2026-10-16).
//   - The list is fetched ONE 16B beat per AR burst (fixed ARLEN=0): the
//     engine draws the two entries of a beat only AFTER the burst has
//     completed (RLAST), so RREADY is never held low mid-burst while
//     drawing.  A multi-beat list burst would keep the read arbiter's GPU
//     slot at the head of the queue for the whole drawing phase and starve
//     the display reader (rtl12 board evidence: display underruns with
//     long lists, 0/0/0 with <=2 entries per batch).  One beat per AR lets
//     the arbiter switch to the display between bursts; one software start
//     still processes the whole list.
//   - Between rectangles the pixel address simply jumps; a flush pulse at
//     each rectangle end closes the write group (the master's burst
//     assembler is contiguous-only; copy/bitblt flush per line for the
//     same reason).
//   - A list-read SLVERR flags error, stops further entries/bursts, drains
//     the in-flight burst gracefully, then drains the write channel
//     (A review 2026-10-16: no silent continuation).
//   - Batch done is asserted only after the write channel has fully drained
//     (2-cycle settle + wr_idle + AW==B), identical to copy/bitblt
//     (A review 2026-10-16: done must mean "all B received").
//   - batch=0 keeps the Stage 2 single-rectangle behaviour bit-identical
//     (done right after the last pixel handshake, as frozen).
//============================================================================

`include "gpu_pkg.vh"

module gpu_fill (
    input  wire        clk,
    input  wire        rstn,
    input  wire        start,
    output reg         busy,
    output reg         done,
    output reg         error,
    input  wire [31:0] dst_addr,
    input  wire [15:0] width,
    input  wire [15:0] height,
    input  wire [31:0] dst_stride,
    input  wire [15:0] color,
    // Stage 8: batch (list) mode
    input  wire        batch,
    input  wire [31:0] list_addr,
    input  wire [31:0] list_cnt,          // full u32; >1024 refused
    output reg  [31:0] pixel_addr,
    output reg  [15:0] pixel_data,
    output reg         pixel_valid,
    input  wire        pixel_ready,
    // Stage 8: pulses for 1 cycle when a batch rectangle finishes, so the
    // shared gpu_axi_master commits and issues the pending groups.  This is
    // REQUIRED between rectangles: without a flush the master would chain
    // the next rect's groups onto the pending non-contiguous ones (the
    // burst assembler is contiguous-only; copy/bitblt flush per line for
    // the same reason).  Tied 0 in single-rect mode (stream is bubble-free,
    // the done flush suffices).
    output reg         flush,
    // Stage 8: shared write-channel observation (batch drain, same contract
    // as gpu_copy/gpu_bitblt)
    input  wire        wr_aw_hs,
    input  wire        wr_b_hs,
    input  wire        wr_idle,
    // AXI4 read channel (batch list fetch only; idle in single-rect mode)
    output reg  [31:0] m_axi_araddr,
    output reg  [7:0]  m_axi_arlen,
    output reg         m_axi_arvalid,
    input  wire        m_axi_arready,
    input  wire [127:0] m_axi_rdata,
    input  wire        m_axi_rlast,
    input  wire [1:0]  m_axi_rresp,
    input  wire        m_axi_rvalid,
    output wire        m_axi_rready
);

    localparam [2:0] ST_IDLE    = 3'd0,
                     ST_FILL    = 3'd1,   // single-rect (batch=0)
                     ST_DONE    = 3'd2,
                     ST_B_AR    = 3'd3,   // batch: issue list-read burst
                     ST_B_LIST  = 3'd4,   // batch: receive beats / pick entries
                     ST_B_FILL  = 3'd5,   // batch: fill current entry's rect
                     ST_B_DRAIN = 3'd6;   // batch: drain writes, then done

    reg [2:0]   state;
    reg [15:0]  x_cnt, y_cnt;

    // ---- batch bookkeeping -------------------------------------------------
    reg [15:0]  b_entries_left; // list entries not yet consumed
    reg [31:0]  b_bytes_left;   // list bytes not yet fetched from DDR
    reg [31:0]  b_ar_addr;      // address of the next list burst
    reg         b_in_flight;    // a list burst is between AR and rlast
    reg         b_err_quit;     // rresp error seen: drain burst, then quit
    reg [127:0] beat_buf;       // one 16B beat = two 8B entries
    reg         beat_valid;     // beat_buf holds unconsumed entries
    reg         beat_half;      // 0 = entry in [63:0], 1 = entry in [127:64]
    reg [31:0]  r_addr;         // current entry: dst base
    reg [15:0]  r_w, r_h;       // current entry: size
    reg [1:0]   wb_settle;      // 2-cycle settle after the final flush
    reg [15:0]  aw_cnt;         // AW handshakes since batch start
    reg [15:0]  b_cnt;          // B  handshakes since batch start

    // ---- stall watchdog (batch mode only; same philosophy as copy/bitblt) --
    localparam [23:0] STALL_LIMIT = 24'd200000;   // ~2 ms @ 100 MHz
    reg  [23:0] stall_cnt;
    wire        batch_active = (state == ST_B_AR) || (state == ST_B_LIST) ||
                               (state == ST_B_FILL) || (state == ST_B_DRAIN);
    wire        stall_abort  = batch_active && (stall_cnt >= STALL_LIMIT);

    // ---- list fetch geometry ------------------------------------------------
    // Fixed ONE beat (16 B = two entries) per AR burst; a single beat can
    // never cross a 4 KB boundary (b_ar_addr is 16B aligned), so no burst
    // splitting logic is needed at all.
    // b_bytes_left is initialised beat-rounded: ceil(cnt/2) * 16.

    // The internal beat buffer always accepts one beat at a time.
    assign m_axi_rready = (state == ST_B_LIST) && !beat_valid;

    // current entry fields (little-endian inside the 128-bit beat)
    wire [63:0] entry      = beat_half ? beat_buf[127:64] : beat_buf[63:0];
    wire [31:0] ent_addr   = entry[31:0];
    wire [15:0] ent_w      = entry[47:32];
    wire [15:0] ent_h      = entry[63:48];

    // ---- write-channel handshake counters (batch drain; the channel is
    //      exclusively ours while a batch runs, so counting here is exact) --
    wire        batch_start = start && batch &&
                              ((state == ST_IDLE) || (state == ST_DONE));
    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            aw_cnt <= 16'd0;
            b_cnt  <= 16'd0;
        end else if (batch_start) begin
            aw_cnt <= 16'd0;
            b_cnt  <= 16'd0;
        end else begin
            if (wr_aw_hs) aw_cnt <= aw_cnt + 16'd1;
            if (wr_b_hs)  b_cnt  <= b_cnt  + 16'd1;
        end
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            state <= ST_IDLE; busy <= 0; done <= 0; error <= 0;
            flush <= 0;
            pixel_valid <= 0; x_cnt <= 0; y_cnt <= 0;
            b_entries_left <= 0; b_bytes_left <= 0; b_ar_addr <= 0;
            b_in_flight <= 0; b_err_quit <= 0;
            beat_buf <= 0; beat_valid <= 0; beat_half <= 0;
            r_addr <= 0; r_w <= 0; r_h <= 0;
            wb_settle <= 0;
            stall_cnt <= 0;
            m_axi_araddr <= 0; m_axi_arlen <= 0; m_axi_arvalid <= 0;
        end else begin
            // watchdog: reset on any real progress (pixel beat, list beat,
            // AR handshake, write drain activity); only a true hang reaches
            // STALL_LIMIT
            if (!batch_active)
                stall_cnt <= 24'd0;
            else if ((pixel_valid && pixel_ready) ||
                     (m_axi_rvalid && m_axi_rready) ||
                     (m_axi_arvalid && m_axi_arready) ||
                     wr_aw_hs || wr_b_hs)
                stall_cnt <= 24'd0;
            else
                stall_cnt <= stall_cnt + 24'd1;

            flush <= 1'b0;                      // default: 1-cycle pulse
            if (stall_abort) begin
                // list fetch hung: give up cleanly, flag error
                state            <= ST_DONE;
                busy             <= 1'b0;
                done             <= 1'b1;
                error            <= 1'b1;
                pixel_valid      <= 1'b0;
                beat_valid       <= 1'b0;
                b_in_flight      <= 1'b0;
                b_err_quit       <= 1'b0;
                m_axi_arvalid    <= 1'b0;
            end else begin
            case (state)
                // ------------------------------------------------ idle ----
                ST_IDLE: begin
                    done  <= 0;
                    error <= 0;
                    if (start) begin
                        if (batch) begin
                            if (list_cnt == 32'd0) begin
                                // empty list: immediate done, zero AXI traffic
                                state <= ST_DONE; done <= 1;
                            end else if (list_addr[3:0] != 4'd0) begin
                                // list must be 16B aligned
                                state <= ST_DONE; done <= 1; error <= 1;
                            end else if (list_cnt > 32'd1024) begin
                                // out-of-spec count: refuse before any bus
                                // request; full-u32 compare, never truncated
                                // (A's Stage-8 review requirement)
                                state <= ST_DONE; done <= 1; error <= 1;
                            end else begin
                                state          <= ST_B_AR;
                                busy           <= 1'b1;
                                b_entries_left <= list_cnt[15:0];
                                b_bytes_left   <= ({13'd0, list_cnt[15:0], 3'b0}
                                                   + 32'd15) & 32'hFFFF_FFF0;
                                b_ar_addr      <= list_addr;
                                b_in_flight    <= 1'b0;
                                b_err_quit     <= 1'b0;
                                beat_valid     <= 1'b0;
                                beat_half      <= 1'b0;
                            end
                        end else if (width == 0 || height == 0) begin
                            state <= ST_DONE; done <= 1;
                        end else begin
                            state <= ST_FILL; busy <= 1;
                            x_cnt <= 0; y_cnt <= 0;
                            pixel_addr <= dst_addr;
                            pixel_data <= color;
                            pixel_valid <= 1;
                        end
                    end
                end

                // ------------------------------------ single-rect fill ----
                ST_FILL: begin
                    if (pixel_valid && pixel_ready) begin
                        if (x_cnt == width - 1) begin
                            if (y_cnt == height - 1) begin
                                state <= ST_DONE; busy <= 0; done <= 1;
                                pixel_valid <= 0;
                            end else begin
                                x_cnt <= 0; y_cnt <= y_cnt + 1;
                                pixel_addr <= dst_addr + (y_cnt + 1) * dst_stride;
                                pixel_data <= color; pixel_valid <= 1;
                            end
                        end else begin
                            x_cnt <= x_cnt + 1;
                            pixel_addr <= dst_addr + y_cnt * dst_stride + (x_cnt + 1) * 2;
                            pixel_data <= color; pixel_valid <= 1;
                        end
                    end
                end

                // --------------------------- batch: list burst address ----
                // ONE beat per AR (ARLEN=0): drawing starts only after RLAST,
                // so the read arbiter is never held mid-burst while we draw.
                ST_B_AR: begin
                    if (!m_axi_arvalid) begin
                        m_axi_araddr  <= b_ar_addr;
                        m_axi_arlen   <= 8'd0;
                        m_axi_arvalid <= 1'b1;
                    end else if (m_axi_arready) begin
                        m_axi_arvalid <= 1'b0;
                        b_in_flight   <= 1'b1;
                        b_bytes_left  <= b_bytes_left - 32'd16;
                        b_ar_addr     <= b_ar_addr   + 32'd16;
                        state         <= ST_B_LIST;
                    end
                end

                // ----------------- batch: receive beats / pick entries ----
                ST_B_LIST: begin
                    if (b_err_quit && !b_in_flight) begin
                        // list-read error: the rest of the burst has been
                        // drained; stop issuing, drain writes, report
                        pixel_valid  <= 1'b0;
                        beat_valid   <= 1'b0;
                        b_bytes_left <= 32'd0;
                        wb_settle    <= 2'd2;
                        state        <= ST_B_DRAIN;
                    end else if (m_axi_rvalid && m_axi_rready) begin
                        if (m_axi_rresp != 2'b00) begin
                            // flag and drain the rest of this burst; the
                            // buffered/queued entries are never consumed
                            error      <= 1'b1;
                            b_err_quit <= 1'b1;
                        end else begin
                            beat_buf    <= m_axi_rdata;
                            beat_valid  <= 1'b1;
                            beat_half   <= 1'b0;
                        end
                        if (m_axi_rlast)
                            b_in_flight <= 1'b0;
                    end else if (beat_valid) begin
                        // consume one entry per cycle
                        if (beat_half) beat_valid <= 1'b0;
                        beat_half      <= ~beat_half;
                        b_entries_left <= b_entries_left - 16'd1;
                        if (ent_w == 16'd0 || ent_h == 16'd0) begin
                            // empty rect: skip; batch end may follow
                            if (b_entries_left == 16'd1) begin
                                // last entry: done only after write drain
                                wb_settle <= 2'd2;
                                state     <= ST_B_DRAIN;
                            end
                        end else begin
                            r_addr <= ent_addr;
                            r_w    <= ent_w;
                            r_h    <= ent_h;
                            x_cnt  <= 16'd0;
                            y_cnt  <= 16'd0;
                            pixel_addr  <= ent_addr;
                            pixel_data  <= color;
                            pixel_valid <= 1'b1;
                            state       <= ST_B_FILL;
                        end
                    end else if (!b_in_flight) begin
                        // no buffered entry and no burst in flight: if bytes
                        // remain, fetch the next burst; a gap here means the
                        // last burst was fully consumed and only entry pickup
                        // is left (handled above) -- so bytes must be > 0
                        if (b_bytes_left != 32'd0)
                            state <= ST_B_AR;
                    end
                end

                // -------------------------- batch: fill current rect ------
                ST_B_FILL: begin
                    if (pixel_valid && pixel_ready) begin
                        if (x_cnt == r_w - 1) begin
                            if (y_cnt == r_h - 1) begin
                                pixel_valid <= 0;
                                flush       <= 1'b1;   // commit+issue this rect
                                if (b_entries_left == 16'd0) begin
                                    // last rect: done only after write drain
                                    wb_settle <= 2'd2;
                                    state     <= ST_B_DRAIN;
                                end else begin
                                    state <= ST_B_LIST;
                                end
                            end else begin
                                x_cnt <= 0; y_cnt <= y_cnt + 1;
                                pixel_addr <= r_addr + (y_cnt + 1) * dst_stride;
                                pixel_data <= color; pixel_valid <= 1;
                            end
                        end else begin
                            x_cnt <= x_cnt + 1;
                            pixel_addr <= r_addr + y_cnt * dst_stride + (x_cnt + 1) * 2;
                            pixel_data <= color; pixel_valid <= 1;
                        end
                    end
                end

                // -------- batch: wait for the write master to drain --------
                // Same quiescence rule as gpu_copy/gpu_bitblt: after the last
                // flush the master commits buffered groups and registers
                // awvalid a cycle later, so settle two cycles first; done is
                // asserted only when every AW has its B.
                ST_B_DRAIN: begin
                    if (wb_settle != 2'd0) begin
                        wb_settle <= wb_settle - 2'd1;
                    end else if (wr_idle && (aw_cnt == b_cnt)) begin
                        state <= ST_DONE;
                        busy  <= 1'b0;
                        done  <= 1'b1;
                    end
                end

                // ------------------------------------------------ done -----
                ST_DONE: begin
                    busy <= 0;
                    if (start) begin
                        done  <= 0;
                        error <= 0;
                        if (batch) begin
                            if (list_cnt == 32'd0) begin
                                done <= 1;
                            end else if (list_addr[3:0] != 4'd0) begin
                                done <= 1; error <= 1;
                            end else if (list_cnt > 32'd1024) begin
                                // out-of-spec count: refuse before any bus
                                // request (A's Stage-8 review requirement)
                                done <= 1; error <= 1;
                            end else begin
                                state          <= ST_B_AR;
                                busy           <= 1'b1;
                                b_entries_left <= list_cnt[15:0];
                                b_bytes_left   <= ({13'd0, list_cnt[15:0], 3'b0}
                                                   + 32'd15) & 32'hFFFF_FFF0;
                                b_ar_addr      <= list_addr;
                                b_in_flight    <= 1'b0;
                                b_err_quit     <= 1'b0;
                                beat_valid     <= 1'b0;
                                beat_half      <= 1'b0;
                            end
                        end else if (width == 0 || height == 0) begin
                            done <= 1;
                        end else begin
                            state <= ST_FILL; busy <= 1; x_cnt <= 0; y_cnt <= 0;
                            pixel_addr <= dst_addr; pixel_data <= color; pixel_valid <= 1;
                        end
                    end
                end

                default: state <= ST_IDLE;
            endcase
            end
        end
    end
endmodule
