//============================================================================
// File        : bullet_line_render.v
// Description : Stage 9 scanline bullet renderer, 128-bit beat architecture.
//               Loads one 1280-pixel background line from DDR, then overlays
//               16x16 bullets selected by bullet_desc_loader's vertical bands
//               into ping-pong 160x128-bit line buffers.  No bullet pixels
//               are written to DDR.
// Team        : Team B (RTL Accelerator)
//
// Beat pipeline (replaces the earlier 16-bit pixel RMW, which could not be
// mapped to dual-port RAM by Efinity):
//   * Two atlas beats are read into a 256-bit sprite-row register.
//   * Each destination beat is read as a full 128-bit word, merged with up
//     to 8 source pixels (alignment/key/alpha/clipping), and written back as
//     ONE full word.  There are no sub-word writes and no 8-pixel write ports.
//   * One destination beat is retired per cycle.  Descriptor order is kept,
//     so later bullets observe earlier writes exactly as in the reference.
//   * Alpha16 instantiates the same RGB565 round-to-nearest blend per lane.
//   * The display port remains 16-bit: full-beat synchronous reads followed
//     by a registered-lane mux, so A's interface does not change.
//
// Descriptor order: current and previous bands are merged by descriptor ID,
// not processed serially.  Only the consumed merge head is advanced.
// All memories use plain synchronous read registers; no read-port muxes.
// Background AXI reads keep RREADY high for the whole burst (<=16 beats,
// never cross 4 KB).
//============================================================================

module bullet_line_render (
    input  wire         clk,
    input  wire         rstn,
    input  wire         start_line,
    input  wire [15:0]  line_num,
    input  wire [31:0]  bg_line_addr,
    input  wire         bank,
    output reg          busy,
    output reg          done,
    output reg          error,

    input  wire [15:0]  color_key,
    input  wire         alpha_en,
    input  wire [5:0]   alpha_val,

    output reg  [31:0]  m_axi_araddr,
    output reg  [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output reg          m_axi_arvalid,
    input  wire         m_axi_arready,
    input  wire [127:0] m_axi_rdata,
    input  wire         m_axi_rlast,
    input  wire [1:0]   m_axi_rresp,
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready,

    output wire [10:0]  desc_rd_idx,
    input  wire [127:0] desc_rd_data,
    output wire [4:0]   band_rd_idx,
    input  wire [11:0]  band_rd_base,
    input  wire [11:0]  band_rd_count,
    output wire [11:0]  band_mem_rd_addr,
    input  wire [10:0]  band_mem_rd_id,

    input  wire         atlas_we,
    input  wire [9:0]   atlas_waddr,
    input  wire [127:0] atlas_wdata,

    input  wire [10:0]  disp_rd_idx,
    input  wire         disp_rd_bank,
    output wire [15:0]  disp_rd_data,

    output reg  [31:0]  stat_cycles,
    output reg  [31:0]  stat_bg_ar_cycles,
    output reg  [31:0]  stat_bg_r_cycles,
    output reg  [31:0]  stat_compute_cycles,
    output reg  [11:0]  stat_sprites,
    output reg  [11:0]  stat_entries,
    output wire [4:0]   dbg_state,
    output wire [31:0]  dbg_cur_total,
    output wire [31:0]  dbg_cur_bg_ar,
    output wire [31:0]  dbg_cur_bg_r,
    output wire [31:0]  dbg_cur_compute,
    output wire [8:0]   dbg_bg_left,
    output wire [7:0]   dbg_bg_wr_beat,
    output wire [8:0]   dbg_burst_beats,
    output wire [31:0]  dbg_bg_ar_addr,
    output wire [7:0]   dbg_bg_arlen,
    output wire         dbg_bg_arvalid,
    output wire         dbg_bg_arready,
    output wire         dbg_bg_rvalid,
    output wire [8:0]   dbg_ar_left,
    output wire [1:0]   dbg_outstanding
);

    assign dbg_state = state;
    assign dbg_cur_total = cycle_cnt;
    assign dbg_cur_bg_ar = bg_ar_cnt;
    assign dbg_cur_bg_r = bg_r_cnt;
    assign dbg_cur_compute = compute_cnt;
    assign dbg_bg_left = bg_left;
    assign dbg_bg_wr_beat = bg_wr_beat;
    assign dbg_burst_beats = burst_beats;
    assign dbg_bg_ar_addr = m_axi_araddr;
    assign dbg_bg_arlen = m_axi_arlen;
    assign dbg_bg_arvalid = m_axi_arvalid;
    assign dbg_bg_arready = m_axi_arready;
    assign dbg_bg_rvalid = m_axi_rvalid;
    assign dbg_ar_left = ar_left;
    assign dbg_outstanding = outstanding;

    localparam integer BG_BEATS = 160;

    assign m_axi_arsize  = 3'b100;
    assign m_axi_arburst = 2'b01;
    assign m_axi_rready  = (state == ST_BG_R);

    localparam [4:0] ST_IDLE       = 5'd0,
                     ST_BG_AR      = 5'd1,
                     ST_BG_R       = 5'd2,
                     ST_BAND_REQ   = 5'd3,
                     ST_BAND_WAIT0 = 5'd4,
                     ST_BAND_WAIT1 = 5'd5,
                     ST_HCUR_REQ   = 5'd6,
                     ST_HCUR_WAIT0 = 5'd7,
                     ST_HCUR_WAIT1 = 5'd8,
                     ST_HPRV_REQ   = 5'd9,
                     ST_HPRV_WAIT0 = 5'd10,
                     ST_HPRV_WAIT1 = 5'd11,
                     ST_SELECT     = 5'd12,
                     ST_DESC_WAIT0 = 5'd13,
                     ST_DESC_WAIT1 = 5'd14,
                     ST_SPR0       = 5'd15,
                     ST_SPR1       = 5'd16,
                     ST_SPR2       = 5'd17,
                     ST_BEAT       = 5'd18,
                     ST_NEXT       = 5'd19,
                     ST_ACUR_REQ   = 5'd20,
                     ST_ACUR_WAIT  = 5'd21,
                     ST_APRV_REQ   = 5'd22,
                     ST_APRV_WAIT  = 5'd23;

    reg [4:0] state;
    reg [15:0] line_r;
    reg        bank_r;
    reg [31:0] bg_ar_addr;
    reg [8:0]  bg_left;          // beats not yet retired by RLAST
    reg [8:0]  ar_left;          // beats not yet requested by AR
    reg [7:0]  bg_wr_beat;
    reg [8:0]  burst_beats;      // length of the burst currently returning
    reg [8:0]  next_burst;       // length of the prefetched following burst
    reg [1:0]  outstanding;      // accepted ARs not yet closed by RLAST (0..2)
    reg        stop_after_burst;

    reg [4:0]  cur_band;
    reg        band_pass;
    reg [11:0] cur_base, cur_count;
    reg [11:0] prv_base, prv_count;
    reg [11:0] idx_cur, idx_prv;
    reg [11:0] id_cur, id_prv;
    reg        sel_cur;

    reg [15:0]  x_base;
    reg [9:0]   spr_rd_beat;
    reg [127:0] spr_lo, spr_hi;
    reg [7:0]   beat_start, beat_idx, beat_end;

    reg [127:0] atlas_ram [0:1023];
    reg [127:0] line_bufA [0:159];
    reg [127:0] line_bufB [0:159];

    reg [127:0] atlas_data;
    reg [127:0] dst_dataA, dst_dataB;
    reg [127:0] disp_dataA, disp_dataB;
    reg [2:0]   disp_lane;

    reg [31:0] cycle_cnt;
    reg [31:0] bg_ar_cnt, bg_r_cnt, compute_cnt;
    reg [11:0] sprite_cnt, entry_cnt;

    localparam [23:0] STALL_LIMIT = 24'd200000;
    reg [23:0] stall_cnt;
    wire stall_abort = busy && (stall_cnt >= STALL_LIMIT);

    integer i;
    integer si;
    reg [127:0] merged;

    // A-verified single-write/two-read RAM form: the background and RMW
    // choices are combined BEFORE the memories.  Each line buffer has only
    // one physical write enable/address/data, never two FSM write sites.
    wire bg_we  = (state == ST_BG_R) && m_axi_rvalid && m_axi_rready;
    wire rmw_we = (state == ST_BEAT);
    wire lb_we  = bg_we || rmw_we;
    wire [7:0] lb_wa = bg_we ? bg_wr_beat : beat_idx;
    wire [127:0] lb_wd = bg_we ? m_axi_rdata : merged;
    wire lb_weA = lb_we && !bank_r;
    wire lb_weB = lb_we &&  bank_r;

    // Lane merge is combinational so it can feed the unified write data.
    always @* begin
        for (i = 0; i < 8; i = i + 1) begin
            si = $signed({1'b0,beat_idx,3'b000}) + i - $signed(x_base);
            if ((si >= 0) && (si < 16) &&
                (spr_row[si*16 +: 16] != color_key)) begin
                merged[i*16 +: 16] = alpha_en ?
                    blend565(spr_row[si*16 +: 16],
                             dst_data[i*16 +: 16], alpha_val) :
                    spr_row[si*16 +: 16];
            end else begin
                merged[i*16 +: 16] = dst_data[i*16 +: 16];
            end
        end
    end

    wire [12:0] bytes_to_4k = 13'h1000 - {1'b0, bg_ar_addr[11:0]};
    wire [8:0]  beats_to_4k = {1'b0, bytes_to_4k[12:4]};
    wire [8:0]  burst_calc  = (ar_left > 9'd16) ? 9'd16 : ar_left;
    wire [8:0]  burst_next  = (burst_calc > beats_to_4k) ? beats_to_4k : burst_calc;

    wire [255:0] spr_row = {spr_hi, spr_lo};
    wire [127:0] dst_data = bank_r ? dst_dataB : dst_dataA;
    wire signed [16:0] line_dy = $signed({1'b0,line_r}) -
                                 $signed(desc_rd_data[31:16]);
    wire        desc_on_line = desc_rd_data[80] &&
                               (line_dy >= 0) && (line_dy < 16);
    wire signed [16:0] desc_x = $signed(desc_rd_data[15:0]);
    wire signed [16:0] raw_start = desc_x >>> 3;
    wire signed [16:0] raw_end   = ($signed(desc_x) + 17'sd15) >>> 3;
    wire [7:0] clamped_start = (raw_start < 0) ? 8'd0 : raw_start[7:0];
    wire [7:0] clamped_end   = (raw_end > 159) ? 8'd159 : raw_end[7:0];
    wire       sprite_offscreen = (desc_x >= 1280) ||
                                  (($signed(desc_x) + 17'sd15) < 0);

    // First destination read happens in ST_SPR2; subsequent reads look one
    // beat ahead while the current beat is merged/written.
    wire [7:0] dst_beat_addr = (state == ST_SPR2) ? beat_start :
                               ((state == ST_BEAT) && (beat_idx != beat_end)) ?
                                   (beat_idx + 1'b1) : beat_idx;
    wire [127:0] disp_word = disp_rd_bank ? disp_dataB : disp_dataA;
    assign disp_rd_data = disp_word[{disp_lane, 4'b0} +: 16];

    assign desc_rd_idx = (state == ST_SELECT) ?
                         ((id_cur <= id_prv) ? id_cur[10:0] : id_prv[10:0]) :
                         11'd0;
    assign band_rd_idx = (state == ST_BAND_REQ) ?
                         (band_pass ? (cur_band - 1'b1) : cur_band) : 5'd0;
    assign band_mem_rd_addr =
        ((state == ST_HCUR_REQ) || (state == ST_ACUR_REQ)) ?
            (cur_base + idx_cur) :
        ((state == ST_HPRV_REQ) || (state == ST_APRV_REQ)) ?
            (prv_base + idx_prv) : 12'd0;

    function [31:0] sat32(input [31:0] v);
        begin
            sat32 = (v == 32'hFFFF_FFFF) ? v : (v + 1'b1);
        end
    endfunction

    function [15:0] blend565(input [15:0] s, input [15:0] d, input [5:0] a);
        reg [5:0] ia;
        reg [12:0] acc_r, acc_g, acc_b;
        begin
            ia    = 6'd32 - a;
            acc_r = {8'd0, s[15:11]} * a + {8'd0, d[15:11]} * ia + 13'd16;
            acc_g = {7'd0, s[10:5]}  * a + {7'd0, d[10:5]}  * ia + 13'd16;
            acc_b = {8'd0, s[4:0]}   * a + {8'd0, d[4:0]}   * ia + 13'd16;
            blend565 = {acc_r[9:5], acc_g[10:5], acc_b[9:5]};
        end
    endfunction

    // Plain synchronous full-beat read ports (no reset, no read-expression mux).
    always @(posedge clk) begin
        atlas_data <= atlas_ram[spr_rd_beat];
        dst_dataA  <= line_bufA[dst_beat_addr];
        dst_dataB  <= line_bufB[dst_beat_addr];
        disp_dataA <= line_bufA[disp_rd_idx[10:3]];
        disp_dataB <= line_bufB[disp_rd_idx[10:3]];
        disp_lane  <= disp_rd_idx[2:0];
    end

    always @(posedge clk) begin
        if (atlas_we)
            atlas_ram[atlas_waddr] <= atlas_wdata;
        if (lb_weA)
            line_bufA[lb_wa] <= lb_wd;
        if (lb_weB)
            line_bufB[lb_wa] <= lb_wd;
    end

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            state            <= ST_IDLE;
            busy             <= 1'b0;
            done             <= 1'b0;
            error            <= 1'b0;
            line_r           <= 16'd0;
            bank_r           <= 1'b0;
            bg_ar_addr       <= 32'd0;
            bg_left          <= 9'd0;
            ar_left          <= 9'd0;
            bg_wr_beat       <= 8'd0;
            burst_beats      <= 9'd0;
            next_burst       <= 9'd0;
            outstanding      <= 2'd0;
            stop_after_burst <= 1'b0;
            cur_band         <= 5'd0;
            band_pass        <= 1'b0;
            cur_base         <= 12'd0;
            cur_count        <= 12'd0;
            prv_base         <= 12'd0;
            prv_count        <= 12'd0;
            idx_cur          <= 12'd0;
            idx_prv          <= 12'd0;
            id_cur           <= 12'hFFF;
            id_prv           <= 12'hFFF;
            sel_cur          <= 1'b0;
            x_base           <= 16'd0;
            spr_rd_beat      <= 10'd0;
            spr_lo           <= 128'd0;
            spr_hi           <= 128'd0;
            beat_start       <= 8'd0;
            beat_idx         <= 8'd0;
            beat_end         <= 8'd0;
            cycle_cnt        <= 32'd0;
            bg_ar_cnt        <= 32'd0;
            bg_r_cnt         <= 32'd0;
            compute_cnt      <= 32'd0;
            sprite_cnt       <= 12'd0;
            entry_cnt        <= 12'd0;
            stat_cycles      <= 32'd0;
            stat_bg_ar_cycles<= 32'd0;
            stat_bg_r_cycles <= 32'd0;
            stat_compute_cycles<=32'd0;
            stat_sprites     <= 12'd0;
            stat_entries     <= 12'd0;
            stall_cnt        <= 24'd0;
            m_axi_araddr     <= 32'd0;
            m_axi_arlen      <= 8'd0;
            m_axi_arvalid    <= 1'b0;
        end else if (stall_abort) begin
            state         <= ST_IDLE;
            busy          <= 1'b0;
            done          <= 1'b1;
            error         <= 1'b1;
            m_axi_arvalid <= 1'b0;
            stall_cnt     <= 24'd0;
        end else begin
            if (busy) begin
                cycle_cnt <= sat32(cycle_cnt);
                if (state == ST_BG_AR)
                    bg_ar_cnt <= sat32(bg_ar_cnt);
                else if (state == ST_BG_R)
                    bg_r_cnt <= sat32(bg_r_cnt);
                else
                    compute_cnt <= sat32(compute_cnt);
                if ((m_axi_arvalid && m_axi_arready) ||
                    (m_axi_rvalid && m_axi_rready) ||
                    (state != ST_BG_AR && state != ST_BG_R))
                    stall_cnt <= 24'd0;
                else if (stall_cnt != 24'hFFFFFF)
                    stall_cnt <= stall_cnt + 1'b1;
            end else begin
                stall_cnt <= 24'd0;
            end

            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start_line) begin
                        done             <= 1'b0;
                        error            <= 1'b0;
                        busy             <= 1'b1;
                        line_r           <= line_num;
                        bank_r           <= bank;
                        bg_ar_addr       <= bg_line_addr;
                        bg_left          <= BG_BEATS;
                        ar_left          <= BG_BEATS;
                        bg_wr_beat       <= 8'd0;
                        burst_beats      <= 9'd0;
                        next_burst       <= 9'd0;
                        outstanding      <= 2'd0;
                        stop_after_burst <= 1'b0;
                        cur_band         <= line_num[8:4];
                        band_pass        <= 1'b0;
                        cycle_cnt        <= 32'd0;
                        bg_ar_cnt        <= 32'd0;
                        bg_r_cnt         <= 32'd0;
                        compute_cnt      <= 32'd0;
                        sprite_cnt       <= 12'd0;
                        entry_cnt        <= 12'd0;
                        state            <= ST_BG_AR;
                    end
                end

                ST_BG_AR: begin
                    if (!m_axi_arvalid) begin
                        m_axi_araddr  <= bg_ar_addr;
                        m_axi_arlen   <= burst_next[7:0] - 8'd1;
                        m_axi_arvalid <= 1'b1;
                    end else if (m_axi_arready) begin
                        m_axi_arvalid <= 1'b0;
                        burst_beats   <= burst_next;
                        next_burst    <= 9'd0;
                        outstanding   <= 2'd1;
                        bg_ar_addr    <= bg_ar_addr + {23'd0,burst_next,4'b0};
                        ar_left       <= ar_left - burst_next;
                        state         <= ST_BG_R;
                    end
                end

                ST_BG_R: begin
                    // Prefetch the next burst while the current one returns.
                    // At most two outstanding bursts (the arbiter's owner
                    // FIFO depth).  RREADY stays high for the whole phase.
                    if (!m_axi_arvalid && (ar_left != 9'd0) &&
                        (outstanding < 2'd2) && !stop_after_burst &&
                        !(m_axi_rvalid && m_axi_rready &&
                          (m_axi_rresp != 2'b00))) begin
                        m_axi_araddr  <= bg_ar_addr;
                        m_axi_arlen   <= burst_next[7:0] - 8'd1;
                        m_axi_arvalid <= 1'b1;
                    end else if (m_axi_arvalid && m_axi_arready) begin
                        m_axi_arvalid <= 1'b0;
                        bg_ar_addr    <= bg_ar_addr + {23'd0,burst_next,4'b0};
                        ar_left       <= ar_left - burst_next;
                    end

                    if (m_axi_rvalid && m_axi_rready) begin
                        // line_bufA/B are written by the unified lb_we/lb_wa/lb_wd
                        // port above, not by an FSM-local memory assignment.
                        bg_wr_beat <= bg_wr_beat + 1'b1;
                        if (m_axi_rresp != 2'b00) begin
                            error            <= 1'b1;
                            stop_after_burst <= 1'b1;
                        end
                        if (m_axi_rlast) begin
                            bg_left <= bg_left - burst_beats;
                            if (stop_after_burst || (m_axi_rresp != 2'b00)) begin
                                // Stop issuing, but drain every accepted burst.
                                // ARVALID may still be pending or be accepted
                                // on this very edge; done must wait until no
                                // presented request remains and all accepted
                                // bursts have retired (A's two reproductions).
                                if ((outstanding == 2'd1) && !m_axi_arvalid) begin
                                    state <= ST_IDLE;
                                    busy  <= 1'b0;
                                    done  <= 1'b1;
                                end
                            end else if (bg_left == burst_beats) begin
                                state <= ST_BAND_REQ;
                            end
                        end
                    end

                    // Burst-length queue and outstanding accounting.  AR and
                    // RLAST may coincide; each case keeps the returning
                    // burst's length aligned with the data stream.
                    case ({(m_axi_arvalid && m_axi_arready),
                           (m_axi_rvalid && m_axi_rready && m_axi_rlast)})
                        2'b10: begin
                            if (outstanding == 2'd0) begin
                                burst_beats <= burst_next;
                                next_burst  <= 9'd0;
                            end else begin
                                next_burst  <= burst_next;
                            end
                            outstanding <= outstanding + 1'b1;
                        end
                        2'b01: begin
                            burst_beats <= next_burst;
                            next_burst  <= 9'd0;
                            outstanding <= outstanding - 1'b1;
                        end
                        2'b11: begin
                            if (outstanding == 2'd1) begin
                                burst_beats <= burst_next;
                                next_burst  <= 9'd0;
                            end else begin
                                burst_beats <= next_burst;
                                next_burst  <= burst_next;
                            end
                            // count unchanged: one accepted, one retired
                        end
                        default: begin end
                    endcase
                end

                ST_BAND_REQ: state <= ST_BAND_WAIT1;
                ST_BAND_WAIT0: state <= ST_BAND_WAIT1;

                ST_BAND_WAIT1: begin
                    if (!band_pass) begin
                        cur_base  <= band_rd_base;
                        cur_count <= band_rd_count;
                        if (cur_band != 0) begin
                            band_pass <= 1'b1;
                            state     <= ST_BAND_REQ;
                        end else begin
                            prv_base  <= 12'd0;
                            prv_count <= 12'd0;
                            idx_cur   <= 12'd0;
                            idx_prv   <= 12'd0;
                            state     <= ST_HCUR_REQ;
                        end
                    end else begin
                        prv_base  <= band_rd_base;
                        prv_count <= band_rd_count;
                        idx_cur   <= 12'd0;
                        idx_prv   <= 12'd0;
                        state     <= ST_HCUR_REQ;
                    end
                end

                ST_HCUR_REQ: begin
                    if (idx_cur < cur_count)
                        state <= ST_HCUR_WAIT1;
                    else begin
                        id_cur <= 12'hFFF;
                        state  <= ST_HPRV_REQ;
                    end
                end
                ST_HCUR_WAIT0: state <= ST_HCUR_WAIT1;
                ST_HCUR_WAIT1: begin
                    id_cur <= {1'b0, band_mem_rd_id};
                    state  <= ST_HPRV_REQ;
                end

                ST_HPRV_REQ: begin
                    if (idx_prv < prv_count)
                        state <= ST_HPRV_WAIT1;
                    else begin
                        id_prv <= 12'hFFF;
                        state  <= ST_SELECT;
                    end
                end
                ST_HPRV_WAIT0: state <= ST_HPRV_WAIT1;
                ST_HPRV_WAIT1: begin
                    id_prv <= {1'b0, band_mem_rd_id};
                    state  <= ST_SELECT;
                end

                ST_SELECT: begin
                    if ((id_cur == 12'hFFF) && (id_prv == 12'hFFF)) begin
                        stat_cycles  <= cycle_cnt;
                        stat_bg_ar_cycles <= bg_ar_cnt;
                        stat_bg_r_cycles  <= bg_r_cnt;
                        stat_compute_cycles <= compute_cnt;
                        stat_sprites <= sprite_cnt;
                        stat_entries <= entry_cnt;
                        state        <= ST_IDLE;
                        busy         <= 1'b0;
                        done         <= 1'b1;
                    end else begin
                        sel_cur <= (id_cur <= id_prv);
                        if (id_cur <= id_prv)
                            idx_cur <= idx_cur + 1'b1;
                        else
                            idx_prv <= idx_prv + 1'b1;
                        entry_cnt <= entry_cnt + 1'b1;
                        state     <= ST_DESC_WAIT1;
                    end
                end

                ST_DESC_WAIT0: state <= ST_DESC_WAIT1;

                ST_DESC_WAIT1: begin
                    if (desc_on_line && (desc_rd_data[79:64] < 16'd32) &&
                        !sprite_offscreen) begin
                        x_base      <= desc_rd_data[15:0];
                        spr_rd_beat <= {desc_rd_data[68:64], 5'd0} +
                                       {3'd0, line_dy[3:0], 1'b0};
                        beat_start  <= clamped_start;
                        beat_end    <= clamped_end;
                        sprite_cnt  <= sprite_cnt + 1'b1;
                        state       <= ST_SPR0;
                    end else begin
                        if (desc_on_line && (desc_rd_data[79:64] >= 16'd32))
                            error <= 1'b1;
                        state <= ST_NEXT;
                    end
                end

                ST_SPR0: begin
                    spr_rd_beat <= spr_rd_beat + 1'b1;
                    state       <= ST_SPR1;
                end

                ST_SPR1: begin
                    spr_lo      <= atlas_data;
                    spr_rd_beat <= spr_rd_beat + 1'b1;
                    state       <= ST_SPR2;
                end

                ST_SPR2: begin
                    spr_hi   <= atlas_data;
                    beat_idx <= beat_start;
                    state    <= ST_BEAT;
                end

                ST_BEAT: begin
                    // merged/lb_we/lb_wa/lb_wd perform the full-beat RMW in
                    // the unified line-buffer write block above.
                    if (beat_idx == beat_end)
                        state <= ST_NEXT;
                    else
                        beat_idx <= beat_idx + 1'b1;
                end

                ST_NEXT: state <= sel_cur ? ST_ACUR_REQ : ST_APRV_REQ;

                ST_ACUR_REQ: begin
                    if (idx_cur < cur_count)
                        state <= ST_ACUR_WAIT;
                    else begin
                        id_cur <= 12'hFFF;
                        state  <= ST_SELECT;
                    end
                end
                ST_ACUR_WAIT: begin
                    id_cur <= {1'b0, band_mem_rd_id};
                    state  <= ST_SELECT;
                end

                ST_APRV_REQ: begin
                    if (idx_prv < prv_count)
                        state <= ST_APRV_WAIT;
                    else begin
                        id_prv <= 12'hFFF;
                        state  <= ST_SELECT;
                    end
                end
                ST_APRV_WAIT: begin
                    id_prv <= {1'b0, band_mem_rd_id};
                    state  <= ST_SELECT;
                end

                default: state <= ST_IDLE;
            endcase
        end
    end

endmodule
