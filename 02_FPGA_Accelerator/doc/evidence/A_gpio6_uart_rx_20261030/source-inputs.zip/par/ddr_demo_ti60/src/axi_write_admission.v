// A-owned AW admission only. W and B stay on their original paths.
// Once offered to the mux, a request remains offered through any QoS change.
// An AW that predates urgent may still enter DDR; it must drain normally.
module axi_write_admission (
 input wire clk,input wire rstn,input wire enable,input wire urgent,
 input wire s_valid,output wire s_ready,
 output wire m_valid,input wire m_ready,input wire b_handshake,
 output reg [8:0] outstanding,output reg offered,
 output reg [31:0] blocked_cycles
);
 wire take=m_valid && m_ready;
 // A sustained display fault must not indefinitely prevent the CPU from
 // storing state and reaching its protection/recovery path. At low water,
 // allow one transaction after 1024 blocked cycles, still AW-to-B limited.
 reg [9:0] urgent_age;
 wire may_offer=!enable || (outstanding==0 && (!urgent || urgent_age==1023));
 assign m_valid=offered && s_valid;
 assign s_ready=offered && m_ready;
 always @(posedge clk or negedge rstn)begin
  if(!rstn)begin outstanding<=0;offered<=0;blocked_cycles<=0;urgent_age<=0;end
  else begin
   if(!enable || !urgent || !s_valid || offered || outstanding!=0)urgent_age<=0;
   else if(urgent_age!=1023)urgent_age<=urgent_age+1'b1;
   if(take)offered<=0;
   else if(!offered && s_valid && may_offer)offered<=1;
   case({take,b_handshake})
    2'b10:outstanding<=outstanding+1'b1;
    2'b01:outstanding<=outstanding-1'b1;
    default:begin end
   endcase
   if(s_valid && !offered && !may_offer && blocked_cycles!=32'hffffffff)
    blocked_cycles<=blocked_cycles+1'b1;
  end
 end
endmodule
