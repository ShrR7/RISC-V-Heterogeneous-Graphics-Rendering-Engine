// RGB565 stream unpacker, Normal-mode FIFO; runtime horizontal phase repair.
// rtl8: debt = (enabled scan advances - stream pixels consumed) mod 1280.
// A displayed pixel advances both sides. A black active clock advances only
// scan; a discarded stream pixel advances only stream. Count black clocks
// DURING catchup too. Modulo arithmetic never saturates, including outages
// spanning arbitrarily many complete lines. This restores horizontal phase,
// not missing row identity (the stream contains no line/frame tags).
//
// OFF is the rtl6 datapath verbatim in next-state form. Disable clears only
// repair state, never a pending FIFO read or buffered data. A new ON epoch is
// armed in blanking: no OFF history or partial OFF line can become new debt.
// A pre-existing OFF offset is not retroactively corrected by enabling.
//
// Start a repair at de_fall; it may span active lines if data arrives late.
// In that case have stays low until a word can be retained at the exact lane.
// The one outstanding FIFO response belongs to the stream even if it arrives
// on de_fall or an enable transition. Never clear rd_pend to cancel a read.
// relock_busy reflects the real repair state, including the very first cycle.
// relock_tgl marks repair initiation, not proof that HDMI is aligned.
// HDMI/reset/fetch timing and APB interface are unchanged; default remains OFF.

module px_serial (
    input  wire         pclk,
    input  wire         prst_n,

    input  wire         de,             // active video
    input  wire         line_start,     // 1-cycle pulse at the first active pixel

    // ---- DC_FIFO read side (pixel clock domain) ---------------------------
    input  wire [127:0] fifo_dout,      // DC_FIFO RdData
    input  wire         fifo_empty,     // DC_FIFO RdEmpty
    input  wire         fifo_dataval,   // DC_FIFO DataVal
    output wire         fifo_ren,       // DC_FIFO RdEn

    // ---- pixel out ---------------------------------------------------------
    output wire [15:0]  pix,            // RGB565 of the current pixel
    output reg          underrun,       // sticky per line

    // ---- OBSERVATION ONLY: the internal `have` flag, routed out -----------
    output reg          have,           // 1 = wbuf holds a valid word

    // ---- runtime horizontal phase relock, DEFAULT OFF ----------------------------
    //      `relock_en` is the only functional input this delivery adds.  It is
    //      driven by DBG_CTRL bit2 through a 2-FF synchroniser BELOW, so it
    //      must be treated as a quasi-static level (do not toggle it per line).
    input  wire         relock_en,
    //      `relock_tgl` flips once per correction started (so the
    //      debug page can prove the relock fired); `relock_busy` is high while
    //      a correction is still skipping pixels.  Both are observation-only.
    output reg          relock_tgl,
    output wire         relock_busy
);

    localparam [11:0] HACTIVE = 12'd1280;
    reg [127:0] wbuf, wbuf_n;
    reg [2:0] idx, idx_n;
    reg rd_pend, rd_pend_n, have_n;
    reg ren_s1, ren_s2, armed, armed_n, de_q;
    reg [11:0] phase_debt, phase_debt_n;
    reg catchup, catchup_n, relock_tgl_n;
    reg [11:0] debt;
    wire rlen = ren_s2;
    wire de_fall = de_q && !de;
    wire [11:0] room = 12'd8 - {9'd0,idx};

    assign pix = (de && have) ? wbuf[{idx,4'b0} +: 16] : 16'h0000;
    assign relock_busy = catchup;
    // Normal FIFO response is captured one edge after a request; idx==6
    // requests the replacement for the edge consuming lane 7.
    assign fifo_ren = !rd_pend && !fifo_empty &&
                     ((rlen && armed && catchup) || !have || (de && idx==3'd6));

    always @* begin
        wbuf_n=wbuf; idx_n=idx; have_n=have; rd_pend_n=rd_pend;
        phase_debt_n=phase_debt; armed_n=armed;
        catchup_n=catchup; relock_tgl_n=relock_tgl;
        debt=phase_debt;
        if(fifo_ren) rd_pend_n=1'b1;

        // rtl6 behaviour when no correction overrides the word/lane update.
        if(de && have && idx==3'd7) begin
            if(fifo_dataval) begin
                wbuf_n=fifo_dout; idx_n=0; have_n=1; rd_pend_n=0;
            end else begin idx_n=0; have_n=0; end
        end else if(fifo_dataval) begin
            wbuf_n=fifo_dout; idx_n=0; have_n=1; rd_pend_n=0;
        end else if(de && have) idx_n=idx+3'd1;

        if(!rlen) begin
            phase_debt_n=0; armed_n=0; catchup_n=0;
        end else if(!armed) begin
            phase_debt_n=0; catchup_n=0;
            if(!de) armed_n=1;
        end else begin
            // One authoritative ledger, updated every clock. No line-edge
            // reset can be bypassed by a higher-priority catchup branch.
            if(de && !have)
                debt=(phase_debt==HACTIVE-12'd1) ? 12'd0 : phase_debt+12'd1;

            if(catchup || (de_fall && debt!=0)) begin
                if(!catchup) relock_tgl_n=~relock_tgl;
                if(!catchup && have && debt<room) begin
                    // Strict < : equality must discard the entire old word.
                    idx_n=idx+debt[2:0]; debt=0;
                end else begin
                    // Account for the remaining OLD word before processing a
                    // response arriving on this SAME boundary. Ignoring that
                    // response used to silently discard an extra eight pixels.
                    if(!catchup && have) debt=debt-room;
                    have_n=0; catchup_n=1;
                    if(fifo_dataval) begin
                        rd_pend_n=0;
                        if(debt>=12'd8) debt=debt-12'd8;
                        else begin
                            wbuf_n=fifo_dout; idx_n=debt[2:0];
                            have_n=1; catchup_n=0; debt=0;
                        end
                    end
                end
            end
            phase_debt_n=debt;
        end
    end

    always @(posedge pclk or negedge prst_n) begin
        if(!prst_n) begin
            wbuf<=0; idx<=0; have<=0; rd_pend<=0; underrun<=0;
            ren_s1<=0; ren_s2<=0; armed<=0; de_q<=0;
            phase_debt<=0; catchup<=0; relock_tgl<=0;
        end else begin
            ren_s1<=relock_en; ren_s2<=ren_s1; de_q<=de;
            wbuf<=wbuf_n; idx<=idx_n; have<=have_n; rd_pend<=rd_pend_n;
            phase_debt<=phase_debt_n; armed<=armed_n;
            catchup<=catchup_n; relock_tgl<=relock_tgl_n;
            if(line_start) underrun<=0;
            else if(de && !have) underrun<=1;
        end
    end
endmodule
