// Team A integration component. Production activation requires the complete
// SoC build/timing/scanout checks; this module does not change B's RTL.
module bullet_platform (
    input wire clk,input wire rstn,input wire pclk,input wire prstn,
    input wire [15:0] paddr,input wire psel,input wire penable,input wire pwrite,
    input wire [31:0] pwdata,output wire apb_sel,output wire [31:0] prdata,
    output wire pready,output wire pslverr,
    input wire [31:0] debug_legacy_pixel,input wire [31:0] debug_legacy_core,
    input wire [511:0] debug_bus,input wire [31:0] debug_outer,input wire [15:0] debug_arbiters,
    input wire [15:0] h_cnt,input wire [15:0] v_cnt,input wire de,
    output wire [2:0] display_qos,
    input wire [127:0] debug_admission,
    output wire [15:0] pix,output wire have,output wire mode_active,
    output wire [7:0] m_axi_arid,output wire [31:0] m_axi_araddr,
    output wire [7:0] m_axi_arlen,output wire [2:0] m_axi_arsize,
    output wire [1:0] m_axi_arburst,output wire [1:0] m_axi_arlock,
    output wire m_axi_arvalid,input wire m_axi_arready,
    input wire [127:0] m_axi_rdata,input wire m_axi_rlast,
    input wire [1:0] m_axi_rresp,input wire m_axi_rvalid,output wire m_axi_rready
);
    wire regs_sel,diag_sel;wire [31:0] regs_data,diag_data;
    wire regs_error,diag_error;wire [31:0] debug_gray,debug_copy;
    wire line_toggle;wire [31:0] line_context;
    wire debug_missing;wire [255:0] debug_pixel;
    assign apb_sel=regs_sel|diag_sel;
    assign prdata=diag_sel?diag_data:regs_data;
    assign pslverr=diag_sel?diag_error:regs_error;
    assign pready=1;
    wire mode_req,repeat_mode,start_atlas,start_frame,clear_stats;
    wire [31:0] atlas_base,desc_base,desc_count,bg_base;
    wire [15:0] color_key;wire alpha_en;wire [5:0] alpha_val;
    wire atlas_busy,atlas_done,atlas_error,frame_busy,frame_done,frame_error;
    wire [31:0] max_line_cycles;wire [15:0] line_num;wire line_bank,line_done,line_ack;
    wire [10:0] disp_rd_idx;wire disp_rd_bank;wire [15:0] disp_rd_data;
    wire video_mode_active,frame_tick,copy_busy;wire [7:0] video_epoch,render_epoch;
    wire [3:0] queued_lines;wire [31:0] missing_pixels,missing_lines,displayed_frames;
    wire armed,atlas_ready;
    reg low_water,legacy_low_water;
    // The bottom240 rows and fallback still depend on legacy FIFO service,
    // even after the480-row B renderer is idle. Keep a two/four-line reserve.
    always @(posedge clk or negedge rstn)begin
        if(!rstn)legacy_low_water<=1;
        else if(debug_legacy_core[11:0]<=320)legacy_low_water<=1;
        else if(debug_legacy_core[11:0]>=640)legacy_low_water<=0;
    end
    wire protect_display=mode_req || video_mode_active;
    always @(posedge clk or negedge rstn)begin
        if(!rstn)low_water<=0;
        else if(!protect_display || !frame_busy)low_water<=0;
        else if(queued_lines<=4)low_water<=1;
        else if(queued_lines>=6)low_water<=0;
    end
    wire urgent_read=legacy_low_water || (protect_display && low_water);
    assign display_qos={urgent_read,urgent_read || (protect_display && m_axi_arvalid),protect_display || legacy_low_water};
    reg render_valid;
    wire scanout_reset_n=rstn && prstn;
    // Pixel reset must not cancel B's outstanding AXI burst. Old rows are
    // drained without publication until a fresh frame has actually started.
    always @(posedge clk or negedge scanout_reset_n) begin
        if(!scanout_reset_n)render_valid<=0;
        else if(start_frame)render_valid<=1;
    end
    assign m_axi_arid=8'd0;
    assign m_axi_arlock=2'd0;
    bullet_apb_regs regs (
        .clk(clk),.rstn(rstn),.paddr(paddr),.psel(psel),.penable(penable),
        .pwrite(pwrite),.pwdata(pwdata),.sel(regs_sel),.prdata(regs_data),
        .pready(),.pslverr(regs_error),.mode_req(mode_req),.repeat_mode(repeat_mode),
        .atlas_base(atlas_base),.desc_base(desc_base),.desc_count(desc_count),
        .bg_base(bg_base),.color_key(color_key),.alpha_en(alpha_en),.alpha_val(alpha_val),
        .start_atlas(start_atlas),.start_frame(start_frame),.clear_stats(clear_stats),
        .render_epoch(render_epoch),.atlas_busy(atlas_busy),.atlas_done(atlas_done),
        .atlas_error(atlas_error),.frame_busy(frame_busy),.frame_done(frame_done),
        .frame_error(frame_error),.max_line_cycles(max_line_cycles),
        .video_mode_active(video_mode_active),.frame_tick(frame_tick),.video_epoch(video_epoch),
        .copy_busy(copy_busy),.queued_lines(queued_lines),.missing_pixels(missing_pixels),
        .missing_lines(missing_lines),.displayed_frames(displayed_frames),
        .armed(armed),.atlas_ready(atlas_ready));
    wire [15:0] max_line_num;
    wire [31:0] max_bg_ar_cycles;
    wire [31:0] max_bg_r_cycles;
    wire [31:0] max_compute_cycles;
    wire [31:0] last_publish_wait;
    wire [31:0] max_publish_wait;
    wire [15:0] max_publish_wait_line;
    wire [31:0] last_ack_wait;
    wire [31:0] max_ack_wait;
    wire [15:0] max_ack_wait_line;
    wire stat_is_row0;
    wire [4:0] dbg_render_state;
    wire [2:0] dbg_loader_state;
    wire [2:0] dbg_frame_state;
    wire [15:0] dbg_render_line;
    wire dbg_ready_valid;
    wire dbg_second_valid;
    wire [15:0] dbg_ready_line;
    wire [15:0] dbg_second_line;
    wire [31:0] dbg_cur_total;
    wire [31:0] dbg_cur_bg_ar;
    wire [31:0] dbg_cur_bg_r;
    wire [31:0] dbg_cur_compute;
    wire [31:0] dbg_bg_ar_addr;
    wire [31:0] max_line_cycles_row0;
    wire [31:0] max_line_cycles_active;
    wire [31:0] max_bg_ar_cycles_row0;
    wire [31:0] max_bg_ar_cycles_active;
    wire [31:0] max_bg_r_cycles_row0;
    wire [31:0] max_bg_r_cycles_active;
    wire [31:0] max_compute_cycles_row0;
    wire [31:0] max_compute_cycles_active;
    wire [15:0] max_bg_ar_line;
    wire [15:0] max_bg_r_line;
    wire [15:0] max_compute_line;
    wire [15:0] max_line_num_row0;
    wire [15:0] max_line_num_active;
    wire [8:0] dbg_ar_left;wire [1:0] dbg_outstanding;
    wire [8:0] dbg_bg_left;
    wire [8:0] dbg_burst_beats;
    wire [7:0] dbg_bg_wr_beat;
    wire [7:0] dbg_bg_arlen;
    wire [0:0] dbg_bg_arvalid;
    wire [0:0] dbg_bg_arready;
    wire [0:0] dbg_bg_rvalid;
    bullet_engine engine (
        .dbg_ar_left(dbg_ar_left),.dbg_outstanding(dbg_outstanding),
        .dbg_cur_total(dbg_cur_total),
        .dbg_cur_bg_ar(dbg_cur_bg_ar),
        .dbg_cur_bg_r(dbg_cur_bg_r),
        .dbg_cur_compute(dbg_cur_compute),
        .dbg_bg_ar_addr(dbg_bg_ar_addr),
        .max_line_cycles_row0(max_line_cycles_row0),
        .max_line_cycles_active(max_line_cycles_active),
        .max_bg_ar_cycles_row0(max_bg_ar_cycles_row0),
        .max_bg_ar_cycles_active(max_bg_ar_cycles_active),
        .max_bg_r_cycles_row0(max_bg_r_cycles_row0),
        .max_bg_r_cycles_active(max_bg_r_cycles_active),
        .max_compute_cycles_row0(max_compute_cycles_row0),
        .max_compute_cycles_active(max_compute_cycles_active),
        .max_bg_ar_line(max_bg_ar_line),
        .max_bg_r_line(max_bg_r_line),
        .max_compute_line(max_compute_line),
        .max_line_num_row0(max_line_num_row0),
        .max_line_num_active(max_line_num_active),
        .dbg_bg_left(dbg_bg_left),
        .dbg_burst_beats(dbg_burst_beats),
        .dbg_bg_wr_beat(dbg_bg_wr_beat),
        .dbg_bg_arlen(dbg_bg_arlen),
        .dbg_bg_arvalid(dbg_bg_arvalid),
        .dbg_bg_arready(dbg_bg_arready),
        .dbg_bg_rvalid(dbg_bg_rvalid),

        .max_line_num(max_line_num),
        .max_bg_ar_cycles(max_bg_ar_cycles),
        .max_bg_r_cycles(max_bg_r_cycles),
        .max_compute_cycles(max_compute_cycles),
        .last_publish_wait(last_publish_wait),
        .max_publish_wait(max_publish_wait),
        .max_publish_wait_line(max_publish_wait_line),
        .last_ack_wait(last_ack_wait),
        .max_ack_wait(max_ack_wait),
        .max_ack_wait_line(max_ack_wait_line),
        .stat_is_row0(stat_is_row0),
        .dbg_render_state(dbg_render_state),
        .dbg_loader_state(dbg_loader_state),
        .dbg_frame_state(dbg_frame_state),
        .dbg_render_line(dbg_render_line),
        .dbg_ready_valid(dbg_ready_valid),
        .dbg_second_valid(dbg_second_valid),
        .dbg_ready_line(dbg_ready_line),
        .dbg_second_line(dbg_second_line),

        .clk(clk),.rstn(rstn),.start_atlas(start_atlas),.atlas_base(atlas_base),
        .atlas_busy(atlas_busy),.atlas_done(atlas_done),.atlas_error(atlas_error),
        .start_frame(start_frame),.desc_base(desc_base),.desc_count(desc_count[15:0]),
        .bg_base(bg_base),.color_key(color_key),.alpha_en(alpha_en),.alpha_val(alpha_val),
        .frame_busy(frame_busy),.frame_done(frame_done),.frame_error(frame_error),
        .line_num(line_num),.line_bank(line_bank),.line_done(line_done),.line_ack(line_ack),
        .max_line_cycles(max_line_cycles),.m_axi_araddr(m_axi_araddr),.m_axi_arlen(m_axi_arlen),
        .m_axi_arsize(m_axi_arsize),.m_axi_arburst(m_axi_arburst),.m_axi_arvalid(m_axi_arvalid),
        .m_axi_arready(m_axi_arready),.m_axi_rdata(m_axi_rdata),.m_axi_rlast(m_axi_rlast),
        .m_axi_rresp(m_axi_rresp),.m_axi_rvalid(m_axi_rvalid),.m_axi_rready(m_axi_rready),
        .disp_rd_idx(disp_rd_idx),.disp_rd_bank(disp_rd_bank),.disp_rd_data(disp_rd_data));
    // A-side handshake age, supplementary to B's native diagnostics.
    reg [31:0] last_ar,ar_wait,r_gap,frame_serial;reg [8:0] pending_beats;
    function [31:0] sat_inc(input [31:0] x);sat_inc=(&x)?x:x+1'b1;endfunction
    always @(posedge clk or negedge rstn)begin
        if(!rstn)begin last_ar<=0;ar_wait<=0;r_gap<=0;pending_beats<=0;frame_serial<=0;end
        else begin
            if(start_frame)frame_serial<=frame_serial+1'b1;
            if(m_axi_arvalid && !m_axi_arready)ar_wait<=sat_inc(ar_wait);else ar_wait<=0;
            if(pending_beats!=0 && !(m_axi_rvalid && m_axi_rready))r_gap<=sat_inc(r_gap);else r_gap<=0;
            if(m_axi_arvalid && m_axi_arready)begin
                last_ar<=m_axi_araddr;pending_beats<={1'b0,m_axi_arlen}+9'd1;
            end else if(m_axi_rvalid && m_axi_rready && pending_beats!=0)pending_beats<=pending_beats-1'b1;
        end
    end
    wire [511:0] b_context={32'd0,32'd0,
        {dbg_second_line,dbg_ready_line},{16'd0,dbg_render_line},
        {18'd0,stat_is_row0,dbg_second_valid,dbg_ready_valid,dbg_frame_state,dbg_loader_state,dbg_render_state},
        {16'd0,max_ack_wait_line},max_ack_wait,last_ack_wait,
        {16'd0,max_publish_wait_line},max_publish_wait,last_publish_wait,
        max_compute_cycles,max_bg_r_cycles,max_bg_ar_cycles,{16'd0,max_line_num},max_line_cycles};
    wire [1023:0] core_context={b_context,
        frame_serial,bg_base,desc_count,last_ar,
        max_line_cycles,r_gap,ar_wait,
        {23'd0,pending_beats},
        debug_outer,{16'd0,debug_arbiters},debug_legacy_core,debug_copy,
        {8'd0,render_epoch,line_num},
        {16'd0,queued_lines,render_valid,copy_busy,line_ack,line_done,frame_error,frame_done,
            frame_busy,atlas_busy,start_frame,mode_req,repeat_mode,armed},
        {19'd0,m_axi_arlen,m_axi_rready,m_axi_rvalid,m_axi_rlast,m_axi_arready,m_axi_arvalid},32'd0};
    (* async_reg="true" *) reg lt1,lt2,lt3;
    reg lt_seen;reg [31:0] lc1,lc2;
    always @(posedge clk or negedge rstn)begin
        if(!rstn)begin lt1<=0;lt2<=0;lt3<=0;lt_seen<=0;lc1<=0;lc2<=0;end
        else begin lt1<=line_toggle;lt2<=lt1;lt3<=lt2;lt_seen<=lt3;lc1<=line_context;lc2<=lc1;end
    end
    wire [223:0] history_context={
        {queued_lines,debug_legacy_core[11:0],debug_arbiters},m_axi_araddr,debug_bus[31:0],ar_wait,
        debug_copy,{3'd0,line_ack,line_done,copy_busy,dbg_second_valid,dbg_ready_valid,dbg_frame_state,dbg_render_state,dbg_render_line},lc2};
    wire [1023:0] current_B_context={
        32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,32'd0,
        debug_admission,
        {21'd0,dbg_outstanding,dbg_ar_left},
        max_compute_cycles_active,
        max_bg_r_cycles_active,
        max_bg_ar_cycles_active,
        max_line_cycles_active,
        max_compute_cycles_row0,
        max_bg_r_cycles_row0,
        max_bg_ar_cycles_row0,
        max_line_cycles_row0,
        {16'd0,max_line_num_active},
        {max_line_num_row0,max_compute_line},
        {max_bg_r_line,max_bg_ar_line},
        {dbg_render_line,dbg_render_state,dbg_bg_rvalid,dbg_bg_arready,dbg_bg_arvalid,dbg_bg_arlen},
        dbg_bg_ar_addr,
        {6'd0,dbg_burst_beats,dbg_bg_wr_beat,dbg_bg_left},
        dbg_cur_compute,
        dbg_cur_bg_r,
        dbg_cur_bg_ar,
        dbg_cur_total};
    bullet_first_missing first_missing(
        .clk(clk),.rstn(rstn),.pclk(pclk),.missing(debug_missing),.pixel_context(debug_pixel),
        .current_B_context(current_B_context),.outer_context(debug_bus),.history_tick(lt3!=lt_seen),.history_context(history_context),
        .core_context(core_context),.paddr(paddr),.psel(psel),.penable(penable),.pwrite(pwrite),
        .pwdata(pwdata),.sel(diag_sel),.prdata(diag_data),.pslverr(diag_error),.core_clock_gray(debug_gray));
    bullet_scanout scanout (
        .debug_core_gray(debug_gray),.debug_legacy_pixel(debug_legacy_pixel),
        .debug_line_toggle(line_toggle),.debug_line_context(line_context),
        .debug_missing(debug_missing),.debug_pixel(debug_pixel),.debug_copy(debug_copy),
        .clk(clk),.rstn(rstn),.pclk(pclk),.prstn(prstn),.mode_req(mode_req),
        .clear_stats(clear_stats),.render_epoch(render_epoch),.render_valid(render_valid),
        .line_done(line_done),.line_num(line_num),.line_bank(line_bank),
        .disp_rd_idx(disp_rd_idx),.disp_rd_bank(disp_rd_bank),.disp_rd_data(disp_rd_data),
        .line_ack(line_ack),.h_cnt(h_cnt),.v_cnt(v_cnt),.de(de),.pix(pix),.have(have),
        .mode_active_pixel(mode_active),.mode_active_core(video_mode_active),
        .frame_tick(frame_tick),.frame_epoch(video_epoch),.copy_busy(copy_busy),
        .queued_lines(queued_lines),.missing_pixels(missing_pixels),
        .missing_lines(missing_lines),.displayed_frames(displayed_frames));
endmodule
