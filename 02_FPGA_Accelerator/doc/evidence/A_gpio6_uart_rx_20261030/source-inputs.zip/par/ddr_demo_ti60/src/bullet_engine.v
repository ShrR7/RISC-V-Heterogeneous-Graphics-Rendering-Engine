//============================================================================
// File        : bullet_engine.v
// Description : Stage 9 top-level bullet engine: atlas loader + descriptor
//               loader + 480-line scanline renderer, with a single shared
//               AXI read master and a display-side line-buffer read port.
// Team        : Team B (RTL Accelerator)
//
// Flow:
//   start_atlas (only while completely idle): load 32 sprites (16 KB) from
//   DDR into the on-chip atlas.  This is normally done once at init.
//   start_frame: load/bucket descriptors, then render lines 0..479 into
//   alternating line buffers.  `line_done` marks each prepared line;
//   `line_num` and `line_bank` identify the buffer for the display side.
//
// Atlas and frame starts are mutually exclusive; a start while busy is
// rejected with done+error.  All AXI read bursts are <=16 beats, never cross
// 4 KB, and RREADY stays high throughout each burst.
//============================================================================

module bullet_engine (
    input  wire         clk,
    input  wire         rstn,

    input  wire         start_atlas,
    input  wire [31:0]  atlas_base,
    output reg          atlas_busy,
    output reg          atlas_done,
    output reg          atlas_error,

    input  wire         start_frame,
    input  wire [31:0]  desc_base,
    input  wire [15:0]  desc_count,
    input  wire [31:0]  bg_base,
    input  wire [15:0]  color_key,
    input  wire         alpha_en,
    input  wire [5:0]   alpha_val,
    output reg          frame_busy,
    output reg          frame_done,
    output reg          frame_error,

    output wire [15:0]  line_num,
    output wire         line_bank,
    output wire         line_done,
    input  wire         line_ack,          // display consumed the prepared line
    output reg  [31:0]  max_line_cycles,
    output reg  [15:0]  max_line_num,
    output reg  [31:0]  max_bg_ar_cycles,
    output reg  [31:0]  max_bg_r_cycles,
    output reg  [31:0]  max_compute_cycles,
    output reg  [15:0]  max_bg_ar_line,
    output reg  [15:0]  max_bg_r_line,
    output reg  [15:0]  max_compute_line,
    output reg  [31:0]  max_line_cycles_row0,
    output reg  [31:0]  max_line_cycles_active,
    output reg  [15:0]  max_line_num_row0,
    output reg  [15:0]  max_line_num_active,
    output reg  [31:0]  max_bg_ar_cycles_row0,
    output reg  [31:0]  max_bg_ar_cycles_active,
    output reg  [31:0]  max_bg_r_cycles_row0,
    output reg  [31:0]  max_bg_r_cycles_active,
    output reg  [31:0]  max_compute_cycles_row0,
    output reg  [31:0]  max_compute_cycles_active,
    output reg  [31:0]  last_publish_wait,
    output reg  [31:0]  max_publish_wait,
    output reg  [15:0]  max_publish_wait_line,
    output reg  [31:0]  last_ack_wait,
    output reg  [31:0]  max_ack_wait,
    output reg  [15:0]  max_ack_wait_line,
    output reg          stat_is_row0,
    output wire [4:0]   dbg_render_state,
    output wire [2:0]   dbg_loader_state,
    output wire [2:0]   dbg_frame_state,
    output wire [15:0]  dbg_render_line,
    output wire         dbg_ready_valid,
    output wire         dbg_second_valid,
    output wire [15:0]  dbg_ready_line,
    output wire [15:0]  dbg_second_line,
    output wire [31:0]  dbg_cur_total,
    output wire [31:0]  dbg_cur_bg_ar,
    output wire [31:0]  dbg_cur_bg_r,
    output wire [31:0]  dbg_cur_compute,
    output wire [8:0]   dbg_bg_left,
    output wire [7:0]   dbg_bg_wr_beat,
    output wire [8:0]   dbg_burst_beats,
    output wire [31:0]  dbg_bg_ar_addr,
    output wire [7:0]   dbg_bg_arlen,
    output wire         dbg_bg_arvalid,
    output wire         dbg_bg_arready,
    output wire         dbg_bg_rvalid,
    output wire [8:0]   dbg_ar_left,
    output wire [1:0]   dbg_outstanding,

    // shared AXI read master
    output wire [31:0]  m_axi_araddr,
    output wire [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output wire         m_axi_arvalid,
    input  wire         m_axi_arready,
    input  wire [127:0] m_axi_rdata,
    input  wire         m_axi_rlast,
    input  wire [1:0]   m_axi_rresp,
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready,

    // display-side synchronous line-buffer read port
    input  wire [10:0]  disp_rd_idx,
    input  wire         disp_rd_bank,
    output wire [15:0]  disp_rd_data
);

    localparam integer ATLAS_BEATS = 1024;   // 32 sprites x 32 beats

    // ---------------------------------------------------------------- atlas
    localparam [1:0] A_IDLE = 2'd0, A_AR = 2'd1, A_R = 2'd2;
    reg [1:0]  a_state;
    reg [31:0] a_ar_addr;
    reg [10:0] a_left;
    reg [9:0]  a_wr_beat;
    reg [8:0]  a_burst;
    reg [31:0] a_araddr_r;
    reg [7:0]  a_arlen_r;
    reg        a_arvalid_r;
    reg        a_stop;
    reg [23:0] a_stall;

    wire [12:0] a_bytes_to_4k = 13'h1000 - {1'b0, a_ar_addr[11:0]};
    wire [8:0]  a_beats_to_4k = {1'b0, a_bytes_to_4k[12:4]};
    wire [8:0]  a_burst_calc  = (a_left > 11'd16) ? 9'd16 : a_left[8:0];
    wire [8:0]  a_burst_next  = (a_burst_calc > a_beats_to_4k) ?
                                a_beats_to_4k : a_burst_calc;
    wire        a_rready = (a_state == A_R);
    wire        a_progress = (a_arvalid_r && m_axi_arready) ||
                             (m_axi_rvalid && m_axi_rready && (a_state == A_R));

    // ---------------------------------------------------------------- frame
    localparam [2:0] F_IDLE = 3'd0, F_DESC = 3'd1,
                     F_LINE_START = 3'd2, F_LINE_WAIT = 3'd3,
                     F_FULL = 3'd4, F_DRAIN = 3'd5;
    reg [2:0]  f_state;
    reg        l_start;
    reg        r_start;
    reg [15:0] line_r;
    reg [31:0] bg_line_addr;
    // Two-entry ready queue: the display consumes ready_line while the
    // renderer prepares the next bank.  Only two full banks stop rendering.
    reg        ready_valid, second_valid;
    reg [15:0] ready_line, second_line;

    // 32-bit saturating publish/ack instrumentation.  Publish wait measures
    // r_done -> the line becoming visible as ready_line; ack wait measures
    // ready_line visible -> line_ack.  They separate "not generated" from
    // "generated but not delivered".
    reg        pub_active, ack_active;
    reg [15:0] pub_line, ack_line;
    reg [31:0] pub_cnt, ack_cnt;

    function [31:0] sat32(input [31:0] v);
        begin
            sat32 = (v == 32'hFFFF_FFFF) ? v : (v + 1'b1);
        end
    endfunction

    assign line_num  = ready_line;
    assign line_bank = ready_line[0];
    assign line_done = ready_valid;
    assign dbg_render_line = line_r;
    assign dbg_ready_valid = ready_valid;
    assign dbg_second_valid = second_valid;
    assign dbg_ready_line = ready_line;
    assign dbg_second_line = second_line;
    assign dbg_frame_state = f_state;

    wire        l_busy, l_done, l_error;
    wire [31:0] l_araddr;
    wire [7:0]  l_arlen;
    wire        l_arvalid, l_rready;

    wire        r_busy, r_done, r_error;
    wire [31:0] r_araddr;
    wire [7:0]  r_arlen;
    wire        r_arvalid, r_rready;
    wire [31:0] stat_cycles;
    wire [31:0] stat_bg_ar_cycles, stat_bg_r_cycles, stat_compute_cycles;
    wire [11:0] stat_sprites, stat_entries;

    wire [10:0] desc_rd_idx;
    wire [127:0] desc_rd_data;
    wire [4:0] band_rd_idx;
    wire [11:0] band_rd_base, band_rd_count;
    wire [11:0] band_mem_rd_addr;
    wire [10:0] band_mem_rd_id;

    bullet_desc_loader u_loader (
        .clk(clk), .rstn(rstn), .start(l_start),
        .busy(l_busy), .done(l_done), .error(l_error),
        .desc_base(desc_base), .desc_count(desc_count),
        .m_axi_araddr(l_araddr), .m_axi_arlen(l_arlen),
        .m_axi_arsize(), .m_axi_arburst(),
        .m_axi_arvalid(l_arvalid), .m_axi_arready(m_axi_arready),
        .m_axi_rdata(m_axi_rdata), .m_axi_rlast(m_axi_rlast),
        .m_axi_rresp(m_axi_rresp), .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(l_rready),
        .desc_rd_idx(desc_rd_idx), .desc_rd_data(desc_rd_data),
        .band_rd_idx(band_rd_idx), .band_rd_base(band_rd_base),
        .band_rd_count(band_rd_count),
        .band_mem_rd_addr(band_mem_rd_addr), .band_mem_rd_id(band_mem_rd_id),
        .dbg_state(dbg_loader_state)
    );

    wire atlas_we = (a_state == A_R) && m_axi_rvalid && m_axi_rready;
    wire [9:0] atlas_waddr = a_wr_beat;
    wire [127:0] atlas_wdata = m_axi_rdata;

    bullet_line_render u_render (
        .clk(clk), .rstn(rstn), .start_line(r_start),
        .line_num(line_r), .bg_line_addr(bg_line_addr), .bank(line_r[0]),
        .busy(r_busy), .done(r_done), .error(r_error),
        .color_key(color_key), .alpha_en(alpha_en), .alpha_val(alpha_val),
        .m_axi_araddr(r_araddr), .m_axi_arlen(r_arlen),
        .m_axi_arsize(), .m_axi_arburst(),
        .m_axi_arvalid(r_arvalid), .m_axi_arready(m_axi_arready),
        .m_axi_rdata(m_axi_rdata), .m_axi_rlast(m_axi_rlast),
        .m_axi_rresp(m_axi_rresp), .m_axi_rvalid(m_axi_rvalid),
        .m_axi_rready(r_rready),
        .desc_rd_idx(desc_rd_idx), .desc_rd_data(desc_rd_data),
        .band_rd_idx(band_rd_idx), .band_rd_base(band_rd_base),
        .band_rd_count(band_rd_count),
        .band_mem_rd_addr(band_mem_rd_addr), .band_mem_rd_id(band_mem_rd_id),
        .atlas_we(atlas_we), .atlas_waddr(atlas_waddr),
        .atlas_wdata(atlas_wdata),
        .disp_rd_idx(disp_rd_idx), .disp_rd_bank(disp_rd_bank),
        .disp_rd_data(disp_rd_data),
        .stat_cycles(stat_cycles),
        .stat_bg_ar_cycles(stat_bg_ar_cycles),
        .stat_bg_r_cycles(stat_bg_r_cycles),
        .stat_compute_cycles(stat_compute_cycles),
        .stat_sprites(stat_sprites), .stat_entries(stat_entries),
        .dbg_state(dbg_render_state),
        .dbg_cur_total(dbg_cur_total),
        .dbg_cur_bg_ar(dbg_cur_bg_ar),
        .dbg_cur_bg_r(dbg_cur_bg_r),
        .dbg_cur_compute(dbg_cur_compute),
        .dbg_bg_left(dbg_bg_left),
        .dbg_bg_wr_beat(dbg_bg_wr_beat),
        .dbg_burst_beats(dbg_burst_beats),
        .dbg_bg_ar_addr(dbg_bg_ar_addr),
        .dbg_bg_arlen(dbg_bg_arlen),
        .dbg_bg_arvalid(dbg_bg_arvalid),
        .dbg_bg_arready(dbg_bg_arready),
        .dbg_bg_rvalid(dbg_bg_rvalid),
        .dbg_ar_left(dbg_ar_left),
        .dbg_outstanding(dbg_outstanding)
    );

    // Read-channel owner: atlas load, descriptor load, or line render.
    // They are mutually exclusive by the frame/atlas start rules.
    assign m_axi_araddr = (a_state != A_IDLE) ? a_araddr_r :
                          (f_state == F_DESC) ? l_araddr : r_araddr;
    assign m_axi_arlen  = (a_state != A_IDLE) ? a_arlen_r :
                          (f_state == F_DESC) ? l_arlen : r_arlen;
    assign m_axi_arvalid = (a_state != A_IDLE) ? a_arvalid_r :
                           (f_state == F_DESC) ? l_arvalid : r_arvalid;
    assign m_axi_rready = (a_state != A_IDLE) ? a_rready :
                          (f_state == F_DESC) ? l_rready : r_rready;
    assign m_axi_arsize  = 3'b100;
    assign m_axi_arburst = 2'b01;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            a_state         <= A_IDLE;
            atlas_busy      <= 1'b0;
            atlas_done      <= 1'b0;
            atlas_error     <= 1'b0;
            a_ar_addr       <= 32'd0;
            a_left          <= 11'd0;
            a_wr_beat       <= 10'd0;
            a_burst         <= 9'd0;
            a_araddr_r      <= 32'd0;
            a_arlen_r       <= 8'd0;
            a_arvalid_r     <= 1'b0;
            a_stop          <= 1'b0;
            a_stall         <= 24'd0;

            f_state         <= F_IDLE;
            frame_busy      <= 1'b0;
            frame_done      <= 1'b0;
            frame_error     <= 1'b0;
            l_start         <= 1'b0;
            r_start         <= 1'b0;
            line_r          <= 16'd0;
            bg_line_addr    <= 32'd0;
            ready_valid     <= 1'b0;
            second_valid    <= 1'b0;
            ready_line      <= 16'd0;
            second_line     <= 16'd0;
            max_line_cycles <= 32'd0;
            max_line_num    <= 16'd0;
            max_bg_ar_cycles<= 32'd0;
            max_bg_r_cycles <= 32'd0;
            max_compute_cycles<=32'd0;
            max_bg_ar_line  <= 16'd0;
            max_bg_r_line   <= 16'd0;
            max_compute_line<= 16'd0;
            max_line_cycles_row0<=32'd0;
            max_line_cycles_active<=32'd0;
            max_line_num_row0<=16'd0;
            max_line_num_active<=16'd0;
            max_bg_ar_cycles_row0<=32'd0;
            max_bg_ar_cycles_active<=32'd0;
            max_bg_r_cycles_row0<=32'd0;
            max_bg_r_cycles_active<=32'd0;
            max_compute_cycles_row0<=32'd0;
            max_compute_cycles_active<=32'd0;
            last_publish_wait<=32'd0;
            max_publish_wait<=32'd0;
            max_publish_wait_line<=16'd0;
            last_ack_wait   <= 32'd0;
            max_ack_wait    <= 32'd0;
            max_ack_wait_line<=16'd0;
            stat_is_row0    <= 1'b0;
            pub_active      <= 1'b0;
            ack_active      <= 1'b0;
            pub_line        <= 16'd0;
            ack_line        <= 16'd0;
            pub_cnt         <= 32'd0;
            ack_cnt         <= 32'd0;
        end else begin
            l_start <= 1'b0;
            r_start <= 1'b0;

            // ------------------------------ atlas loader -------------------
            if (a_state == A_IDLE)
                a_stall <= 24'd0;
            else if (a_progress)
                a_stall <= 24'd0;
            else if (a_stall != 24'hFFFFFF)
                a_stall <= a_stall + 1'b1;

            if ((a_state != A_IDLE) && (a_stall >= 24'd200000)) begin
                a_state      <= A_IDLE;
                atlas_busy   <= 1'b0;
                atlas_done   <= 1'b1;
                atlas_error  <= 1'b1;
                a_arvalid_r  <= 1'b0;
                a_stall      <= 24'd0;
            end else begin
                case (a_state)
                    A_IDLE: begin
                        atlas_busy <= 1'b0;
                        if (start_atlas) begin
                            if (f_state != F_IDLE) begin
                                atlas_done  <= 1'b1;
                                atlas_error <= 1'b1;
                            end else if (|atlas_base[3:0]) begin
                                atlas_done  <= 1'b1;
                                atlas_error <= 1'b1;
                            end else begin
                                atlas_done  <= 1'b0;
                                atlas_error <= 1'b0;
                                atlas_busy  <= 1'b1;
                                a_ar_addr   <= atlas_base;
                                a_left      <= ATLAS_BEATS;
                                a_wr_beat   <= 10'd0;
                                a_stop      <= 1'b0;
                                a_state     <= A_AR;
                            end
                        end
                    end

                    A_AR: begin
                        if (!a_arvalid_r) begin
                            a_araddr_r  <= a_ar_addr;
                            a_arlen_r   <= a_burst_next[7:0] - 8'd1;
                            a_burst     <= a_burst_next;
                            a_arvalid_r <= 1'b1;
                        end else if (m_axi_arready) begin
                            a_arvalid_r <= 1'b0;
                            a_state     <= A_R;
                        end
                    end

                    A_R: begin
                        if (m_axi_rvalid && m_axi_rready) begin
                            a_wr_beat <= a_wr_beat + 1'b1;
                            if (m_axi_rresp != 2'b00) begin
                                atlas_error <= 1'b1;
                                a_stop      <= 1'b1;
                            end
                            if (m_axi_rlast) begin
                                if (a_stop || (m_axi_rresp != 2'b00)) begin
                                    a_state    <= A_IDLE;
                                    atlas_busy <= 1'b0;
                                    atlas_done <= 1'b1;
                                end else if (a_left == {2'd0, a_burst}) begin
                                    a_state    <= A_IDLE;
                                    atlas_busy <= 1'b0;
                                    atlas_done <= 1'b1;
                                end else begin
                                    a_ar_addr <= a_ar_addr + {23'd0,a_burst,4'b0};
                                    a_left    <= a_left - {2'd0,a_burst};
                                    a_state   <= A_AR;
                                end
                            end
                        end
                    end

                    default: a_state <= A_IDLE;
                endcase
            end

            // ------------------------------ frame controller ---------------
            // Publish/ack timing is independent of the FSM state encoding.
            if (pub_active) begin
                if (ready_valid && (ready_line == pub_line)) begin
                    last_publish_wait <= pub_cnt;
                    if (pub_cnt > max_publish_wait) begin
                        max_publish_wait      <= pub_cnt;
                        max_publish_wait_line <= pub_line;
                    end
                    pub_active <= 1'b0;
                end else begin
                    pub_cnt <= sat32(pub_cnt);
                end
            end

            if (ack_active) begin
                if (line_ack) begin
                    last_ack_wait <= ack_cnt;
                    if (ack_cnt > max_ack_wait) begin
                        max_ack_wait      <= ack_cnt;
                        max_ack_wait_line <= ack_line;
                    end
                    ack_active <= 1'b0;
                end else begin
                    ack_cnt <= sat32(ack_cnt);
                end
            end
            if (ready_valid && (!ack_active || (ack_line != ready_line))) begin
                ack_active <= 1'b1;
                ack_line   <= ready_line;
                ack_cnt    <= 32'd0;
            end

            // Ack retires the oldest ready line.  If a second line is already
            // complete, it is promoted immediately; rendering may continue.
            if (line_ack) begin
                if (second_valid) begin
                    ready_line   <= second_line;
                    second_valid <= 1'b0;
                    ready_valid  <= 1'b1;
                end else begin
                    ready_valid  <= 1'b0;
                end
            end

            case (f_state)
                F_IDLE: begin
                    frame_busy <= 1'b0;
                    if (start_frame) begin
                        if (a_state != A_IDLE) begin
                            frame_done  <= 1'b1;
                            frame_error <= 1'b1;
                        end else begin
                            frame_done      <= 1'b0;
                            frame_error     <= 1'b0;
                            frame_busy      <= 1'b1;
                            max_line_cycles <= 32'd0;
                            max_line_num    <= 16'd0;
                            max_bg_ar_cycles<= 32'd0;
                            max_bg_r_cycles <= 32'd0;
                            max_compute_cycles<=32'd0;
            max_bg_ar_line  <= 16'd0;
            max_bg_r_line   <= 16'd0;
            max_compute_line<= 16'd0;
            max_line_cycles_row0<=32'd0;
            max_line_cycles_active<=32'd0;
            max_line_num_row0<=16'd0;
            max_line_num_active<=16'd0;
            max_bg_ar_cycles_row0<=32'd0;
            max_bg_ar_cycles_active<=32'd0;
            max_bg_r_cycles_row0<=32'd0;
            max_bg_r_cycles_active<=32'd0;
            max_compute_cycles_row0<=32'd0;
            max_compute_cycles_active<=32'd0;
                            last_publish_wait<=32'd0;
                            max_publish_wait<=32'd0;
                            max_publish_wait_line<=16'd0;
                            last_ack_wait   <= 32'd0;
                            max_ack_wait    <= 32'd0;
                            max_ack_wait_line<=16'd0;
                            pub_active      <= 1'b0;
                            ack_active      <= 1'b0;
                            pub_cnt         <= 32'd0;
                            ack_cnt         <= 32'd0;
                            stat_is_row0    <= 1'b0;
                            line_r          <= 16'd0;
                            bg_line_addr    <= bg_base;
                            ready_valid     <= 1'b0;
                            second_valid    <= 1'b0;
                            l_start         <= 1'b1;
                            f_state         <= F_DESC;
                        end
                    end
                end

                F_DESC: begin
                    if (!l_start && l_done) begin
                        if (l_error) begin
                            frame_busy  <= 1'b0;
                            frame_done  <= 1'b1;
                            frame_error <= 1'b1;
                            f_state     <= F_IDLE;
                        end else begin
                            f_state <= F_LINE_START;
                        end
                    end
                end

                F_LINE_START: begin
                    r_start <= 1'b1;
                    f_state <= F_LINE_WAIT;
                end

                F_LINE_WAIT: begin
                    if (!r_start && r_done) begin
                        stat_is_row0 <= (line_r == 16'd0);
                        pub_active   <= 1'b1;
                        pub_line     <= line_r;
                        pub_cnt      <= 32'd0;
                        if (stat_cycles > max_line_cycles) begin
                            max_line_cycles <= stat_cycles;
                            max_line_num    <= line_r;
                        end
                        if (stat_bg_ar_cycles > max_bg_ar_cycles) begin
                            max_bg_ar_cycles <= stat_bg_ar_cycles;
                            max_bg_ar_line   <= line_r;
                        end
                        if (stat_bg_r_cycles > max_bg_r_cycles) begin
                            max_bg_r_cycles <= stat_bg_r_cycles;
                            max_bg_r_line   <= line_r;
                        end
                        if (stat_compute_cycles > max_compute_cycles) begin
                            max_compute_cycles <= stat_compute_cycles;
                            max_compute_line   <= line_r;
                        end
                        if (line_r == 16'd0) begin
                            if (stat_cycles > max_line_cycles_row0) begin
                                max_line_cycles_row0 <= stat_cycles;
                                max_line_num_row0    <= line_r;
                            end
                            if (stat_bg_ar_cycles > max_bg_ar_cycles_row0)
                                max_bg_ar_cycles_row0 <= stat_bg_ar_cycles;
                            if (stat_bg_r_cycles > max_bg_r_cycles_row0)
                                max_bg_r_cycles_row0 <= stat_bg_r_cycles;
                            if (stat_compute_cycles > max_compute_cycles_row0)
                                max_compute_cycles_row0 <= stat_compute_cycles;
                        end else begin
                            if (stat_cycles > max_line_cycles_active) begin
                                max_line_cycles_active <= stat_cycles;
                                max_line_num_active    <= line_r;
                            end
                            if (stat_bg_ar_cycles > max_bg_ar_cycles_active)
                                max_bg_ar_cycles_active <= stat_bg_ar_cycles;
                            if (stat_bg_r_cycles > max_bg_r_cycles_active)
                                max_bg_r_cycles_active <= stat_bg_r_cycles;
                            if (stat_compute_cycles > max_compute_cycles_active)
                                max_compute_cycles_active <= stat_compute_cycles;
                        end
                        if (r_error) begin
                            frame_busy  <= 1'b0;
                            frame_done  <= 1'b1;
                            frame_error <= 1'b1;
                            f_state     <= F_IDLE;
                        end else if (!ready_valid || line_ack) begin
                            // One bank is (or becomes) free: publish this
                            // line and immediately render the next one.
                            ready_valid  <= 1'b1;
                            ready_line   <= line_r;
                            second_valid <= 1'b0;
                            if (line_r == 16'd479) begin
                                f_state <= F_DRAIN;
                            end else begin
                                line_r       <= line_r + 1'b1;
                                bg_line_addr <= bg_line_addr + 32'd2560;
                                f_state      <= F_LINE_START;
                            end
                        end else begin
                            // Both banks now hold completed, unconsumed
                            // lines.  Stop until the oldest is acked.
                            second_valid <= 1'b1;
                            second_line  <= line_r;
                            f_state      <= F_FULL;
                        end
                    end
                end

                F_FULL: begin
                    if (line_ack) begin
                        if (second_line == 16'd479) begin
                            f_state <= F_DRAIN;
                        end else begin
                            line_r       <= second_line + 1'b1;
                            bg_line_addr <= bg_line_addr + 32'd2560;
                            f_state      <= F_LINE_START;
                        end
                    end
                end

                F_DRAIN: begin
                    // The last line is drained once its ack arrives and no
                    // younger completed line remains queued.
                    if (line_ack && !second_valid && (ready_line == 16'd479)) begin
                        frame_busy  <= 1'b0;
                        frame_done  <= 1'b1;
                        frame_error <= 1'b0;
                        f_state     <= F_IDLE;
                    end
                end

                default: f_state <= F_IDLE;
            endcase
        end
    end

endmodule
