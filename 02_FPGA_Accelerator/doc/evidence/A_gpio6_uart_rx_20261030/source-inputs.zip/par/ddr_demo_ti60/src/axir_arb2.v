//============================================================================
// File        : axir_arb2.v
// Description : 2-to-1 AXI4 READ channel arbiter (Stage 4, A side)
// Team        : Team A (FPGA/SoC/display platform)
//
// Why this exists:
//   Axi_Mux slave port 1 has ONE read channel but Stage 4 needs two readers:
//     m0 = the display line fetcher (gpu_axi_reader -> DC_FIFO -> HDMI)
//     m1 = the Copy engine      (gpu_copy, inside gpu_top / apb3_top)
//   Both readers issue one burst at a time and wait for RLAST before starting
//   the next one, so a two-entry FIFO tracks their accepted bursts. Equal IDs guarantee
//   ordered responses; different IDs are serialized. AR ownership is held
//   across backpressure. IDs do not have to be remapped.
//
// Policy: m0 (display) has priority - it is the latency critical path
//   (it only needs ~106 MB/s of the ~1.6 GB/s DDR3 bandwidth and requests one
//   line per 22 us, so m1 still gets the large majority of the bandwidth).
//
// The write channel is NOT touched here: gpu_fill and gpu_copy share one write
// master inside gpu_top, and the display path is read-only.
//============================================================================

module axir_arb2 #(parameter integer MAX_M0_BURSTS=0) (
    input  wire         clk,
    input  wire         rstn,

    // ---- master 0 : display line fetcher (priority) -----------------------
    input  wire [7:0]   m0_arid,
    input  wire [31:0]  m0_araddr,
    input  wire [7:0]   m0_arlen,
    input  wire [2:0]   m0_arsize,
    input  wire [1:0]   m0_arburst,
    input  wire [1:0]   m0_arlock,
    input  wire         m0_arvalid,
    output wire         m0_arready,
    output wire [7:0]   m0_rid,
    output wire [127:0] m0_rdata,
    output wire         m0_rlast,
    output wire [1:0]   m0_rresp,
    output wire         m0_rvalid,
    input  wire         m0_rready,

    // ---- master 1 : Copy engine -------------------------------------------
    input  wire [7:0]   m1_arid,
    input  wire [31:0]  m1_araddr,
    input  wire [7:0]   m1_arlen,
    input  wire [2:0]   m1_arsize,
    input  wire [1:0]   m1_arburst,
    input  wire [1:0]   m1_arlock,
    input  wire         m1_arvalid,
    output wire         m1_arready,
    output wire [7:0]   m1_rid,
    output wire [127:0] m1_rdata,
    output wire         m1_rlast,
    output wire [1:0]   m1_rresp,
    output wire         m1_rvalid,
    input  wire         m1_rready,

    // ---- slave : Axi_Mux S1 read channel ----------------------------------
    output wire [7:0]   s_arid,
    output wire [31:0]  s_araddr,
    output wire [7:0]   s_arlen,
    output wire [2:0]   s_arsize,
    output wire [1:0]   s_arburst,
    output wire [1:0]   s_arlock,
    output wire         s_arvalid,
    input  wire         s_arready,
    input  wire [7:0]   s_rid,
    input  wire [127:0] s_rdata,
    input  wire         s_rlast,
    input  wire [1:0]   s_rresp,
    input  wire         s_rvalid,
    output wire         s_rready,
    output wire [7:0] debug_state
);

    // Two accepted bursts may overlap when their AXI IDs are identical.
    // AXI guarantees response ordering for a shared ID; different IDs are
    // serialized so an out-of-order slave cannot send to the wrong owner.
    // Production display and GPU both use ID 0. Keeping an owner FIFO lets
    // one wait for DDR while the other presents its next request safely.
    reg owners [0:1];
    reg [7:0] ids [0:1];
    reg head, tail;
    reg [1:0] count;
    reg ar_locked, locked_owner;
    // Optional finite service quota for the lower-priority client. A locked
    // AR always retains owner/payload. Zero preserves the legacy policy.
    reg [7:0] m0_run;
    wire give_m1=(MAX_M0_BURSTS!=0) && m1_arvalid && (m0_run>=MAX_M0_BURSTS);
    wire owner = ar_locked ? locked_owner : (!m0_arvalid || give_m1);
    always @(posedge clk or negedge rstn)begin
        if(!rstn)m0_run<=0;
        else if(!m1_arvalid || (push && owner))m0_run<=0;
        else if(push && !owner && m0_run!=255)m0_run<=m0_run+1'b1;
    end
    wire response_owner = owners[head];
    wire pop = s_rvalid && s_rready && s_rlast;
    wire space = count < 2 || pop;
    wire same_id = count == 0 || (count == 1 && pop) || s_arid == ids[head];
    wire push = s_arvalid && s_arready;
    assign debug_state={2'd0,ar_locked,locked_owner,(count!=0),response_owner,count};

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            head <= 0; tail <= 0; count <= 0;
            ar_locked <= 0; locked_owner <= 0;
        end else begin
            if (s_arvalid && !s_arready) begin
                ar_locked <= 1; locked_owner <= owner;
            end else if (push) ar_locked <= 0;
            if (push) begin
                owners[tail] <= owner; ids[tail] <= s_arid; tail <= !tail;
            end
            if (pop) head <= !head;
            case ({push,pop})
                2'b10: count <= count + 2'd1;
                2'b01: count <= count - 2'd1;
                default: count <= count;
            endcase
        end
    end

    assign s_arid    = owner ? m1_arid    : m0_arid;
    assign s_araddr  = owner ? m1_araddr  : m0_araddr;
    assign s_arlen   = owner ? m1_arlen   : m0_arlen;
    assign s_arsize  = owner ? m1_arsize  : m0_arsize;
    assign s_arburst = owner ? m1_arburst : m0_arburst;
    assign s_arlock  = owner ? m1_arlock  : m0_arlock;
    assign s_arvalid = rstn && space && same_id && (owner ? m1_arvalid : m0_arvalid);
    assign m0_arready = rstn && space && same_id && !owner && s_arready;
    assign m1_arready = rstn && space && same_id &&  owner && s_arready;

    assign m0_rvalid = count != 0 && !response_owner && s_rvalid;
    assign m1_rvalid = count != 0 &&  response_owner && s_rvalid;
    assign m0_rid = s_rid;     assign m1_rid = s_rid;
    assign m0_rdata = s_rdata; assign m1_rdata = s_rdata;
    assign m0_rlast = s_rlast; assign m1_rlast = s_rlast;
    assign m0_rresp = s_rresp; assign m1_rresp = s_rresp;
    assign s_rready = count != 0 && (response_owner ? m1_rready : m0_rready);
endmodule
