`timescale 1ns/1ps
//============================================================================
// platform_gpio.v : 8-bit "platform" GPIO page for the Stage 7 peripherals
//                   (A side; sits next to the GPU in APB Slave 0)
//
//   bit[3:0] : PS2 gamepad  DATA(bidir) / CMD / ATT(select) / CLK
//   bit[5:4] : MPU6050 I2C  SCL / SDA          (software bit-banged)
//   bit[7:6] : spare
//
// Why bit-banging: the board has no general-purpose I2C port. The only I2C
// nets on it are the HDMI *receive* DDC and the MIPI camera "Sensor_SCL/SDA"
// pair (which lands on the camera FFC connector), and no project in the repo
// ever routed the SoC's I2C0 to pins. Both peripherals therefore talk through
// plain GPIOs driven by the RISC-V at 100 kHz (I2C) / 250 kHz (PS2), which is
// trivial at 100 MHz.
//
// APB3 zero-wait slave, register page 0x40..0x4F:
//   0x40 PLAT_GPIO_IN   RO  pin levels
//   0x44 PLAT_GPIO_OUT  RW  output values
//   0x48 PLAT_GPIO_OE   RW  output enables (1 = drive, 0 = input / hi-Z)
//   0x4C PLAT_ID        RO  0x504C4154 = "PLAT"
//
// The page is decoded here in A's wrapper (apb3_top) and the GPU slave is
// masked off for these addresses, so B's gpu_apb_regs.v stays untouched.
//============================================================================

module platform_gpio #(
    parameter [31:0] PLAT_MAGIC = 32'h504C_4154,   // "PLAT"
    parameter        WIDTH      = 8,
    parameter [WIDTH-1:0] INPUT_ONLY_MASK = 0
) (
    input  wire             clk,
    input  wire             reset,          // active high (apb3_top convention)

    // ---- APB3 -------------------------------------------------------------
    input  wire [7:0]       paddr,
    input  wire             psel,
    input  wire             penable,
    input  wire             pwrite,
    input  wire [31:0]      pwdata,
    output reg  [31:0]      prdata,
    output wire             pready,
    output wire             pslverr,
    output wire             sel,            // 1 when this page is addressed

    // ---- pins (three buses, same convention as the SoC's soc_gpio) --------
    input  wire [WIDTH-1:0] pin_in,
    output wire [WIDTH-1:0] pin_out,
    output wire [WIDTH-1:0] pin_oe
);

    localparam [7:0] REG_IN  = 8'h40;
    localparam [7:0] REG_OUT = 8'h44;
    localparam [7:0] REG_OE  = 8'h48;
    localparam [7:0] REG_ID  = 8'h4C;

    assign sel = psel & (paddr[7:4] == 4'h4);      // 0x40 .. 0x4F

    // zero wait state, same as gpu_apb_regs (pready = 1'b1)
    assign pready  = 1'b1;
    assign pslverr = 1'b0;

    wire wr = sel & penable & pwrite;

    reg [WIDTH-1:0] out_reg;
    reg [WIDTH-1:0] oe_reg;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            out_reg <= {WIDTH{1'b0}};
            oe_reg  <= {WIDTH{1'b0}};
        end else if (wr) begin
            case (paddr[7:0])
                REG_OUT: out_reg <= pwdata[WIDTH-1:0];
                REG_OE : oe_reg  <= pwdata[WIDTH-1:0] & ~INPUT_ONLY_MASK;
                default: ;
            endcase
        end
    end

    always @(*) begin
        case (paddr[7:0])
            REG_IN : prdata = {{(32-WIDTH){1'b0}}, pin_in};
            REG_OUT: prdata = {{(32-WIDTH){1'b0}}, out_reg};
            REG_OE : prdata = {{(32-WIDTH){1'b0}}, oe_reg};
            REG_ID : prdata = PLAT_MAGIC;
            default: prdata = 32'd0;
        endcase
    end

    assign pin_out = out_reg;
    assign pin_oe  = oe_reg;

endmodule
