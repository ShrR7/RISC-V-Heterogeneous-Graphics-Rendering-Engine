//============================================================================
// File        : gpu_pkg.vh
// Description : GPU Accelerator global parameters and macros
// Team        : Team B (RTL Accelerator)
// Project     : gpu_accelerator
// Platform    : Efinix Ti60F225 (Titanium)
// Target      : 2026 National College Student Embedded Chip Competition
//               Track 2: RISC-V + FPGA 2D Graphics Rendering Accelerator
//============================================================================
// Revision History:
//   v0.1  - 2026-09-10 : Initial creation, Stage 1 (APB register loopback)
//   v0.2  - 2026-09-18 : Stage 5: add OP_BITBLT; align AXI constants with
//                        the 128-bit implementation
//   v0.3  - 2026-09-19 : Stage 6: add FB_CTRL(0x28) / FB_STATUS(0x2C) for
//                        FB0/FB1 double-buffer display swap
//============================================================================

`ifndef GPU_PKG_VH
`define GPU_PKG_VH

//----------------------------------------------------------------------------
// Pixel format and screen geometry
//----------------------------------------------------------------------------
`define SCREEN_WIDTH   640
`define SCREEN_HEIGHT  480
`define PIXEL_BYTES    2                  // RGB565 = 16 bits = 2 bytes
`define FRAME_SIZE     614400             // 640 * 480 * 2

//----------------------------------------------------------------------------
// AXI4 parameters (matches gpu_top / gpu_axi_master)
//----------------------------------------------------------------------------
`define AXI_DATA_WIDTH  128
`define AXI_ADDR_WIDTH  32
`define AXI_ID_WIDTH    8
`define AXI_STRB_WIDTH  16

//----------------------------------------------------------------------------
// APB register address map (byte offset from GPU base address)
//   Base address in SoC: 0xF810_0000 (APB Slave 0)
//----------------------------------------------------------------------------
`define REG_CTRL        8'h00
`define REG_STATUS      8'h04
`define REG_SRC_ADDR    8'h08
`define REG_DST_ADDR    8'h0C
`define REG_WIDTH       8'h10
`define REG_HEIGHT      8'h14
`define REG_SRC_STRIDE  8'h18
`define REG_DST_STRIDE  8'h1C
`define REG_COLOR       8'h20
`define REG_ID          8'h24
`define REG_FB_CTRL     8'h28            // Stage 6: display buffer swap request
`define REG_FB_STATUS   8'h2C            // Stage 6: display buffer swap status
`define REG_ALPHA       8'h30            // Stage 7: global alpha 0~32 (ALPHA-BLEND)
`define REG_LIST_ADDR   8'h34            // Stage 8: batch list DDR base (16B aligned)
`define REG_LIST_CNT    8'h38            // Stage 8: batch list entry count (0..1024)

`define REG_MAX_ADDR    8'h38            // Highest valid register offset

//----------------------------------------------------------------------------
// CTRL register bit fields
//----------------------------------------------------------------------------
`define CTRL_START_BIT  0
`define CTRL_OP_LO_BIT  1
`define CTRL_OP_HI_BIT  2
`define CTRL_ALPHA_BIT  8               // Stage 7: op=10 modifier, 1=alpha blend
`define CTRL_BATCH_BIT  9               // Stage 8: 1 = batch (list) mode for op=00/10

// Operation encoding (bits[2:1])
`define OP_FILL         2'b00            // Solid Fill
`define OP_COPY         2'b01            // Block Copy
`define OP_BITBLT       2'b10            // BitBlt (Stage 5+; +bit8 = ALPHA-BLEND, Stage 7)
`define OP_RSVD         2'b11            // Reserved

//----------------------------------------------------------------------------
// STATUS register bit fields
//----------------------------------------------------------------------------
`define STAT_BUSY_BIT   0
`define STAT_DONE_BIT   1
`define STAT_ERR_BIT    2

//----------------------------------------------------------------------------
// FB_CTRL / FB_STATUS bit fields (Stage 6 double buffering)
//----------------------------------------------------------------------------
`define FB_CTRL_SEL_BIT    0             // fb_sel_req: 0=show FB0, 1=show FB1
`define FB_STAT_ACTIVE_BIT 0             // fb_sel_active: buffer shown now
`define FB_STAT_PENDING_BIT 1            // swap_pending: req != active

//----------------------------------------------------------------------------
// Magic ID (read-only, ASCII "GPU1")
//----------------------------------------------------------------------------
`define GPU_MAGIC_ID    32'h4750_5531

`endif // GPU_PKG_VH
