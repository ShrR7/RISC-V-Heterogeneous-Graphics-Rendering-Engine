`timescale 1ns/1ps
//============================================================================
// apb3_top : APB Slave 0 wrapper for the GPU accelerator + A-side devices
//
// Stage 2: the GPU's 32-bit AXI4 write master is routed out of this wrapper
//          and connected at the top level to the Axi_Mux S1 port.
//
// Stage 7: platform GPIO page 0x40..0x4F (src/platform_gpio.v).
// Stage 7 display debug: display debug page 0x50..0x7F
//          rtl5: DBG_STATUS2 moved 0x5E -> 0x74 (0x5E is not 4-byte aligned);
//          the line verdict is isolated from APB read-clear; a startup snapshot
//          is latched at the 2nd vs edge and exposed at 0x78/0x7C.  All of the
//          dispdbg_* signals below are still pure OBSERVATION inputs.
//          (src/display_dbg.v, A side, registered in interface_spec.md 3.1).
//          The page is decoded HERE and the GPU slave is masked off for those
//          addresses, so B's gpu_apb_regs.v / gpu_top.v / gpu_pkg.vh stay
//          untouched.
//          display_dbg is PURELY OBSERVATIONAL: every dispdbg_* signal is an
//          INPUT to this wrapper (an observation of the display path) and the
//          block has NO output that reaches a reset, a line request, a frame
//          swap or any FSM.  Nothing in this file gates the display.
//
// APB3 contract (interface_spec.md sec.5): every slave is zero wait state,
//          so PREADY is the AND of the three PREADYs and PSLVERR is the OR of
//          the three PSLVERRs; PRDATA is a 3:1 mux on the winning PSEL.
//          Exactly one slave may see PSEL high for a given address.
//============================================================================

module apb3_top (
    input  [15:0] apb_paddr,
    input  [0:0]  apb_psel,
    input         apb_penable,
    output        apb_pready,
    input         apb_pwrite,
    input  [31:0] apb_pwdata,
    output [31:0] apb_prdata,
    output        apb_pslverror,
    output        sig,
    input         clk,
    input         reset,

    // ---- Stage 6: double-buffer swap handshake to the display path ---------
    //      fb_sel_req  : FB_CTRL[0], driven in this (APB/user_clk) domain
    //      fb_sel_active: buffer the display is scanning out, ALREADY
    //                     synchronized into this domain by the top level
    //                     (gpu_apb_regs compares the two combinationally)
    output        display_fb_sel_req,
    input         display_fb_sel_active,

    // ---- Stage 7: platform GPIO page 0x40..0x4F (PS2 pad + MPU6050 I2C) ----
    //      Three buses, same convention as the SoC's soc_gpio. The pins are
    //      bit-banged by software, so there is no hardware I2C/PS2 logic here.
    input  [7:0]  plat_gpio_IN,
    output [7:0]  plat_gpio_OUT,
    output [7:0]  plat_gpio_OE,

    // ---- Stage 7: display debug page 0x50..0x7F (src/display_dbg.v) --------
    //      EVERY dispdbg_* input below is an OBSERVATION of either the AXI
    //      domain (the reader) or the pixel domain (hdmi_sync / px_serial).
    //      rtl7 amends this: there is now EXACTLY ONE control output,
    //      `dispdbg_relock_en` (px_serial line-phase relock).  It is 0 after
    //      every reset, it is enabled only by an explicit DBG_CTRL bit2 write,
    //      and it can not gate a reset, a line request or a frame swap.
    //      DBG_CTRL[0] still only clears counters and sticky bits that live
    //      inside display_dbg, and DBG_CTRL[1] only re-arms the boot snapshot.
    input  [15:0] dispdbg_pclk_vcnt,
    input         dispdbg_pclk_de,
    input         dispdbg_pclk_have,          // px_serial.have (bug #1 root cause)
    input         dispdbg_pclk_vs,            // hdmi_sync.vs (startup-snapshot base)
    // rtl7: the line-phase relock.  `relock_en` is the ONE functional output of
    //       the debug page: a level that is 0 after every reset, so out of reset
    //       the display path is untouched.  The other two are observation only.
    input         dispdbg_pclk_relock_tgl,    // px_serial: a relock fired
    input         dispdbg_pclk_relock_busy,   // px_serial: catch-up running
    output        dispdbg_relock_en,          // DBG_CTRL bit2, default 0 = OFF
    input         dispdbg_reader_arvalid,
    input         dispdbg_reader_arready,
    input         dispdbg_reader_rvalid,
    input         dispdbg_reader_rready,
    input         dispdbg_reader_busy,
    input         dispdbg_reader_error,
    input         dispdbg_reader_line_req,
    input         dispdbg_reader_line_done,
    input         dispdbg_pclk,               // hdmi_tx_slow_clk (74.375 MHz)
    input         dispdbg_pclk_reset_n,       // hdmi_rst_n (pixel domain)

    // ---- AXI4 write master (gpu_fill / gpu_copy share it) ------------------
    output [31:0] m_axi_awaddr,
    output [7:0]  m_axi_awlen,
    output [2:0]  m_axi_awsize,
    output [1:0]  m_axi_awburst,
    output        m_axi_awvalid,
    input         m_axi_awready,
    output [127:0] m_axi_wdata,
    output [15:0]  m_axi_wstrb,
    output        m_axi_wlast,
    output        m_axi_wvalid,
    input         m_axi_wready,
    input  [1:0]  m_axi_bresp,
    input         m_axi_bvalid,
    output        m_axi_bready,

    // ---- AXI4 read master (Stage 4: gpu_copy reads the source block) -------
    // Top level arbitrates it against the display line fetcher (axir_arb2)
    // and drives Axi_Mux slave port 1's read channel.
    output [7:0]  m_axi_arid,
    output [31:0] m_axi_araddr,
    output [7:0]  m_axi_arlen,
    output [2:0]  m_axi_arsize,
    output [1:0]  m_axi_arburst,
    output [1:0]  m_axi_arlock,
    output        m_axi_arvalid,
    input         m_axi_arready,
    input  [7:0]  m_axi_rid,
    input  [127:0] m_axi_rdata,
    input         m_axi_rlast,
    input  [1:0]  m_axi_rresp,
    input         m_axi_rvalid,
    output        m_axi_rready
);

    wire [31:0] gpu_paddr;

    assign gpu_paddr = {16'd0, apb_paddr};
    assign sig = 1'b0;

    //========================================================================
    // Stage 7 platform page (A side): 0x40..0x4F, see src/platform_gpio.v
    //   The page is decoded here and the GPU slave is masked off for those
    //   addresses, so B's gpu_apb_regs.v / gpu_top.v stay untouched.
    //========================================================================
    wire        plat_sel;
    wire [31:0] plat_prdata;
    wire        plat_pready, plat_pslverr;

    platform_gpio #(.WIDTH(8), .INPUT_ONLY_MASK(8'h40)) u_platform_gpio (
        .clk     (clk),
        .reset   (reset),
        .paddr   (apb_paddr[7:0]),
        .psel    (apb_psel[0]),
        .penable (apb_penable),
        .pwrite  (apb_pwrite),
        .pwdata  (apb_pwdata),
        .prdata  (plat_prdata),
        .pready  (plat_pready),
        .pslverr (plat_pslverr),
        .sel     (plat_sel),
        .pin_in  (plat_gpio_IN),
        .pin_out (plat_gpio_OUT),
        .pin_oe  (plat_gpio_OE)
    );

    //========================================================================
    // A side display debug page: 0x50..0x7F, see src/display_dbg.v
    //   Two clock/reset pairs are passed in on purpose:
    //     clk/reset            : APB + AXI reader domain (user_clk)
    //     pclk/prst_n          : video domain (hdmi_tx_slow_clk / hdmi_rst_n)
    //   display_dbg does all the clock-domain crossing internally and drives
    //   NOTHING outside itself.
    //========================================================================
    wire        dispdbg_sel;
    wire [31:0] dispdbg_prdata;
    wire        dispdbg_pready, dispdbg_pslverr;

    display_dbg u_display_dbg (
        .clk            (clk),
        .reset          (reset),

        .paddr          (apb_paddr[7:0]),
        .psel           (apb_psel[0]),
        .penable        (apb_penable),
        .pwrite         (apb_pwrite),
        .pwdata         (apb_pwdata),
        .prdata         (dispdbg_prdata),
        .pready         (dispdbg_pready),
        .pslverr        (dispdbg_pslverr),
        .sel            (dispdbg_sel),

        .pclk           (dispdbg_pclk),
        .prst_n         (dispdbg_pclk_reset_n),
        .disp_de        (dispdbg_pclk_de),
        .disp_have      (dispdbg_pclk_have),
        .disp_vs        (dispdbg_pclk_vs),
        .disp_vcnt      (dispdbg_pclk_vcnt),

        .reader_arvalid (dispdbg_reader_arvalid),
        .reader_arready (dispdbg_reader_arready),
        .reader_rvalid  (dispdbg_reader_rvalid),
        .reader_rready  (dispdbg_reader_rready),
        .reader_busy    (dispdbg_reader_busy),
        .reader_error   (dispdbg_reader_error),
        .reader_line_req (dispdbg_reader_line_req),
        .reader_line_done(dispdbg_reader_line_done),

        .disp_relock_tgl  (dispdbg_pclk_relock_tgl),
        .disp_relock_busy (dispdbg_pclk_relock_busy),
        .dbg_relock_en    (dispdbg_relock_en)
    );

    //========================================================================
    // Three-slave APB3 arbitration: GPU (0x00..0x3F), platform GPIO
    // (0x40..0x4F), display debug (0x50..0x8F, rtl7 extended it for the
    // 4-byte aligned phase registers at 0x80/0x84).
    //   Exactly one SEL may be high; the GPU is masked off by the other two.
    //   PRDATA is the 3:1 mux, PREADY = AND, PSLVERR = OR.
    //   NOTE: the GPU term is the 48c0a72 expression with ONLY `& ~dispdbg_sel`
    //   added, so GPU selection is unchanged outside 0x50..0x7F.
    //========================================================================
    wire uart_sel;
    wire [31:0] uart_prdata;
    wire uart_pready, uart_pslverr;

    platform_uart_rx u_platform_uart_rx (
        .clk(clk), .reset(reset), .rx(plat_gpio_IN[6]),
        .paddr(apb_paddr), .psel(apb_psel[0]), .penable(apb_penable),
        .pwrite(apb_pwrite), .pwdata(apb_pwdata), .sel(uart_sel),
        .prdata(uart_prdata), .pready(uart_pready), .pslverr(uart_pslverr)
    );

    wire        gpu_sel = apb_psel[0] & ~plat_sel & ~dispdbg_sel & ~uart_sel;
    wire [31:0] gpu_prdata;
    wire        gpu_pready, gpu_pslverr;

    assign apb_prdata    = uart_sel    ? uart_prdata    :
                           plat_sel    ? plat_prdata    :
                           dispdbg_sel ? dispdbg_prdata : gpu_prdata;
    assign apb_pready    = plat_pready & dispdbg_pready & gpu_pready & uart_pready;
    assign apb_pslverror = plat_pslverr | dispdbg_pslverr | gpu_pslverr | uart_pslverr;

    gpu_top u_gpu_top (
        .pclk    (clk),
        .presetn (~reset),

        // ---- Stage 6: double-buffer swap handshake ----------------------
        .display_fb_sel_req    (display_fb_sel_req),
        .display_fb_sel_active (display_fb_sel_active),

        .paddr   (gpu_paddr),
        .psel    (gpu_sel),
        .penable (apb_penable),
        .pwrite  (apb_pwrite),
        .pwdata  (apb_pwdata),
        .prdata  (gpu_prdata),
        .pready  (gpu_pready),
        .pslverr (gpu_pslverr),

        // ---- AXI4 write master (Stage 2) --------------------------------
        .m_axi_awaddr  (m_axi_awaddr),
        .m_axi_awlen   (m_axi_awlen),
        .m_axi_awsize  (m_axi_awsize),
        .m_axi_awburst (m_axi_awburst),
        .m_axi_awvalid (m_axi_awvalid),
        .m_axi_awready (m_axi_awready),
        .m_axi_wdata   (m_axi_wdata),
        .m_axi_wstrb   (m_axi_wstrb),
        .m_axi_wlast   (m_axi_wlast),
        .m_axi_wvalid  (m_axi_wvalid),
        .m_axi_wready  (m_axi_wready),
        .m_axi_bresp   (m_axi_bresp),
        .m_axi_bvalid  (m_axi_bvalid),
        .m_axi_bready  (m_axi_bready),

        // ---- AXI4 read master (Stage 4) ---------------------------------
        .m_axi_arid    (m_axi_arid),
        .m_axi_araddr  (m_axi_araddr),
        .m_axi_arlen   (m_axi_arlen),
        .m_axi_arsize  (m_axi_arsize),
        .m_axi_arburst (m_axi_arburst),
        .m_axi_arlock  (m_axi_arlock),
        .m_axi_arvalid (m_axi_arvalid),
        .m_axi_arready (m_axi_arready),
        .m_axi_rid     (m_axi_rid),
        .m_axi_rdata   (m_axi_rdata),
        .m_axi_rlast   (m_axi_rlast),
        .m_axi_rresp   (m_axi_rresp),
        .m_axi_rvalid  (m_axi_rvalid),
        .m_axi_rready  (m_axi_rready)
    );

endmodule
